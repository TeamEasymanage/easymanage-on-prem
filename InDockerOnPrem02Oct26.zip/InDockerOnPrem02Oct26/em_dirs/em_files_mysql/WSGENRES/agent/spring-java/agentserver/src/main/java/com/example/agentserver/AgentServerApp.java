package com.example.agentserver; 

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// ------------------------------------------------------------ 
// Agentic AI
// ------------------------------------------------------------ 

// For MCP Combined Mode
//@SpringBootApplication(scanBasePackages = {"com.example.agentserver", "com.example.emmcp"})

@SpringBootApplication
public class AgentServerApp {

	public static void main(String[] args) {
		SpringApplication.run(AgentServerApp.class, args);
	}
}

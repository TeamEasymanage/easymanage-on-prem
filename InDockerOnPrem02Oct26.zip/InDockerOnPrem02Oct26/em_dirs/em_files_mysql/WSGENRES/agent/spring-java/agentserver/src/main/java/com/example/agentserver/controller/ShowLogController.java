package com.example.agentserver.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Value;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@CrossOrigin  
@RestController
@RequestMapping("/agentserver/agent")
public class ShowLogController {

    @Value("${agentserver.showlogEnabled}")
    private Boolean showlogEnabled;

    @GetMapping(value = "/showlogend")
    public String showLogEnd(@RequestParam(defaultValue = "2000") int noOfLines) {

        if (!showlogEnabled) {
            return "Log viewing is disabled in the application properties.";
        }

        if (noOfLines <= 0) {
            return "Invalid number of lines requested. Please provide a positive value."; 
        }

        if (noOfLines == 1) {
            noOfLines = 2;
        }

        if (noOfLines > 5000) {
            noOfLines = 5000;
        }

		String userDir = System.getProperty("user.dir");
		File logFile = new File(userDir, "target/logs/agentserver.log");

		//System.out.println("Log file path: " + logFile.getAbsolutePath());

        List<String> lines = new ArrayList<>();
        
        // "r" means open the file in read-only mode
        try (RandomAccessFile filename = new RandomAccessFile(logFile, "r")) {
            long fileLength = logFile.length();
            long pointer = fileLength - 1;
            
            StringBuilder currentLine = new StringBuilder();
            int lineCount = 0;

            // Read backward from the end of the file
            while (pointer >= 0 && lineCount < noOfLines) {
                filename.seek(pointer);
                int c = filename.read();
                
                if (c == '\n') {
                    if (currentLine.length() > 0 || pointer == fileLength - 1) {
                        lines.add(currentLine.reverse().toString());
                        currentLine.setLength(0); // Reset buffer
                        lineCount++;
                    }
                } else if (c != '\r') { // Ignore Windows carriage returns
                    currentLine.append((char) c);
                }
                pointer--;
            }

            // Don't forget the very first line if we hit the top of the file
            if (currentLine.length() > 0 && lineCount < noOfLines) {
                lines.add(currentLine.reverse().toString());
            }

            // Since we read backwards, we must reverse the list to restore chronological order
            Collections.reverse(lines);
            
            return String.join("\n", lines);

        } catch (IOException e) {
            return "Error reading log file: " + e.getMessage();
        }

    }

    @GetMapping(value = "/showlogfile")
    public String showLogFile() {

        if (!showlogEnabled) {
            return "Log viewing is disabled in the application properties.";
        }

            String userDir = System.getProperty("user.dir");
            File logFile = new File(userDir, "target/logs/agentserver.log");

            //System.out.println("Log file path: " + logFile.getAbsolutePath());

            StringBuilder logContent = new StringBuilder();
            try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(logFile))) {
                String line;
                while ((line = br.readLine()) != null) {
                    logContent.append(line).append("\n");
                }
            } catch (java.io.IOException e) {
                return "Error reading log file: " + e.getMessage();
            }
            return logContent.toString();
    }

}

package com.example.agentserver.service; 

import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 

import org.springframework.ai.tool.ToolCallbackProvider; 
import org.springframework.ai.tool.ToolCallback; 
import org.springframework.ai.mcp.SyncMcpToolCallbackProvider;
import io.modelcontextprotocol.client.McpSyncClient;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor; 
import org.springframework.ai.chat.memory.MessageWindowChatMemory; 
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate; 

import com.example.agentserver.model.AgentModels.AgentProj;
import com.example.agentserver.model.AgentModels.AgentTask;
import com.example.agentserver.model.AgentModels.AgentStartRequest;
import com.example.agentserver.model.AgentModels.ChatRequest;
import com.example.agentserver.model.AgentExecution;
import com.example.agentserver.model.AgentExecution.Status;
import com.example.agentserver.ChainAgent;
import com.example.agentserver.model.RestorePoint;

@Service
public class AgentExecutionService {

	private static final Logger logger = LoggerFactory.getLogger(AgentExecutionService.class); 

    @Value("${agentserver.max-sessions}")
    private int maxSessions;

    @Value("${em.mcptools.toolTypeExcl}")
    private String toolTypeExcl;

    @Value("${em.mcptools.mcpgroupsEnabled}")
    private Boolean mcpgroupsEnabled;

    private final McpToolGroupsConfig mcpgroupsConfig;

    private final ChatClient.Builder chatClientBuilder;
    private ToolCallbackProvider tools;
    List<McpSyncClient> mcpClients;

    private final Map<String, AgentExecution> executions = new ConcurrentHashMap<>();

    private final Map<String, List<ToolCallback>> toolsForExecution = new ConcurrentHashMap<>();

    //private final Map<String, List<ToolCallback>> toolsForHub = new ConcurrentHashMap<>();

    public AgentExecutionService(ChatClient.Builder chatClientBuilder, ToolCallbackProvider tools, List<McpSyncClient> mcpClients, McpToolGroupsConfig mcpgroupsConfig) {
        this.chatClientBuilder = chatClientBuilder;
        this.tools = tools;
        this.mcpClients = mcpClients;
        this.mcpgroupsConfig = mcpgroupsConfig;
    }

    // =========== List MCP Servers and tools ===========

    // If MCP Tool Groups are enabled, list the groups and their effective tools.
    public String listMcpToolGroups() {

		StringBuffer sb = new StringBuffer();

			ToolCallback[] toolCallbacks = tools.getToolCallbacks(); 

			sb.append("------- Total MCP Tools Available: {} ------------ [" + toolCallbacks.length + "]"); 
			sb.append("\n\n"); 
			sb.append("------- MCP Tool Groups: ------------ "); 
			sb.append("\n\n"); 

			List<ToolCallback> selectedToolCallbacks = Arrays.asList(toolCallbacks); 

			sb.append("==================================================================="); 
			sb.append("\n\n"); 

			logger.info("------- listMcpToolGroups ------------ ");  


            // MCP Tool Groups
            /*
            // If enabled, and mcpgroup.* present, process as below
            //  for each group, check pattern str : list tools
            */

            if (mcpgroupsEnabled != null && mcpgroupsEnabled) {
			sb.append("------- MCP Tool Groups : Enabled ------------ ");  
			sb.append("\n\n"); 
                // Apply MCP Tool Groups logic
                Map<String, String> mcpgroups = mcpgroupsConfig.getMcpgroup();
                if (mcpgroups != null && !mcpgroups.isEmpty()) {
    			sb.append("All MCP Tool Groups & Patterns: " + mcpgroups.toString());  
			sb.append("\n\n"); 

			sb.append("==================================================================="); 
			sb.append("\n\n"); 

                String[] keysArray = mcpgroups.keySet().toArray(new String[0]);

                for (String key : keysArray) {
    			sb.append("For MCP Tool Group: " + key.toString());  
			sb.append("\n\n"); 
                String toolsFromMatchedGroups = "";
                        toolsFromMatchedGroups = mcpgroups.get(key);

                // ------------------------------------------------------
                    if (toolsFromMatchedGroups != null && toolsFromMatchedGroups.trim().length() > 0) {
                    sb.append("------- Applicable Tools : For Group " + key + " ------------ ");  
			sb.append("\n"); 

                    String[] inclGrpConditionArray = toolsFromMatchedGroups.split("\\|");
                    for (int i=0; i< inclGrpConditionArray.length; i++) {
                    System.out.println(" i = " + i + " cond: " + inclGrpConditionArray[i]);
                    }

                    Predicate<ToolCallback> inclGrpPredicate = Arrays.stream(inclGrpConditionArray)
                            .map(cond -> (Predicate<ToolCallback>) s -> s.getToolDefinition().name().contains(cond))
                            .reduce(x -> false, Predicate::or); 

                    List<ToolCallback> inclGrpToolCallbacks = selectedToolCallbacks.stream() 
                        .filter(inclGrpPredicate)
                        .toList(); 
                    sb.append("------- Total Applicable Tools : "+inclGrpToolCallbacks.size()+" ------------ "); 
			sb.append("\n\n"); 

            inclGrpToolCallbacks.forEach(toolCallback -> {
                sb.append("Tool Name: " + toolCallback.getToolDefinition().name());
	    		sb.append("\n"); 
                //sb.append("Tool Description: " + toolCallback.getToolDefinition().description());
    			//sb.append("\n"); 
            });

			sb.append("\n"); 
			sb.append("==================================================================="); 
			sb.append("\n\n"); 

                    }
                // ------------------------------------------------------

                }

                } else {
                sb.append("MCP Group Definitions (em.mcptools.mcpgroup.*) in application properties are empty.");
                }

                } else {
                sb.append("MCP Tool Groups : Not Enabled in application properties.");
                }

	return sb.toString();
    }

    // For multiple servers, use the static helper method
    public String listMcpWiseTools() {
		StringBuffer sb = new StringBuffer();

        int i=0;
        for (McpSyncClient mcpClient : mcpClients) {

            sb.append("MCP Server " + (++i) + " : \n");
            sb.append("  Server Name : " + mcpClient.getServerInfo().name());
			sb.append("\n"); 
            sb.append("  Client Name : " + mcpClient.getClientInfo().title());
			sb.append("\n\n"); 

            /*
            sb.append("MCP Server " + (++i) + " getServerInfo(): \n\n" + mcpClient.getServerInfo().toString());
			sb.append("\n\n"); 
            sb.append("Tools from MCP Server " + i + " getClientInfo(): " + mcpClient.getClientInfo().toString());
			sb.append("\n\n"); 
            //sb.append("Tools from MCP Server " + i + " listResources(): " + mcpClient.listResources().toString());
			//sb.append("\n\n"); 
            //sb.append("Tools from MCP Server " + i + " listTools(): " + mcpClient.listTools().toString());
            */

            SyncMcpToolCallbackProvider provider = new SyncMcpToolCallbackProvider(mcpClient);

            ToolCallback[] toolCallbacks = provider.getToolCallbacks();

			sb.append("  ----- Total MCP Tools Available: {} ------------ [" + toolCallbacks.length + "]"); 
			sb.append("\n\n"); 

            Arrays.stream(toolCallbacks).forEach(toolCallback -> {
                sb.append("Tool Name: " + toolCallback.getToolDefinition().name());
	    		sb.append("\n"); 
                //sb.append("Tool Description: " + toolCallback.getToolDefinition().description());
    			//sb.append("\n"); 
            });

			sb.append("\n\n"); 
			sb.append("==================================================================="); 
			sb.append("\n\n"); 

        }
        return sb.toString();
    }

    public String listTools() {

		StringBuffer sb = new StringBuffer();
			ToolCallback[] toolCallbacks = tools.getToolCallbacks(); 

			sb.append("------- Total MCP Tools Available: {} ------------ [" + toolCallbacks.length + "]"); 

			sb.append("\n"); 
 			sb.append("\n"); 

			for (ToolCallback callback : toolCallbacks) { 
				sb.append("Tool Name: " + callback.getToolDefinition().name()); 
    			sb.append("\n"); 
				//System.out.println("Tool Description: " + callback.getToolDefinition().description()); 
				//To inspect the input schema: 
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema()); 
			} 
	return sb.toString();
    }

    public String listToolsFilterWise(
                boolean projLevel, 
                //From AgentExecution execution
                int toolLimit,
                String toolNameIncl,
                String toolNameExcl
                ) {

		StringBuffer sb = new StringBuffer();

			sb.append("\n"); 
 			sb.append("\n"); 

            // ** START Tools Filter **
			ToolCallback[] toolCallbacks = tools.getToolCallbacks(); 

			sb.append("------- Total MCP Tools Available: {} ------------ : " + toolCallbacks.length); 

			sb.append("\n"); 
 			sb.append("\n"); 

            /* 
			for (ToolCallback callback : toolCallbacks) { 
				System.out.println("Tool Name: " + callback.getToolDefinition().name()); 
				//System.out.println("Tool Description: " + callback.getToolDefinition().description()); 
				//To inspect the input schema: 
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema()); 
			} 
            */

			List<ToolCallback> selectedToolCallbacks = Arrays.asList(toolCallbacks); 

			sb.append("------- Filter|Use MCP Tools ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

            /*
			sb.append("------- Filter Tran Tools [create_|update_|delete_] ----------- ");  
			List<ToolCallback> filteredToolCallbacks = selectedToolCallbacks.stream() 
				.filter(tool ->  
					!tool.getToolDefinition().name().contains("update_") && 
					!tool.getToolDefinition().name().contains("create_") && 
					!tool.getToolDefinition().name().contains("delete_")  
					) // Filter out specific tools by name 
				.toList(); 
				selectedToolCallbacks = filteredToolCallbacks; 
			//chatClient.call(new Prompt(userMessage, new ChatOptionsBuilder().withTools(selectedToolCallbacks).build())); 
            */
			//sb.append("------- Filter Tools As Per Prop toolTypeExcl ----------- ");  

            if (toolTypeExcl != null && toolTypeExcl.trim().length() > 0) {
			sb.append("------- Filter Tools : toolTypeExcl ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

			sb.append("toolTypeExcl: " + toolTypeExcl);  

			sb.append("\n"); 
 			sb.append("\n"); 

            String[] exclTypeConditionArray = toolTypeExcl.split("\\|");
            for (int i=0; i< exclTypeConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + exclTypeConditionArray[i]);
            }

            Predicate<ToolCallback> exclPredicate = Arrays.stream(exclTypeConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> !s.getToolDefinition().name().contains(cond))
                    .reduce(x -> true, Predicate::and); 

			List<ToolCallback> exclTypeToolCallbacks = selectedToolCallbacks.stream() 
				.filter(exclPredicate)
				.toList(); 
				selectedToolCallbacks = exclTypeToolCallbacks; 
 			sb.append("------- Total MCP Tools - toolTypeExcl : {} ------------ " +selectedToolCallbacks.size()); 

			sb.append("\n"); 
 			sb.append("\n"); 

            }

            //Apply From AgentProj

            if (projLevel) {

            /*
            int toolLimit = execution.getAgentProj().toolLimit();
            String toolNameIncl = execution.getAgentProj().toolNameIncl();
            String toolNameExcl = execution.getAgentProj().toolNameExcl();
            */

            // MCP Tool Groups
            /*
            // If enabled, and mcpgroup.* present, process as below
            //  Check toolNameIncl to scan any mcpgroup(s) included, 
            //  :: combine their pattern str : apply (incl/keep) to list
            //  - remove mcpgroup(s)| from toolNameIncl, +? trim-remove blanks
            //  (leaving toolNameIncl to process later)
            */

            if (mcpgroupsEnabled != null && mcpgroupsEnabled) {
			sb.append("------- MCP Tool Groups : Enabled ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

                // Apply MCP Tool Groups logic
                Map<String, String> mcpgroups = mcpgroupsConfig.getMcpgroup();
                if (mcpgroups != null && !mcpgroups.isEmpty()) {
    			sb.append("mcpgroups: " + mcpgroups.toString());  

			sb.append("\n"); 
 			sb.append("\n"); 


                if (toolNameIncl != null && toolNameIncl.trim().length() > 0) {
                sb.append("------- Filter Groups if any : toolNameIncl ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

                sb.append("toolNameIncl: " + toolNameIncl);  

			sb.append("\n"); 


                String[] keysArray = mcpgroups.keySet().toArray(new String[0]);

                List<String> matchedGroups = new ArrayList<>();
                String toolsFromMatchedGroups = "";
                boolean gotMatch = false;

                for (String key : keysArray) {
                    if(toolNameIncl.contains(key)) {
                        matchedGroups.add(key);
                        toolNameIncl = toolNameIncl.replace(key, "");
                        toolsFromMatchedGroups = toolsFromMatchedGroups 
                        + mcpgroups.get(key) + "|";
                        gotMatch = true;
                    }
                }
                sb.append("matchedGroups: " + matchedGroups.toString());

			sb.append("\n"); 


                if(gotMatch) {
                // ------------------------------------------------------
                    if (toolsFromMatchedGroups != null && toolsFromMatchedGroups.trim().length() > 0) {
                    sb.append("------- Filter Tools : toolsFromMatchedGroups ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

                    sb.append("toolsFromMatchedGroups: " + toolsFromMatchedGroups);  

			sb.append("\n"); 

                    String[] inclGrpConditionArray = toolsFromMatchedGroups.split("\\|");
                    for (int i=0; i< inclGrpConditionArray.length; i++) {
                    System.out.println(" i = " + i + " cond: " + inclGrpConditionArray[i]);
                    }

                    Predicate<ToolCallback> inclGrpPredicate = Arrays.stream(inclGrpConditionArray)
                            .map(cond -> (Predicate<ToolCallback>) s -> s.getToolDefinition().name().contains(cond))
                            .reduce(x -> false, Predicate::or); 

                    List<ToolCallback> inclGrpToolCallbacks = selectedToolCallbacks.stream() 
                        .filter(inclGrpPredicate)
                        .toList(); 
                        selectedToolCallbacks = inclGrpToolCallbacks; 
                    sb.append("------- Total MCP Tools - toolsFromMatchedGroups : {} ------------ " +selectedToolCallbacks.size()); 

			sb.append("\n"); 
 			sb.append("\n"); 

                    }
                // ------------------------------------------------------

                }

                }

                } else {
                System.out.println("MCP Groups (em.mcptools.mcpgroup.*) are empty.");
                }

            }

            // Process toolNameIncl for tools

            if (toolNameIncl != null && toolNameIncl.trim().length() > 0) {

			sb.append("------- Filter Tools : toolNameIncl ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

			sb.append("toolNameIncl: " + toolNameIncl);  

			sb.append("\n"); 
 			sb.append("\n"); 

            //toolNameIncl = toolNameIncl.trim();
            toolNameIncl = toolNameIncl.replace("||", "|");
            //if (toolNameIncl.equals("|")) { toolNameIncl = ""; }
            if (toolNameIncl.startsWith("|")) {
                toolNameIncl = toolNameIncl.substring(1);
            }
            if (toolNameIncl.endsWith("|")) {
                toolNameIncl = toolNameIncl.substring(0, toolNameIncl.length() - 1);
            }

			sb.append("toolNameIncl: " + toolNameIncl);  

			sb.append("\n"); 
 			sb.append("\n"); 

            String[] inclConditionArray = toolNameIncl.split("\\|");
            for (int i=0; i< inclConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + inclConditionArray[i]);
            }

            Predicate<ToolCallback> inclPredicate = Arrays.stream(inclConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> s.getToolDefinition().name().contains(cond))
                    .reduce(x -> false, Predicate::or); 

			List<ToolCallback> inclToolCallbacks = selectedToolCallbacks.stream() 
				.filter(inclPredicate)
				.toList(); 
				selectedToolCallbacks = inclToolCallbacks; 
 			sb.append("------- Total MCP Tools - toolNameIncl : {} ------------ " +selectedToolCallbacks.size()); 

			sb.append("\n"); 
 			sb.append("\n"); 

            }

            if (toolNameExcl != null && toolNameExcl.trim().length() > 0) {
			sb.append("------- Filter Tools : toolNameExcl ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

			sb.append("toolNameExcl: " + toolNameExcl);  

			sb.append("\n"); 
 			sb.append("\n"); 

            String[] exclConditionArray = toolNameExcl.split("\\|");
            for (int i=0; i< exclConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + exclConditionArray[i]);
            }

            Predicate<ToolCallback> exclPredicate = Arrays.stream(exclConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> !s.getToolDefinition().name().contains(cond))
                    .reduce(x -> true, Predicate::and); 

			List<ToolCallback> exclToolCallbacks = selectedToolCallbacks.stream() 
				.filter(exclPredicate)
				.toList(); 
				selectedToolCallbacks = exclToolCallbacks; 
 			sb.append("------- Total MCP Tools - toolNameExcl : {} ------------ " +selectedToolCallbacks.size()); 

			sb.append("\n"); 
 			sb.append("\n"); 

            }

            if (toolLimit > 0 && toolLimit < selectedToolCallbacks.size()) {
			sb.append("------- Apply toolLimit ("+toolLimit+") ------------ ");  
			List<ToolCallback> limitedToolCallbacks = selectedToolCallbacks.stream() 
                .limit(toolLimit) 
				.toList(); 
				selectedToolCallbacks = limitedToolCallbacks; 
 			sb.append("------- Total MCP Tools - toolLimit : {} ------------ " +selectedToolCallbacks.size()); 

			sb.append("\n"); 
 			sb.append("\n"); 

            }

            } //projLevel


			sb.append("------- Selected MCP Tools ------------ ");  

			sb.append("\n"); 
 			sb.append("\n"); 

 
			sb.append("------- Total Selected MCP Tools: {} ------------ " +selectedToolCallbacks.size());  

			sb.append("\n"); 
 			sb.append("\n"); 

 
			for (ToolCallback callback : selectedToolCallbacks) {  
				sb.append("Tool Name: " + callback.getToolDefinition().name());  
    			sb.append("\n"); 
				//System.out.println("Tool Description: " + callback.getToolDefinition().description());  
				//To inspect the input schema:  
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema());  
			}  

			sb.append("\n"); 
 			sb.append("\n"); 

            // ** END Tools Filter **
	return sb.toString();
    }


    // =========== List MCP Servers and tools ===========

    private ChatClient buildChatClient(AgentExecution execution) {

            // ** START Tools Filter **
			ToolCallback[] toolCallbacks = tools.getToolCallbacks(); 

			logger.info("------- Total MCP Tools Available: {} ------------ ",toolCallbacks.length); 

            /* 
			for (ToolCallback callback : toolCallbacks) { 
				System.out.println("Tool Name: " + callback.getToolDefinition().name()); 
				//System.out.println("Tool Description: " + callback.getToolDefinition().description()); 
				//To inspect the input schema: 
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema()); 
			} 
            */

			List<ToolCallback> selectedToolCallbacks = Arrays.asList(toolCallbacks); 

			logger.info("------- Filter|Use MCP Tools ------------ ");  

            /*
			logger.info("------- Filter Tran Tools [create_|update_|delete_] ----------- ");  
			List<ToolCallback> filteredToolCallbacks = selectedToolCallbacks.stream() 
				.filter(tool ->  
					!tool.getToolDefinition().name().contains("update_") && 
					!tool.getToolDefinition().name().contains("create_") && 
					!tool.getToolDefinition().name().contains("delete_")  
					) // Filter out specific tools by name 
				.toList(); 
				selectedToolCallbacks = filteredToolCallbacks; 
			//chatClient.call(new Prompt(userMessage, new ChatOptionsBuilder().withTools(selectedToolCallbacks).build())); 
            */
			//logger.info("------- Filter Tools As Per Prop toolTypeExcl ----------- ");  

            if (toolTypeExcl != null && toolTypeExcl.trim().length() > 0) {
			logger.info("------- Filter Tools : toolTypeExcl ------------ ");  
			logger.info("toolTypeExcl: " + toolTypeExcl);  

            String[] exclTypeConditionArray = toolTypeExcl.split("\\|");
            for (int i=0; i< exclTypeConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + exclTypeConditionArray[i]);
            }

            Predicate<ToolCallback> exclPredicate = Arrays.stream(exclTypeConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> !s.getToolDefinition().name().contains(cond))
                    .reduce(x -> true, Predicate::and); 

			List<ToolCallback> exclTypeToolCallbacks = selectedToolCallbacks.stream() 
				.filter(exclPredicate)
				.toList(); 
				selectedToolCallbacks = exclTypeToolCallbacks; 
 			logger.info("------- Total MCP Tools - toolTypeExcl : {} ------------ ",selectedToolCallbacks.size()); 
            }

            //Apply From AgentProj

            int toolLimit = execution.getAgentProj().toolLimit();
            String toolNameIncl = execution.getAgentProj().toolNameIncl();
            String toolNameExcl = execution.getAgentProj().toolNameExcl();
            String sysPrompt = execution.getAgentProj().sysPrompt();

            // MCP Tool Groups
            /*
            // If enabled, and mcpgroup.* present, process as below
            //  Check toolNameIncl to scan any mcpgroup(s) included, 
            //  :: combine their pattern str : apply (incl/keep) to list
            //  - remove mcpgroup(s)| from toolNameIncl, +? trim-remove blanks
            //  (leaving toolNameIncl to process later)
            */

            if (mcpgroupsEnabled != null && mcpgroupsEnabled) {
			logger.info("------- MCP Tool Groups : Enabled ------------ ");  
                // Apply MCP Tool Groups logic
                Map<String, String> mcpgroups = mcpgroupsConfig.getMcpgroup();
                if (mcpgroups != null && !mcpgroups.isEmpty()) {
    			logger.info("mcpgroups: " + mcpgroups.toString());  

                if (toolNameIncl != null && toolNameIncl.trim().length() > 0) {
                logger.info("------- Filter Groups if any : toolNameIncl ------------ ");  
                logger.info("toolNameIncl: " + toolNameIncl);  

                String[] keysArray = mcpgroups.keySet().toArray(new String[0]);

                List<String> matchedGroups = new ArrayList<>();
                String toolsFromMatchedGroups = "";
                boolean gotMatch = false;

                for (String key : keysArray) {
                    if(toolNameIncl.contains(key)) {
                        matchedGroups.add(key);
                        toolNameIncl = toolNameIncl.replace(key, "");
                        toolsFromMatchedGroups = toolsFromMatchedGroups 
                        + mcpgroups.get(key) + "|";
                        gotMatch = true;
                    }
                }
                logger.info("matchedGroups: " + matchedGroups.toString());

                if(gotMatch) {
                // ------------------------------------------------------
                    if (toolsFromMatchedGroups != null && toolsFromMatchedGroups.trim().length() > 0) {
                    logger.info("------- Filter Tools : toolsFromMatchedGroups ------------ ");  
                    logger.info("toolsFromMatchedGroups: " + toolsFromMatchedGroups);  

                    String[] inclGrpConditionArray = toolsFromMatchedGroups.split("\\|");
                    for (int i=0; i< inclGrpConditionArray.length; i++) {
                    System.out.println(" i = " + i + " cond: " + inclGrpConditionArray[i]);
                    }

                    Predicate<ToolCallback> inclGrpPredicate = Arrays.stream(inclGrpConditionArray)
                            .map(cond -> (Predicate<ToolCallback>) s -> s.getToolDefinition().name().contains(cond))
                            .reduce(x -> false, Predicate::or); 

                    List<ToolCallback> inclGrpToolCallbacks = selectedToolCallbacks.stream() 
                        .filter(inclGrpPredicate)
                        .toList(); 
                        selectedToolCallbacks = inclGrpToolCallbacks; 
                    logger.info("------- Total MCP Tools - toolsFromMatchedGroups : {} ------------ ",selectedToolCallbacks.size()); 
                    }
                // ------------------------------------------------------

                }

                }

                } else {
                System.out.println("MCP Groups (em.mcptools.mcpgroup.*) are empty.");
                }

            }

            // Process toolNameIncl for tools

            if (toolNameIncl != null && toolNameIncl.trim().length() > 0) {
			logger.info("------- Filter Tools : toolNameIncl ------------ ");  
			logger.info("toolNameIncl: " + toolNameIncl);  

            //toolNameIncl = toolNameIncl.trim();
            toolNameIncl = toolNameIncl.replace("||", "|");
            //if (toolNameIncl.equals("|")) { toolNameIncl = ""; }
            if (toolNameIncl.startsWith("|")) {
                toolNameIncl = toolNameIncl.substring(1);
            }
            if (toolNameIncl.endsWith("|")) {
                toolNameIncl = toolNameIncl.substring(0, toolNameIncl.length() - 1);
            }

			logger.info("toolNameIncl: " + toolNameIncl);  

            String[] inclConditionArray = toolNameIncl.split("\\|");
            for (int i=0; i< inclConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + inclConditionArray[i]);
            }

            Predicate<ToolCallback> inclPredicate = Arrays.stream(inclConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> s.getToolDefinition().name().contains(cond))
                    .reduce(x -> false, Predicate::or); 

			List<ToolCallback> inclToolCallbacks = selectedToolCallbacks.stream() 
				.filter(inclPredicate)
				.toList(); 
				selectedToolCallbacks = inclToolCallbacks; 
 			logger.info("------- Total MCP Tools - toolNameIncl : {} ------------ ",selectedToolCallbacks.size()); 
            }

            if (toolNameExcl != null && toolNameExcl.trim().length() > 0) {
			logger.info("------- Filter Tools : toolNameExcl ------------ ");  
			logger.info("toolNameExcl: " + toolNameExcl);  

            String[] exclConditionArray = toolNameExcl.split("\\|");
            for (int i=0; i< exclConditionArray.length; i++) {
            System.out.println(" i = " + i + " cond: " + exclConditionArray[i]);
            }

            Predicate<ToolCallback> exclPredicate = Arrays.stream(exclConditionArray)
                    .map(cond -> (Predicate<ToolCallback>) s -> !s.getToolDefinition().name().contains(cond))
                    .reduce(x -> true, Predicate::and); 

			List<ToolCallback> exclToolCallbacks = selectedToolCallbacks.stream() 
				.filter(exclPredicate)
				.toList(); 
				selectedToolCallbacks = exclToolCallbacks; 
 			logger.info("------- Total MCP Tools - toolNameExcl : {} ------------ ",selectedToolCallbacks.size()); 
            }

            if (toolLimit > 0 && toolLimit < selectedToolCallbacks.size()) {
			logger.info("------- Apply toolLimit ("+toolLimit+") ------------ ");  
			List<ToolCallback> limitedToolCallbacks = selectedToolCallbacks.stream() 
                .limit(toolLimit) 
				.toList(); 
				selectedToolCallbacks = limitedToolCallbacks; 
 			logger.info("------- Total MCP Tools - toolLimit : {} ------------ ",selectedToolCallbacks.size()); 
            }


			logger.info("------- Selected MCP Tools ------------ ");  
 
			logger.info("------- Total Selected MCP Tools: {} ------------ ",selectedToolCallbacks.size());  
 
			for (ToolCallback callback : selectedToolCallbacks) {  
				System.out.println("Tool Name: " + callback.getToolDefinition().name());  
				//System.out.println("Tool Description: " + callback.getToolDefinition().description());  
				//To inspect the input schema:  
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema());  
			}  

            // ** END Tools Filter **

		logger.info("------- Build ChatClient  ------------ "); 
 
			String systemPrompt = 
			"""  
			You are a senior data analyst specializing in data insights. 
			""" 
			; 
			/* 
			// Ex for For feature engineering 
			""" 
			You are a data scientist agent. Based on the table schema and data inputs, 
			identify the most relevant features for predicting customer churn. 
			Explain your process and feature importance before outputting the final feature list. 
			"""; 
			 */ 
 
            if (sysPrompt != null && sysPrompt.trim().length() > 0) {
			logger.info("------- Using Requested systemPrompt ----------- ");  
			logger.info("systemPrompt: " + sysPrompt);  
                systemPrompt = sysPrompt;
            }

            toolsForExecution.put(execution.getExecutionId(), selectedToolCallbacks);

			ChatClient chatClient = chatClientBuilder 
					.defaultSystem(systemPrompt) 
					.defaultAdvisors(
                        MessageChatMemoryAdvisor.builder(MessageWindowChatMemory.builder().build()).build()
						, new SimpleLoggerAdvisor()
                    ) 
					.build(); 

            return chatClient;

                    /* Note
                    // using defaultToolCallbacks gives error
                    //Exception Error message: Multiple tools with the same name (...) found in ToolCallingChatOptions
					//.defaultToolCallbacks(selectedToolCallbacks) 
					//.defaultToolCallbacks(tools) 
                    */


    }

    public List<ToolCallback> getToolsForExecution(String executionId) {
        return toolsForExecution.get(executionId);
    }

    public AgentExecution startAgent(AgentStartRequest agentStartRequest, String switchModel) {


        System.out.println("INFO agentserver.max-sessions = "+maxSessions);

        int totalExecutions = executions.size();

        if (totalExecutions >= maxSessions) {
            String maxMsg = "Error: Max Sessions Limit Reached, Close sessions and re-try.";
            System.out.println(maxMsg);
            throw new RuntimeException(maxMsg);
        }

        String projId = agentStartRequest.agentProj().projId();
        String[] inputPrompts = Arrays.stream(agentStartRequest.agentTasks())
                                    .map(AgentTask::inputPrompt) 
                                    .toArray(String[]::new); 

        AgentExecution execution = new AgentExecution(
                        projId, 
                        inputPrompts, 
                        agentStartRequest.agentProj(), 
                        agentStartRequest.agentTasks(),
                        switchModel);
        executions.put(execution.getExecutionId(), execution);
        
        // Execute first step immediately
        executeNextStep(execution);
        
        return execution;
    }

    // -------- chatrun -----
    public AgentExecution chatRun(String executionId, ChatRequest chatRequest) {


        // Get the execution
        AgentExecution execution = getExecution(executionId);

        // Retireve the agentTasks and add new task for this chatRun step with input from chatRequest
        AgentTask[] existingTasks = execution.getAgentTasks();

        AgentTask newChatTask = new AgentTask(
            ""+(existingTasks.length+1), // taskId
            existingTasks.length+1, // taskOrd
            "Chat Run Task "+(existingTasks.length+1), // taskName
            "Input", // promptType
            chatRequest.inputPrompt(), // inputPrompt
            "", // inputContext
            "No", // prevContextYN
            "", // prevContextSel
            "", // contextSvPrompt
            "",  // taskModel
            "No",  // ragYN
            "",  // ragFilter
            "No"   // semCacheYN
        );

        AgentTask[] updatedTasks = Arrays.copyOf(existingTasks, existingTasks.length + 1);        
        updatedTasks[updatedTasks.length - 1] = newChatTask;
        execution.setAgentTasks(updatedTasks);

        //update inputPrompts array in execution as well
        String[] updatedPrompts = Arrays.copyOf(execution.getInputPrompts(), execution.getInputPrompts().length + 1);
        updatedPrompts[updatedPrompts.length - 1] = chatRequest.inputPrompt();
        execution.setInputPrompts(updatedPrompts);

        execution.setStatus(Status.PENDING_APPROVAL);  // Set to pending approval for the new chat task  
        // execution.setCurrentStep(execution.getCurrentStep() + 1); // Set current step to the new chat task index  
        // Execute next step
        executeNextStep(execution);
        
        return execution;
    }

    // ----------------------

    public boolean executeNextStep(AgentExecution execution) {
        if (execution.getStatus() != Status.PENDING_APPROVAL && 
            execution.getStatus() != Status.APPROVED) {
            throw new IllegalStateException("Agent is not in a state to execute next step: " + execution.getStatus());
        }

        ChatClient chatClient = buildChatClient(execution);
        ChainAgent agent = new ChainAgent(chatClient, 
                    execution.getInputPrompts(), 
                    execution,
                    getToolsForExecution(execution.getExecutionId())
                    );
        
        // currentStep tracks which step result we're currently on
        // stepResults[0] = projId
        // stepResults[1] = result after prompt[0]
        // stepResults[2] = result after prompt[1]
        // etc.
        int currentStep = execution.getCurrentStep();
        int promptIndex = currentStep; // The prompt index to execute
        
        if (promptIndex >= execution.getInputPrompts().length) {
            // All steps completed
            execution.setStatus(Status.COMPLETED);
            return false;
        }
        
        // Get the previous result (input for first step, previous step result for others)
        String previousResult = execution.getStepResults().get(currentStep);
        
        // Execute the prompt
        String stepResult = agent.executeStep(promptIndex, previousResult);
        execution.addStepResult(stepResult);
        execution.setCurrentStep(currentStep + 1);
        
        // Check if this was the last step
        // After executing all prompts, currentStep equals systemPrompts.length
        if (execution.getCurrentStep() >= execution.getInputPrompts().length) {
            execution.setFinalOutput(stepResult);
            execution.setStatus(Status.COMPLETED);
            return false;
        } else {
            execution.setStatus(Status.PENDING_APPROVAL);
            return true;
        }
    }
    
    public AgentExecution approveStep(String executionId) {
        AgentExecution execution = getExecution(executionId);
        
        if (execution.getStatus() != Status.PENDING_APPROVAL) {
            throw new IllegalStateException("Agent is not pending approval. Current status: " + execution.getStatus());
        }
        
        execution.setStatus(Status.APPROVED);
        
        // Execute next step
        boolean hasMoreSteps = executeNextStep(execution);
        
        if (!hasMoreSteps) {
            execution.setStatus(Status.COMPLETED);
        }
        
        return execution;
    }

    public AgentExecution rejectStep(String executionId, String reason) {
        AgentExecution execution = getExecution(executionId);
        
        if (execution.getStatus() != Status.PENDING_APPROVAL) {
            throw new IllegalStateException("Agent is not pending approval. Current status: " + execution.getStatus());
        }
        
        execution.setStatus(Status.REJECTED);
        execution.setRejectionReason(reason);
        
        return execution;
    }
    
    public AgentExecution getExecution(String executionId) {
        AgentExecution execution = executions.get(executionId);
        if (execution == null) {
            throw new IllegalArgumentException("Agent execution not found: " + executionId);
        }
        return execution;
    }
    
    public AgentExecution cancelExecution(String executionId) {
        AgentExecution execution = getExecution(executionId);
        execution.setStatus(Status.CANCELLED);
        return execution;
    }
    
    public List<String> getExecutions() {
        List<String> executionList = new ArrayList<>();
        executions.entrySet().stream() 
        .map(Map.Entry::getValue)
        .forEach((p) -> { 
            executionList.add(p.getExecutionId()); 
        }); 
        return executionList;
    }

    public List<RestorePoint> getRestorePoints(String executionId) {
        AgentExecution execution = getExecution(executionId);
        List<RestorePoint> restorePoints = new ArrayList<>();
        List<Integer> availableIndices = execution.getAvailableRestorePoints();
        int currentStep = execution.getCurrentStep();
        
        for (Integer stepIndex : availableIndices) {
            String result = execution.getStepResult(stepIndex);
            String description;
            
            if (stepIndex == 0) {
                description = "Original Input";
            } else {
                description = "Step " + stepIndex + " Result";
            }
            
            restorePoints.add(new RestorePoint(
                stepIndex,
                result,
                description,
                stepIndex == currentStep
            ));
        }
        
        return restorePoints;
    }
    
    public AgentExecution restoreToStep(String executionId, int stepIndex, boolean reExecute) {
        AgentExecution execution = getExecution(executionId);
        
        // Validate step index
        if (stepIndex < 0 || stepIndex >= execution.getCompletedStepCount()) {
            throw new IllegalArgumentException("Invalid step index: " + stepIndex + 
                ". Available steps: 0 to " + (execution.getCompletedStepCount() - 1));
        }
        
        // Restore to the step
        boolean restored = execution.restoreToStep(stepIndex);
        if (!restored) {
            throw new IllegalStateException("Failed to restore to step: " + stepIndex);
        }
        
        // If re-execute is requested and we're not at the input step, re-execute
        if (reExecute && stepIndex > 0) {
            // Re-execute the step at the restore point
            // stepIndex 1 means execute prompt[0] on stepResults[0] (input)
            // stepIndex 2 means execute prompt[1] on stepResults[1]
            // So promptIndex = stepIndex - 1
            int promptIndex = stepIndex - 1;
            int previousStepIndex = stepIndex - 1;
            String previousResult = execution.getStepResult(previousStepIndex);
            
            ChatClient chatClient = buildChatClient(execution);
            ChainAgent agent = new ChainAgent(chatClient, 
                        execution.getInputPrompts(), 
                        execution,
                        getToolsForExecution(execution.getExecutionId())
                        );

            String newResult = agent.executeStep(promptIndex, previousResult);
            
            // Replace the result at stepIndex (after restore, stepResults has exactly stepIndex + 1 elements)
            List<String> stepResults = execution.getStepResults();
            stepResults.set(stepIndex, newResult);
            
            // Keep currentStep at stepIndex since we just re-executed that step
            // Status is already set to PENDING_APPROVAL by restoreToStep if stepIndex > 0
            execution.setStatus(Status.PENDING_APPROVAL);
        }
        
        return execution;
    }

    public void closeAgent(String executionId) {
        System.out.println("INFO closing session = "+executionId);
        executions.remove(executionId);
        toolsForExecution.remove(executionId);
    }

    public void closeAllAgents() {
        System.out.println("INFO closing all sessions");
        executions.clear();
    }

}


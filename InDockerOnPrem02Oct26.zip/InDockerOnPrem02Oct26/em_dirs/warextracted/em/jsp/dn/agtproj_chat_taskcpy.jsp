<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wpsd" scope="page" class="em.Agtproj_taskcpypst" />
<%
	wpsd.processRequest(request, response);
	get_gui_str(wpsd.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wpsd.emerr;
	valid_login = wpsd.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Project Chat Task Copy </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wpsd.usrnm;
%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wpsd.categ_name%></b></font></font></td>
</td>
</tr>
</table>
<BR>


	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	%>

	<%= bfont %> <b>Agent Project Chat Task Copy</b></font><br><br>

	<% wpsd.doDbDataChatCopy(request); %>
	<% wpsd.doneReq(); %>

	<%=bfont%> 
	<% if ( wpsd.dodb_stat ==1) { %>

	<%= bfont %> Chat Task Copied: Use Agent Tasks  [ Paste Add ] </font><br>
	<%= bfont %> * To Create New Agent Task From This Chat Prompt </font><br>
	<% } else { %>

	 <%=bfont%> <font color="FF0000">
	 <br><br>
	 Error : Task Copy Failed.
	 <br><br>
	     </font></font>
	<% } %>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	wp.processRequest_gen(request, response);
	get_gui_str(wp.gui_str);


%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> AI Agents Dashboard</title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 8;
	mnu2_sel = 0;
	String usrnm = wp.usrnm;
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	
    String projParam = "";

	String ag_id = "" + request.getParameter("ag_id");
		ag_id = ag_id.replace("null","");
	
	if (ag_id.trim().length() > 1 ) {
		
		String toolLimit = "" + request.getParameter("toolLimit");
		toolLimit = toolLimit.replace("null", " ");
		String toolNameIncl= "" + request.getParameter("toolNameIncl");
		toolNameIncl = toolNameIncl.replace("null", " ");
		String toolNameExcl= "" + request.getParameter("toolNameExcl");
		toolNameExcl = toolNameExcl.replace("null", " ");
		
		projParam = 
				"toolLimit=" + toolLimit +
				"&toolNameIncl=" + toolNameIncl +
				"&toolNameExcl=" + toolNameExcl ;
	}

%>
<%@ include file="../pre_dn_sm.jsp" %>

	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	%>

<style>
.btn {
margin: 2px;
}
</style>

	<%= bfont %> <b>AI Agents Dashboard</b></font>
	<br><br>

<%
	String[] agtSvrConf = wp.getAgtSvrConf();
	String conf_id = agtSvrConf[0];
	String url_base = agtSvrConf[1];
	String api_hdrs = agtSvrConf[2];
	String rd_only = agtSvrConf[3];

	String no_disp_hdrs = "";
	if (app_run == 1) {
		no_disp_hdrs = " style=\"display:none;\" ";
	}
	
	//String modelOpts = wp.getOptRunModels();
	// gets "<select  id=\"runWithModel\" name=runWithModel> "+"\n"+


%>
<% wp.doneRequest(); %>

<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="2"> <%=bfont%> <b>Agent Run Dashboard</b></font>
	<%=bfont1%> 
	</font>
</td>
<td colspan="3"> <%=bfont%> <b>Usage</b></font>
	<%=bfont1%> 
	</font>
</td>
</tr>


	<tr bgcolor="EFEFEF">
<td><%=bfont%> Conf Id <br><br>API Call  </font></td>
<td><%=bfont%> 
	<%=conf_id%> <br><br>
	
	<select id="mySelectApi"></select>
	<br><br>
	    <button onclick="postData()">Execute</button>
		<br><br>

<%
	if (ag_id.trim().length() > 1 ) {

%>
		
		<button class ="btn btn-xs btn-primary" onclick="postDataProj()">list-proj-<%=ag_id%>-tools</button>
<%
	}
%>

	
</font></td>

	<td>
	<%=bfont%>  

	<%
	String tool_tip1 = 
	"Options to list tools available or applicable are: \n" +
	" ** [list-mcp-all-tools, list-mcp-server-wise-tools, list-mcp-tool-groups], \n" +
	"To See what tools are made available in Agent Run and Chat execution, see in : \n" +
	" ** [list-mcp-filter-applied-tools and list-mcp-filter-applied-proj-tools]  \n" ;
	%>

	MCP Tools Available and Filtered: <i class="fa fa-info-circle" title="<%=tool_tip1%>"></i>
	<br>

	list-mcp-all-tools <i class="fa fa-info-circle" title="List All MCP Tools."></i>
	| list-mcp-server-wise-tools <i class="fa fa-info-circle" title="List All MCP Tools - MCP Server Wise."></i>
	| list-mcp-filter-applied-tools <i class="fa fa-info-circle" title="List MCP Tools Filtered As Per em.mcptools.toolTypeExcl app property."></i>
	| list-mcp-tool-groups <i class="fa fa-info-circle" title="List MCP Tools - MCP Tool Group Wise, if groups are setup as app properties."></i>
	| list-sessions
	| list-status 
	| close-all-danger

	<br><br>
	API Base: 
	<input type="text" id="apiEndpointBase" value="<%=url_base%>" size="40"   maxlength="100" readOnly >

	<br><br>
	Headers: 
<textarea id="agentprojhdrs" rows="1" cols="40"  <%=rd_only%> <%=no_disp_hdrs%> >
<%=api_hdrs%>
</textarea>
	
	</font>	
	</td>
	</tr>

	</table> 


	<%=bfont%> <b>Response: </b><br>
    <pre id="responseArea"></pre>

<script>
const toolList = [
    { "tool_name": "list-mcp-all-tools" 		  , "tool_description": ""},
    { "tool_name": "list-mcp-server-wise-tools" , "tool_description": ""},
    { "tool_name": "list-mcp-filter-applied-tools" , "tool_description": ""},
    { "tool_name": "list-mcp-tool-groups" , "tool_description": ""},
    { "tool_name": "list-sessions"			  ,	"tool_description": ""},
    { "tool_name": "list-status"				  ,	"tool_description": ""},
    { "tool_name": "close-all-danger"			  ,	"tool_description": ""}
];

const base_url = '<%=url_base%>'

//const jsonString = JSON.stringify(toolConfiguration, null, 2);

let url_opts = '';
//'<option value="">Select Menu Item</option>';

for (const tool of toolList) {
  const full_url = base_url + '/' + tool.tool_name;
  url_opts += '<option value="' + full_url +'">'+tool.tool_name+'</option>';
}

document.getElementById('mySelectApi').innerHTML = url_opts;

</script>


<script>

function getHeaders() {

/*	
const myDefHeaders = {
	'Accept': '* / *',
	//'Origin': 'http://127.0.0.1:8080',
	'Content-Type': 'application/json'
};
*/

//console.log('Hdrs 0 :', myDefHeaders);

const headersArr = new Headers();
headersArr.append("Accept", "*/*");
headersArr.append("Content-Type", "application/json")
//headersArr.append("Origin", "http://127.0.0.1:8080")

//console.log('Hdrs Basic :');
//console.log(new Map(headersArr));

const usrhdrs = document.getElementById('agentprojhdrs').value;
const usrhdrsobj = JSON.parse(usrhdrs);

//console.log('Hdrs Auth :');
//console.log(usrhdrsobj);

Object.entries(usrhdrsobj).forEach(([key, value]) => {
    headersArr.append(key, value);
});

//console.log('Hdrs Added :');
//console.log(new Map(headersArr));

//const inputKeyValArr = Object.entries(usrhdrsobj);

/*
        for (const key in usrhdrsobj) {
            if (Object.hasOwnProperty.call(usrhdrsobj, key)) {

			headersArr.append(key, usrhdrsobj[key]);

            }
        }
*/

return headersArr;

}


async function postData() {

    var apiEndpoint = document.getElementById('mySelectApi').value;
	console.log('Got Url:', apiEndpoint);

	const addHdrs = getHeaders();

    try {

		var response = '';

        response = await fetch(apiEndpoint, {
            method: 'GET', 
			headers: addHdrs
            //headers: {
			//	'accept': '*/*',
            //    'Content-Type': 'application/json' 
            //}
        });


        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.text();

		
		  try {
			const jsonData = JSON.parse(result);
			document.getElementById('responseArea').textContent = JSON.stringify(jsonData, null, 2);
		  } catch (err) {
			document.getElementById('responseArea').textContent = result;
		  }

          //console.log('Success:', result);

    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}


async function postDataProj() {


    const apiProjEndpoint = '<%=url_base%>/list-mcp-filter-applied-proj-tools';

	const apiUrl = new URL(apiProjEndpoint);

	console.log('<%=projParam%>');
	
	const params = new URLSearchParams('<%=projParam%>');
	//const finalUrl = `${apiProjEndpoint}?${params.toString()}`;
	apiUrl.search = params.toString();

	//console.log(apiUrl.toString());

	const addHdrs = getHeaders();

    try {

		var response = '';

        response = await fetch(apiUrl, {
            method: 'GET', 
			headers: addHdrs
            //headers: {
			//	'accept': '*/*',
            //    'Content-Type': 'application/json' 
            //}
        });


        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.text();

		
		  try {
			const jsonData = JSON.parse(result);
			document.getElementById('responseArea').textContent = JSON.stringify(jsonData, null, 2);
		  } catch (err) {
			document.getElementById('responseArea').textContent = result;
		  }

          //console.log('Success:', result);

    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}

</script>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

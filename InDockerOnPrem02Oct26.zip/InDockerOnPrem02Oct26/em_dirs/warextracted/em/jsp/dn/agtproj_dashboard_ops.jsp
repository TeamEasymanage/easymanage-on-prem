<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	wp.processRequest_gen(request, response);
	get_gui_str(wp.gui_str);


%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> AI Agents Ops</title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 8;
	mnu2_sel = 0;
	String usrnm = wp.usrnm;
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;

%>
<%@ include file="../pre_dn_sm.jsp" %>

	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	%>

<style>
.btn {
margin: 2px;
}
</style>

	<%= bfont %> <b>AI Agents Ops</b></font>
	<br><br>

<%
	String[] agtSvrConf = wp.getAgtSvrConf();
	String conf_id = agtSvrConf[0];
	String url_base = agtSvrConf[1];
	String api_hdrs = agtSvrConf[2];
	String rd_only = agtSvrConf[3];

	String no_disp_hdrs = "";
	if (app_run == 1) {
		no_disp_hdrs = " style=\"display:none;\" ";
	}
	
	//String modelOpts = wp.getOptRunModels();
	// gets "<select  id=\"runWithModel\" name=runWithModel> "+"\n"+


%>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="2"> <%=bfont%> <b>Agent Run Ops</b></font>
	<%=bfont1%> 
	</font>
</td>
<td colspan="3"> <%=bfont%> <b>Usage</b></font>
	<%=bfont1%> 
	</font>
</td>
</tr>


	<tr bgcolor="EFEFEF">
<td><%=bfont%> API Endpoint </font></td>
<td><%=bfont%> 
	<input type="text" id="apiEndpointVal" value="<%=url_base%>/list-status" size="50"   maxlength="100" >
    <%-- <input type="text" id="apiEndpointVal" value="http://127.0.0.1:9030/agentserver/agent/list-status" size="50"   maxlength="100"> --%>
	<br><br>
	Headers: 
<textarea id="agentprojhdrs" rows="1" cols="40"  <%=rd_only%> <%=no_disp_hdrs%> >
<%=api_hdrs%>
</textarea>
	
</font></td>
<td><%=bfont%> GET Endpoints </font></td>
	<td> list-sessions | list-status | close-all-danger </td>
	<td> No parameters </td>
	</tr>
	<tr bgcolor="EFEFEF">
<td><%=bfont%> Parameter: executionId </font></td>
<td><%=bfont%> 
    <input type="text" id="executionId" value="" size="40"   maxlength="100">
</font></td>
<td><%=bfont%> GET Endpoints </font></td>
	<td> status | restore-points | cancel | close </td>
	<td> Parameter: executionId </td>
	</tr>
	<tr bgcolor="EFEFEF">
<td><%=bfont%> Request Body </font></td>
<td><%=bfont%> 
<textarea id="reqbody" rows="1" cols="50">
</textarea>
</font></td>
<td></td>
<td></td>
<td></td>
<%--
<td><%=bfont%> POST Endpoints </font></td>
	<td> approve | reject </td>
	<td> Parameter: executionId <br>
	Request Body: <br>
	{
  "approved": true,
  "reason": "string"
	}
	</td>
--%>

	</tr>
	<tr bgcolor="EFEFEF">
<td><%=bfont%>  </font></td>
<td><%=bfont%> 
	<select id="apiOpt">
		<option>GET</option>
		<option disabled>POST</option>
	</select>
	&nbsp;&nbsp;
    <button onclick="postData()">Execute</button>

</font></td>
<td></td>
<td></td>
<td></td>
<%--
<td><%=bfont%> POST Endpoints </font></td>
	<td> restore </td>
	<td> Parameter: executionId <br>
	Request Body: <br>
	{
	  "stepIndex": 0,
	  "reExecute": true
	}
	<br>
	Note: stepIndex is stepNumber - 1
	</td>
--%>
	</tr>

	</table> 


	<%=bfont%> <b>Response: </b><br>
    <pre id="responseArea"></pre>

<script>

function getHeaders() {

/*	
const myDefHeaders = {
	'Accept': '* / *',
	//'Origin': 'http://127.0.0.1:8080',
	'Content-Type': 'application/json'
};
*/

//console.log('Hdrs 0 :', myDefHeaders);

const headersArr = new Headers();
headersArr.append("Accept", "*/*");
headersArr.append("Content-Type", "application/json")
//headersArr.append("Origin", "http://127.0.0.1:8080")

//console.log('Hdrs Basic :');
//console.log(new Map(headersArr));

const usrhdrs = document.getElementById('agentprojhdrs').value;
const usrhdrsobj = JSON.parse(usrhdrs);

//console.log('Hdrs Auth :');
//console.log(usrhdrsobj);

Object.entries(usrhdrsobj).forEach(([key, value]) => {
    headersArr.append(key, value);
});

//console.log('Hdrs Added :');
//console.log(new Map(headersArr));

//const inputKeyValArr = Object.entries(usrhdrsobj);

/*
        for (const key in usrhdrsobj) {
            if (Object.hasOwnProperty.call(usrhdrsobj, key)) {

			headersArr.append(key, usrhdrsobj[key]);

            }
        }
*/

return headersArr;

}


async function postData() {
    const textarea = document.getElementById('reqbody');
    var dataToSend = textarea.value;
    var executionId = document.getElementById('executionId').value;

	/*
    try {
        JSON.parse(dataToSend);
    } catch (e) {
        document.getElementById('responseArea').textContent = 'Error: Invalid JSON format in the textarea.';
        return;
    }
	*/

    var apiOpt = document.getElementById('apiOpt').value;
    var apiEndpoint = document.getElementById('apiEndpointVal').value;
	console.log('Got Url:', apiEndpoint);
    //const payload = {
    //    content: dataToSend
    //};

	const addHdrs = getHeaders();

    try {

		var response = '';
		if (apiOpt == 'GET') {
			apiEndpoint = apiEndpoint + '?executionId=' + executionId;

        response = await fetch(apiEndpoint, {
            method: 'GET', 
			headers: addHdrs
            //headers: {
			//	'accept': '*/*',
            //    'Content-Type': 'application/json' 
            //}
        });

		} else {

		const url = new URL(apiEndpoint);

		const parameters = {
		  executionId: executionId
		};

		Object.entries(parameters).forEach(([k, v]) => url.searchParams.append(k, v));
		console.log(url);
		
		//url.searchParams = new URLSearchParams(parameters).toString();

        response = await fetch(url, {
            method: 'POST', 
			headers: addHdrs,
            //headers: {
			//	'accept': '*/*',
            //    'Content-Type': 'application/json' 
            //},
            body: dataToSend
        });
		
		}

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}

</script>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

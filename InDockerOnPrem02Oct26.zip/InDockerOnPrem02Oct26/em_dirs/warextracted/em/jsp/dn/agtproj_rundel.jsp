<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="tbde" scope="page" class="em.Agtproj_runsave" />
<%
	tbde.processRequest(request, response);
	get_gui_str(tbde.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = tbde.emerr;
	valid_login = tbde.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Run Delete  </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = tbde.usrnm;
	usrnm_as = tbde.usrnm_as;
	usrnm_si = tbde.usrnm_si;
	datagrp = tbde.datagrp;
%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=tbde.categ_name%></b></font></font></td>
</td>
</tr>
</table>
<BR>


<% if ( tbde.attempt == 0) { %>

	<%-- Display Form --%>
	<% tbde.doFormRunDel(request); %>

	<%=bfont%> 
<% if ( tbde.wp_stat ==1) { %>

	<%=bfont%> <b>Delete Agent Run Records: Confirm ? </b></font><br><br>

<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="13"> <%=bfont%> <b>Agent Run Details</b></font>
</td>
</tr>

<tr bgcolor="EFEFEF" align="center">
<td><%=bfont1%> </font></td>
<td><%=bfont1%> Proj #</font></td>
<td> <%=bfont1%> Agent/Task Name</font></td>
<td> <%=bfont1%> Session Id</font></td>
<td> <%=bfont1%> User Si</font></td>
<td> <%=bfont1%> Datagrp</font></td>
<td> <%=bfont1%> Saved</font></td>
</tr>

	<%-- Categories --%>
	<%=tbde.doCategRowForDel()%>


<% } else { %>

	 <%=bfont%> <font color="FF0000">
	 <br><br>
	 No Agent Run Data Details found. 
	 <br><br>
	     </font></font>
<% } %>


<% tbde.doneRequest(); %>

<% } else {  %>

	<%=bfont%> <b>Deleting Record: </b></font><br><br>

	<%-- Do Data Action --%>

	<% tbde.doDbDataRunDel(request); %>

	<% if (tbde.dodb_stat >= 1) { %>
		<BR> <%=bfont %>
		Record Deleted, Done.
		</font><br>

	<% } else { %>
		<BR> <%=bfont %> <font color="FF0000">
		Error: Record Delete Failed.
		</font></font><br>
	<% } %>
	<% tbde.doneRequestDel(); %>

<% } // elseofif ( tbde.attempt == 0) %>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj_runsave" />
<%
	if (app_run == 1) {
	wp.setApFlg();
	}
	wp.processRequest(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Run Data Detail Options All Tasks</title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

	if (app_run == 1) {
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	}

	String inclPrompt = "" + request.getParameter("inclPrompt");
	inclPrompt = inclPrompt.replace("null","");
	
%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wp.categ_name%></b></font></font></td>
</td>
</tr>
</table>

	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String SendToUrlwpsc = "/"+usrproj+"/jsp/dn/agtproj.jsp?usrnm="+wp.usrnm +"&categ_id="+wp.categ_id+"&categ_name="+wp.categ_name+"&categ_levels="+wp.categ_levels+"&routeto="+wp.routeto+"&tm_now="+tm_now; 
	%>

	<%= bfont %> <b> Agent Run Data Details - For All Task </b></font><br><br>

	<% wp.doGetRunDataDetails_Agt(request); %>
	
	<%=bfont%> 
<% if ( wp.wp_stat ==1) { %>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="13"> <%=bfont%> <b>Agent Run Details  - For Task</b></font>
</td>
</tr>

<tr bgcolor="EFEFEF" align="center">
<td><%=bfont1%> </font></td>
<td><%=bfont1%> Proj #</font></td>
<td> <%=bfont1%> Agent/Task Name</font></td>
<td> <%=bfont1%> Session Id</font></td>
<td> <%=bfont1%> Run Save Id</font></td>
<td> <%=bfont1%> Step No</font></td>
<td> <%=bfont1%> Task Status</font></td>
<td> <%=bfont1%> Is Last Step</font></td>
<td> <%=bfont1%> User Si</font></td>
<td> <%=bfont1%> Datagrp</font></td>
<td> <%=bfont1%> Saved</font></td>
</tr>

<tr>
<td colspan=4></td>
<td colspan=7>
<%@ include file="agtproj_runimp_chart01.jsp" %>
</td>
</tr>
	<%-- Categories --%>
	<%=wp.doCategRowDetTaskAll(inclPrompt)%>
	<% while (wp.moreCategDet() ==1) { %>
		<%=wp.doCategRowDetTaskAll(inclPrompt)%>
	<% } %>

	</table> 

<%@ include file="agtproj_runimp_chart02.jsp" %>

<% } else { %>

	 <%=bfont%> <font color="FF0000">
	 <br><br>
	 No Agent Run Data Details found. 
	 <br><br>
	     </font></font>
<% } %>


<% wp.doneRequest(); %>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>

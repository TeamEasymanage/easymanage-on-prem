<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

	&nbsp;&nbsp;  <button id="viewCopy" onclick="copyClip()" >
	<i class="fa fa-copy" title="Copy to Clipboard."></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewHtml" onclick="showAsHtml()" >
	<i class="fa fa-down-arrow" title="Show response as Html, then Download PDF, Print or Save. "> &#x1F4C4;</i>
	</button> 
	&nbsp;&nbsp;  <button id="viewMd" onclick="showAsMd()" >
	<i class="fa fa-file-o" title="Show response with Text or Markdown as Html, then Download PDF, Print or Save."> Md</i>
	</button> 
	&nbsp;&nbsp;  <button id="viewMermaid" onclick="showAsMermaid()" >
	<i class="fa fa-bar-chart" title="Show response with Mermaid as Diagram. Use prompt like 'Generate Mermaid Diagram Code'. "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewChartJs" onclick="showAsChartJs()" >
	<i class="fa fa-line-chart" title="Show response with chart.js as Diagram. Use prompt like 'Generate bar chart code snippet part for chart.js in format: new Chart(ctx,{ ... }); '  "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewCsv" onclick="showAsCsv()" >
	<i class="fa fa-tasks" title="Show response with CSV as Html. Use prompt like 'Return response in CSV format.' "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewExcel" onclick="dnldAsExcel()" >
	<i class="fa fa-table" title="Response with CSV, Download as Excel. "></i>
	</button> 

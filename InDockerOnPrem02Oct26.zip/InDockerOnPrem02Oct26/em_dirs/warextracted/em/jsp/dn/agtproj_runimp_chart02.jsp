<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<script>

	const body_str = 
	'<style> \n' +
	' * {font-family: \'Verdana\'; font-size: 10px; } \n' +
		'table { border-collapse: collapse; }  \n' +
		'table,th,tr,td { border: 1px solid #ccc; } \n' +
	'</style><body> \n';
	
	const dnldPdf_src = '\n' +
		'<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"><\/script>\n' +
		'\n'
		;
		
	const dnldPdf_btn = '\n' +
		'<button title="Download as PDF" onclick="downloadPDF_P()">PDF &#x1F4C4; &#x2193; </button>\n' +
		'&nbsp; &nbsp;'+
		'\n'+
		'<button title="Download as PDF" onclick="downloadPDF_L()">PDF <span style="display: inline-block; transform: rotate(90deg); margin-right: 6px;">&#x1F4C4;</span> &#x2193;  </button>\n' +
		'&nbsp; &nbsp;'+
		'\n'+
		'&nbsp; &nbsp;'+
		'<button onclick="window.print()">Print &#128424; </button>\n' +
		'\n'+
		'<button id="customSaveBtn" title="Save Page" onclick="saveHtml()" >Save &#x1F4BE; </button>\n' +
		'\n'
		;

	const dnldPdf_func = '\n' +
		'<script>\n' +
		'function downloadPDF_P() { \n' +
		'const elementData = document.getElementById(\'htmlContent\'); \n' +
		'const options = { \n' +
		'	margin:       [10, 5, 10, 5], \n' +
		'	filename:     \'htmlContent.pdf\', \n' +
		'	image:        { type: \'jpeg\', quality: 0.98 }, \n' +
		'	html2canvas:  { scale: 1 }, \n' +
		'	jsPDF:        { unit: \'mm\', format: \'a4\', orientation: \'portrait\' } \n' +
		'	}; \n' +
		' \n' +
		'html2pdf().set(options).from(elementData).save(); \n' +
		'} \n' +
		'\n' +
		'function downloadPDF_L() { \n' +
		'const elementData = document.getElementById(\'htmlContent\'); \n' +
		'const options = { \n' +
		'	margin:       [10, 5, 10, 5], \n' +
		'	filename:     \'htmlContent.pdf\', \n' +
		'	image:        { type: \'jpeg\', quality: 0.98 }, \n' +
		'	html2canvas:  { scale: 1 }, \n' +
		'	jsPDF:        { unit: \'mm\', format: \'a4\', orientation: \'landscape\' } \n' +
		'	}; \n' +
		' \n' +
		'html2pdf().set(options).from(elementData).save(); \n' +
		'} \n' +
		'<\/script>\n' +
		'\n'+
        '<script> \n' +
		'\n' +
		'function saveHtml() { \n' +
        '        const htmlMarkup = document.documentElement.outerHTML; \n' +
        '        const blob = new Blob([htmlMarkup], { type: \'text/html;charset=utf-8\' }); \n' +
        '        const fileUrl = URL.createObjectURL(blob); \n' +
        '         \n' +
        '        const hiddenLink = document.createElement(\'a\'); \n' +
        '        hiddenLink.href = fileUrl; \n' +
        '        hiddenLink.download = \'generated-report.html\'; \n' +
        '        hiddenLink.click(); \n' +
        '         \n' +
        '        URL.revokeObjectURL(fileUrl); \n' +
		'} \n' +
		'\n' +
        '<\/script> \n' +
		''
		;


function copyClip() { 
	const copyText = document.getElementById("responseStep").innerText; 
	navigator.clipboard.writeText(copyText); 

}

</script>

<script>
function showAsHtml() {

    //const diagHtml = document.getElementById('responseStep').textContent;
    const diagHtml = document.getElementById('responseStep').innerHTML;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const viewHtml = '<html>\n' +
		body_str +
		'\n' +
		dnldPdf_src +
		'\n' +
		dnldPdf_btn +
		'\n' +
		dnldPdf_func +
		'\n' +
		'  <hr>\n' +
		'<pre id="htmlContent">\n' +
		diagHtml +
		'</pre>\n' +
		'</body>\n' +
		'</html>';
		;


	//console.log(viewHtml);

	const newWin = window.open("", "_blank", "width=600,height=400");
	//window.open("", "_blank");
    newWin.document.open();
    newWin.document.write(viewHtml);
    newWin.document.close();
	console.log("done");


}
</script>


<script>
function showAsMermaid() {

    const diagHtml = document.getElementById('responseStep').textContent;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const viewHtml = '<html>\n' +
		body_str +
		'  <script type="module">\n' +
		'    import mermaid from "https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.esm.min.mjs"; \n' +
		'  <\/script>\n' +
		'\n' +
		dnldPdf_src +
		'\n' +
		dnldPdf_btn +
		'\n' +
		dnldPdf_func +
		'\n' +
		'  <hr>\n' +
		' <div id="htmlContent">\n' +
		'  <pre class="mermaid">\n' +
		diagHtml + '\n' +
		'  </pre>\n' +
		' </div>\n' +
		'</body>\n' +
		'</html>';

	//console.log(viewHtml);

	const newWin = window.open("", "_blank", "width=600,height=500");
    newWin.document.open();
    newWin.document.write(viewHtml);
    newWin.document.close();
	console.log("done");
}
</script>

<script>
function showAsChartJs() {

    const diagHtml = document.getElementById('responseStep').textContent;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const viewHtml = '<html>\n' +
		body_str +
		' <script src="https://cdn.jsdelivr.net/npm/chart.js"><\/script>\n' +
		'\n' +
		dnldPdf_src +
		'\n' +
		dnldPdf_btn +
		'\n' +
		dnldPdf_func +
		'\n' +
		'  <hr>\n' +
		'<div id="htmlContent" style="width: 600px; height: 400px;">\n' +
		'	<canvas id="myBarChart"></canvas>\n' +
		'</div>\n' +
		'<script>\n' +
        'const ctx = document.getElementById(\'myBarChart\').getContext(\'2d\');\n' +
        'const myBarChart = \n' +
		diagHtml + '\n' +
		'<\/script>\n' +
		'</body>\n' +
		'</html>';

	//console.log(viewHtml);

	const newWin = window.open("", "_blank", "width=600,height=400");
    newWin.document.open();
    newWin.document.write(viewHtml);
    newWin.document.close();
	console.log("done");
}
</script>

<script>
function showAsMd() {

    //const diagHtml = document.getElementById('responseStep').textContent;
    const diagHtml = document.getElementById('responseStep').innerHTML;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const viewHtml = '<html>\n' +
		body_str +
		' <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"><\/script>\n' +
		'\n' +
		dnldPdf_src +
		'\n' +
		dnldPdf_btn +
		'\n' +
		dnldPdf_func +
		'\n' +
		'<pre id="respCopyArea" style="display: none;">\n' +
		diagHtml +
		'</pre>\n' +
		'  <hr>\n' +
		'<div id="htmlContent"></div>\n' +
		'<script>\n' +
		'const mdText = document.getElementById(\'respCopyArea\').innerHTML; \n' +
		'const mdOutput = marked.parse(mdText);'+'\n' +
		' document.getElementById(\'htmlContent\').innerHTML = mdOutput;'+'\n' +
		'<\/script>\n' +
		'</body>\n' +
		'</html>';

	//console.log(viewHtml);

	const newWin = window.open("", "_blank", "width=600,height=400");
    newWin.document.open();
    newWin.document.write(viewHtml);
    newWin.document.close();
	console.log("done");
}
</script>


<script>
function showAsCsv() {

    const diagHtml = document.getElementById('responseStep').textContent;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const csvData = diagHtml;
    const rows = csvData.trim().split('\n');
    let html = 
	'<style> \n'+
	'table, th, td { \n'+
	'  border: 1px solid black; \n'+
	'} \n'+
	'th { \n'+
	'  background-color: #DEDEDE; \n'+
	'} \n'+
	'th, td { \n'+
	'  padding: 4px; \n'+
	'} \n'+
	'table { \n'+
	'  border-collapse: collapse; \n'+
	'  width: 100%; \n'+
	'} \n'+
	'<\/style> \n'+
	'<div id="htmlContent">\n' +
	'<table> \n';

    rows.forEach((row, index) => {
        const cells = row.split(',');
        html += '\n<tr>';
        cells.forEach(cell => {
            // Use <th> for the first row as headers, <td> for others
            const tag = index === 0 ? 'th' : 'td';
            html += '<'+tag+'>'+cell.trim()+'</'+tag+'> \n';
        });
        html += '\n</tr>';
    });

    html += '\n</table>\n';

    html += '</div>\n' ;

	//console.log(html);

	const viewHtml = '<html>\n' +
		body_str +
		'\n' +
		dnldPdf_src +
		'\n' +
		dnldPdf_btn +
		'\n' +
		dnldPdf_func +
		'\n' +
		'  <hr>\n' +
		html +'\n' +
		'</body>\n' +
		'</html>';

	//console.log(viewHtml);

	const newWin = window.open("", "_blank", "width=600,height=400");
    newWin.document.open();
    newWin.document.write(viewHtml);
    newWin.document.close();
	console.log("done");
}
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>

<script>
function dnldAsExcel() {

    const diagHtml = document.getElementById('responseStep').textContent;
	//console.log(diagHtml);

	if (diagHtml && diagHtml.trim().length > 0) {
		//console.log("Content is not empty:", diagHtml);
	} else {
		console.log("Content is empty or whitespace");
		return;
	}

	const csvSrc = diagHtml;
    const rows = diagHtml.trim().split('\n');

	const csvData = rows.map(row => row.split(',').map(cell => cell.trim()));

   
    const wb = XLSX.utils.book_new();
	const ws = XLSX.utils.aoa_to_sheet(csvData);
	
    XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
    
    XLSX.writeFile(wb, "dataContent.xlsx");

	console.log("done");
}
</script>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	if (app_run == 1) {
	wp.setApFlg();
	}
	wp.processRequest_gen(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Server Log </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

	if (app_run == 1) {
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	}

%>
<%@ include file="../pre_dn_sm.jsp" %>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="4"> <%=bfont%> <b>Agent Server Log</b></font>
	<%=bfont1%> 
	</font>
</td>
</tr>

<%
	String[] agtSvrConf = wp.getAgtSvrConf();
	String conf_id = agtSvrConf[0];
	String url_base = agtSvrConf[1];
	String api_hdrs = agtSvrConf[2];
	String rd_only = agtSvrConf[3];

	String no_disp_hdrs = "";

	String modelOpts = wp.getOptRunModels();
	// gets "<select  id=\"runWithModel\" name=runWithModel> "+"\n"+


%>

	<tr>

	<tr>
<td><%=bfont%> 
    <button id="chat_start" onclick="showLog()">Show Log</button>
	<br><br>

<%@ include file="agtproj_run_spin_ins01.jsp" %>

</font></td>

<td bgcolor="EFEFEF"><%=bfont%> API Endpoint <br>Headers </font></td>
<td bgcolor="EFEFEF"><%=bfont%> 
   <input type="text" id="apiEndpointVal" value="<%=url_base%>/showlogend" size="50"   maxlength="100" readOnly >
	<br>
<textarea id="agentprojhdrs" rows="1" cols="40"  <%=rd_only%> <%=no_disp_hdrs%> >
<%=api_hdrs%>
</textarea>

</font></td>
	</tr>
	</table>

	<%=bfont%> <b>Agent & Chat Run Server Log: </b> 
	<i class="fa fa-info-circle" title="Log viewing can be disabled in the application properties. To see more lines or full log file, use Agent Svr Swagger endpoints."></i>
	(Last 2000 lines)

<%@ include file="agtproj_runimp_chart01.jsp" %>

	<br>
    <pre id="responseStep"></pre>
	<br>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>


<script>

function getHeaders() {

//console.log('Hdrs 0 :', myDefHeaders);

const headersArr = new Headers();
headersArr.append("Accept", "*/*");
headersArr.append("Content-Type", "application/json")
//headersArr.append("Origin", "http://127.0.0.1:8080")

const usrhdrs = document.getElementById('agentprojhdrs').value;
const usrhdrsobj = JSON.parse(usrhdrs);

//console.log('Hdrs Auth :');
//console.log(usrhdrsobj);

Object.entries(usrhdrsobj).forEach(([key, value]) => {
    headersArr.append(key, value);
});

//console.log(headersArr);

return headersArr;

}

async function showLog() {


	const spinner = document.getElementById('loading-spinner');

    const apiEndpoint = document.getElementById('apiEndpointVal').value;
	console.log('Got Url:', apiEndpoint);
    //const payload = {
    //    content: dataToSend
    //};

	const apiExecUrl = new URL(apiEndpoint);

	const addHdrs = getHeaders();

    try {

		spinner.style.display = 'block'; 		
		
        const response = await fetch(apiExecUrl, {
            method: 'GET', 
			headers: addHdrs
        });


		const logTerminal = document.getElementById("log-terminal");

        if (!response.ok) {

			const statusCode = response.status; 
			  
			const errorBody = await response.text(); 

			const gotErr = 'Error: ' + statusCode + ' ' + errorBody;
			  
			document.getElementById('responseStep').textContent = gotErr;
			console.error(gotErr);

			throw new Error(`Error ${statusCode}: ${errorBody}`);
            //throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.text();
        document.getElementById('responseStep').textContent = result;
        //console.log('Success:', result);

		/*
		const reader = response.body.pipeThrough(new TextDecoderStream()).getReader();

		while (true) {
			const { value, done } = await reader.read();
			if (done) break;

			// Process the raw text chunks into standard SSE event lines
			const lines = value.split('\n');
			for (const line of lines) {
				if (line.startsWith('data:')) {
					const data = line.replace('data:', '').trim();
					console.log("Received data:", data);

					logTerminal.innerText += data + "\n"; 
					// Auto-scroll to the bottom of the log container
					logTerminal.scrollTop = logTerminal.scrollHeight;

				}
			}
		}
		*/

    } catch (error) {
        //document.getElementById('responseStep').textContent = 'Error: ' + error.message;
        console.error(error);
	} finally {
		spinner.style.display = 'none';
    }

	/*
    const eventSource = new EventSource(apiEndpoint);

    eventSource.onmessage = function(event) {
        // Append log line and add a line break
        logTerminal.innerText += event.data + "\n"; 
        // Auto-scroll to the bottom of the log container
        logTerminal.scrollTop = logTerminal.scrollHeight;
    };

    eventSource.onerror = function() {
        console.log("Log stream disconnected or file rotated.");
    };
	*/

}

</script>

<%@ include file="agtproj_runimp_chart02.jsp" %>

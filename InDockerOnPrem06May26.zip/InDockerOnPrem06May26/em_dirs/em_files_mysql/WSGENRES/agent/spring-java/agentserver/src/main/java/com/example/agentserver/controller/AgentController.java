package com.example.agentserver.controller;

import com.example.agentserver.service.AgentExecutionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;

import com.example.agentserver.model.AgentModels.AgentProj;
import com.example.agentserver.model.AgentModels.AgentTask;
import com.example.agentserver.model.AgentModels.AgentStartRequest;
import com.example.agentserver.model.AgentModels.ChatRequest;
import com.example.agentserver.model.AgentStepResponse;
import com.example.agentserver.model.ApprovalRequest;
import com.example.agentserver.model.AgentStatusResponse;
import com.example.agentserver.model.AgentExecution;
import com.example.agentserver.model.RestoreRequest;
import com.example.agentserver.model.RestorePoint;
import com.example.agentserver.model.RestorePointsResponse;

@CrossOrigin  
@RestController
@RequestMapping("/agentserver/agent")
public class AgentController {
    
    private final AgentExecutionService executionService;
    
    public AgentController(AgentExecutionService executionService) {
        this.executionService = executionService;
    }
    
    /*
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("Agent API is running");
    }
    */

    @GetMapping("/list-mcp-all-tools")
    public ResponseEntity<String> listTools() {

        String toolsList = executionService.listTools();
        return ResponseEntity.ok(toolsList);
    }

    @GetMapping("/list-mcp-server-wise-tools")
    public ResponseEntity<String> listMcpWiseTools() {

        String mcpToolsList = executionService.listMcpWiseTools();
        return ResponseEntity.ok(mcpToolsList);
    }

    // ========== Human-in-the-Loop Approval Endpoints ==========
    
    @PostMapping("/start")
    public ResponseEntity<AgentStepResponse> startAgent(
            @RequestParam(name = "switchModel", defaultValue = "") String switchModel,
            @RequestBody AgentStartRequest agentStartRequest) {

        /*
        if (request.getInput() == null || request.getInput().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        */
        if (agentStartRequest.agentTasks().length == 0 || agentStartRequest.agentTasks()[0].inputPrompt().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        try {

            /*
            String[] prompts = null;
            if (request.getSystemPrompts() != null && !request.getSystemPrompts().isEmpty()) {
                prompts = request.getSystemPrompts().toArray(new String[0]);
            }
            */

            AgentStepResponse response = startAgentInt(agentStartRequest, switchModel);
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public AgentStepResponse startAgentInt(
            AgentStartRequest agentStartRequest,
            String switchModel
            ) {

            AgentExecution execution = executionService.startAgent(
                                        agentStartRequest,
                                        switchModel);
            
            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                execution.getTaskId(), // for currentStep
                execution.getCurrentStep(),
                execution.getCurrentStepResult(),
                execution.getStatus().name(),
                true,
                execution.isLastStep()
            );
            response.setMessage("Step " + execution.getCurrentStep() + " completed. Awaiting approval.");
            
            return response;
    }

    @PostMapping("/approve")
    public ResponseEntity<AgentStepResponse> approveStep(
            @RequestParam String executionId,
            @RequestBody ApprovalRequest approvalRequest) {
        
        try {
            
            AgentStepResponse response = approveStepInt(
            executionId,
            approvalRequest);
            
            return ResponseEntity.ok(response);
        } catch (IllegalStateException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public AgentStepResponse approveStepInt(
            String executionId,
            ApprovalRequest approvalRequest) {
        
            AgentExecution execution = executionService.approveStep(executionId);
            
            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                execution.getTaskId(), // for currentStep
                execution.getCurrentStep(),
                execution.getCurrentStepResult(),
                execution.getStatus().name(),
                execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL,
                execution.isLastStep()
            );
            
            if (execution.getStatus() == AgentExecution.Status.COMPLETED) {
                response.setMessage("Agent completed successfully.");
                response.setStepResult(execution.getFinalOutput());
            } else {
                response.setMessage("Step " + execution.getCurrentStep() + " completed. Awaiting approval.");
            }
            
            return response;
    }

    @PostMapping("/runchat")
    public ResponseEntity<AgentStepResponse> runChat(
            @RequestParam String executionId,
            @RequestBody ChatRequest chatRequest) {
        
        try {
            
            AgentStepResponse response = runchatStepInt(
            executionId,
            chatRequest);
            
            return ResponseEntity.ok(response);
        } catch (IllegalStateException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public AgentStepResponse runchatStepInt(
            String executionId,
            ChatRequest chatRequest) {
        
            AgentExecution execution = executionService.chatRun(executionId, chatRequest);
            
            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                execution.getTaskId(), // for currentStep
                execution.getCurrentStep(),
                execution.getCurrentStepResult(),
                execution.getStatus().name(),
                execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL,
                execution.isLastStep()
            );
            
            if (execution.getStatus() == AgentExecution.Status.COMPLETED) {
                response.setMessage("Agent completed successfully.");
                response.setStepResult(execution.getFinalOutput());
            } else {
                response.setMessage("Step " + execution.getCurrentStep() + " completed. Awaiting approval.");
            }
            
            return response;
    }

    // ====== Use when autoApprYN = Yes (i.e. skip HITL)

    @PostMapping("/run-full")
    public ResponseEntity<List<AgentStepResponse>> runFullAgent(
            @RequestParam(name = "switchModel", defaultValue = "") String switchModel,
            @RequestBody AgentStartRequest agentStartRequest) {

        /*
        if (request.getInput() == null || request.getInput().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        */
        if (agentStartRequest.agentTasks().length == 0 || agentStartRequest.agentTasks()[0].inputPrompt().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }
        
        List<AgentStepResponse> responses = new ArrayList<>();

        try {

            /*
            String[] prompts = null;
            if (request.getSystemPrompts() != null && !request.getSystemPrompts().isEmpty()) {
                prompts = request.getSystemPrompts().toArray(new String[0]);
            }
            */

            AgentStepResponse response = startAgentInt(agentStartRequest, switchModel);
            responses.add(response);

            int countTasks = agentStartRequest.agentTasks().length;
            ApprovalRequest autoApprove = new ApprovalRequest( true, "Auto_Approved");
            // task 0 is executed in startWkfl
            for (int i=0; i < (countTasks-1); i++) {
                // stepIndex will be i-1
                AgentStepResponse response1 = approveStepInt(
                response.getExecutionId(),
                autoApprove);
                responses.add(response1);
            }

            return ResponseEntity.ok(responses);
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PostMapping("/reject")
    public ResponseEntity<AgentStepResponse> rejectStep(
            @RequestParam String executionId,
            @RequestBody ApprovalRequest approvalRequest) {
        
        try {
            AgentExecution execution = executionService.rejectStep(
                executionId, 
                approvalRequest.getReason()
            );
            
            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                execution.getTaskId(), // for currentStep
                execution.getCurrentStep(),
                execution.getCurrentStepResult(),
                execution.getStatus().name(),
                false,
                false
            );
            response.setMessage("Step rejected: " + 
                (execution.getRejectionReason() != null ? execution.getRejectionReason() : "No reason provided"));
            
            return ResponseEntity.ok(response);
        } catch (IllegalStateException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @GetMapping("/status")
    public ResponseEntity<AgentStatusResponse> getStatus(
            @RequestParam String executionId) {
        try {
            
            AgentStatusResponse response = getStatusInt(
            executionId);
           
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    public AgentStatusResponse getStatusInt(
            String executionId) {

            AgentExecution execution = executionService.getExecution(executionId);
            
            AgentStatusResponse response = new AgentStatusResponse();
            response.setExecutionId(execution.getExecutionId());
            response.setStatus(execution.getStatus().name());
            response.setCurrentStep(execution.getCurrentStep());
            response.setTotalSteps(execution.getInputPrompts().length + 1); // +1 for input step
            response.setStepResults(execution.getStepResults());
            response.setFinalOutput(execution.getFinalOutput());
            response.setCreatedAt(execution.getCreatedAt());
            response.setUpdatedAt(execution.getUpdatedAt());
            response.setRejectionReason(execution.getRejectionReason());
            response.setRequiresApproval(execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL);
            
            return response;
    }

    @GetMapping("/step-results")
    public ResponseEntity<List<AgentStepResponse>> getStepResults(
            @RequestParam String executionId) {
        try {
            
        List<AgentStepResponse> responses = new ArrayList<>();

            AgentExecution execution = executionService.getExecution(executionId);

            int noOfResults = execution.getStepResults().size();

            if (noOfResults == 0) {
                throw new IllegalArgumentException("No step results found.");
            }

            for (int i = 0; i < (noOfResults-1); i++) {

            int currentStep = i + 1;
            String stepResult = execution.getStepResults().get(i+1);
            String taskId = execution.getAgentTasks()[i].taskId();
            boolean isLastStep = false;

            if(i == (noOfResults-2) ) {
                isLastStep = true;
            }

            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                taskId, // for currentStep
                currentStep,
                stepResult,
                execution.getStatus().name(),
                execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL,
                isLastStep, //execution.isLastStep()
                execution.getInputPrompts()[currentStep - 1] // Add the step prompt
            );

            response.setMessage("Step completed.");

            /*
            if (execution.getStatus() == AgentExecution.Status.COMPLETED) {
                response.setMessage("Agent completed successfully.");
            } else {
                response.setMessage("Step " + currentStep + " completed. Awaiting approval.");
            }
            */

            responses.add(response);

            } //for

            return ResponseEntity.ok(responses);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/close")
    public ResponseEntity<Boolean> closeAgent(
            @RequestParam String executionId) {
        try {

            // call below to validate executionId + exception
            AgentStatusResponse response = getStatusInt(
            executionId);

            // close
            executionService.closeAgent(executionId);

            return ResponseEntity.ok(true);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/close-all-danger")
    public ResponseEntity<Boolean> closeAllAgents() {
        try {
            // close all
            executionService.closeAllAgents();

            return ResponseEntity.ok(true);
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/list-status")
    public ResponseEntity<List<AgentStatusResponse>> getStatusAll() {
        try {
            List<AgentStatusResponse> listAgentStatusResponse = new ArrayList<>();
            List<String> executionList = executionService.getExecutions();

            for (String executionId : executionList ) {
            AgentExecution execution = executionService.getExecution(executionId);
            
            AgentStatusResponse response = new AgentStatusResponse();
            response.setExecutionId(execution.getExecutionId());
            response.setStatus(execution.getStatus().name());
            response.setCurrentStep(execution.getCurrentStep());
            response.setTotalSteps(execution.getInputPrompts().length + 1); // +1 for input step
            response.setStepResults(execution.getStepResults());
            response.setFinalOutput(execution.getFinalOutput());
            response.setCreatedAt(execution.getCreatedAt());
            response.setUpdatedAt(execution.getUpdatedAt());
            response.setRejectionReason(execution.getRejectionReason());
            response.setRequiresApproval(execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL);

            listAgentStatusResponse.add(response);

            }            
            
            return ResponseEntity.ok(listAgentStatusResponse);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/list-sessions")
    public ResponseEntity<List<String>> listSessions() {
        try {
            List<String> executionList = executionService.getExecutions();
            return ResponseEntity.ok(executionList);
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    
    @GetMapping("/cancel")
    public ResponseEntity<AgentStatusResponse> cancelExecution(
            @RequestParam String executionId) {
        try {
            AgentExecution execution = executionService.cancelExecution(executionId);
            
            AgentStatusResponse response = new AgentStatusResponse();
            response.setExecutionId(execution.getExecutionId());
            response.setStatus(execution.getStatus().name());
            response.setCurrentStep(execution.getCurrentStep());
            response.setTotalSteps(execution.getInputPrompts().length + 1);
            response.setStepResults(execution.getStepResults());
            response.setFinalOutput(execution.getFinalOutput());
            response.setCreatedAt(execution.getCreatedAt());
            response.setUpdatedAt(execution.getUpdatedAt());
            response.setRequiresApproval(false);
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    // ========== Restore Point Endpoints ==========
    
    @GetMapping("/restore-points")
    public ResponseEntity<RestorePointsResponse> getRestorePoints(
            @RequestParam String executionId) {
        try {
            AgentExecution execution = executionService.getExecution(executionId);
            List<RestorePoint> restorePoints = executionService.getRestorePoints(executionId);
            
            RestorePointsResponse response = new RestorePointsResponse(
                executionId,
                execution.getCurrentStep(),
                restorePoints
            );
            response.setMessage("Found " + restorePoints.size() + " restore point(s)");
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    
    @PostMapping("/restore")
    public ResponseEntity<AgentStepResponse> restoreToStep(
            @RequestParam String executionId,
            @RequestBody RestoreRequest restoreRequest) {
        
        try {
            AgentExecution execution = executionService.restoreToStep(
                executionId,
                restoreRequest.getStepIndex(),
                restoreRequest.isReExecute()
            );
            
            AgentStepResponse response = new AgentStepResponse(
                execution.getExecutionId(),
                execution.getProjId(),
                execution.getAppName(),
                execution.getUserName(),
                execution.getTaskId(), // for currentStep
                execution.getCurrentStep(),
                execution.getCurrentStepResult(),
                execution.getStatus().name(),
                execution.getStatus() == AgentExecution.Status.PENDING_APPROVAL,
                execution.isLastStep()
            );
            
            if (restoreRequest.isReExecute()) {
                response.setMessage("Restored to step " + restoreRequest.getStepIndex() + 
                    " and re-executed. Awaiting approval.");
            } else {
                response.setMessage("Restored to step " + restoreRequest.getStepIndex() + 
                    ". Ready for approval or further execution.");
            }
            
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (IllegalStateException e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        } catch (Exception e) {
			System.err.println("Exception Error message: " + e.getMessage()); 
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}


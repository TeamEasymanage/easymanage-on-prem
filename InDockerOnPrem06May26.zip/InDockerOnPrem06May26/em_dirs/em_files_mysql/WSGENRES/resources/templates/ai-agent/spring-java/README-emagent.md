# EasyManage AI Agent

## AI Agent Templates

Templates as zip files 

```
emagent_chain.zip
emagent_parallel.zip
```

| AI Agent Template For | Use Zip |
|---|---|
| Prompt Chaining Workflow Example | emagent_chain.zip  |
| Parallelization Workflow Example | emagent_parallel.zip  |


## How To Use AI Agent Templates

### Prompt Chaining Workflow Example

* Extract zip `emagent_chain.zip`

#### Low-code Customize And Use

* Template is provided for `Product` table
* You want to use it for `Customer` table
* See guidelines below
  - NOTE: In place of tables, You can also use Data Models - table relations and joins. e.g. for `CustomerOrders`

* Open emagent_chain project in Visual Studio Code
* Please search for below string in file names and rename/replace
* Please search for below string and edit, Global Replace, preserving case

| Locate | Rename/Replace With |
|---|---|
| Product | Customer  |

#### Configure Project

* Configure settings for using EasyManage MCP Server:
  - Edit `emagent_chain\src\main\resources\mcp.json`
  - Set/Verify values for command Java 17 location, MCP Server jar, `em.mcp.apiUrl`.
* LLM configured: OpenAI
  - Set environment variable `OPENAI_API_KEY`
  - Note: To use other models, please see/edit
    - `emagent_chain\pom.xml`
    - `emagent_chain\src\main\resources\application.properties`

#### Build Project And Run

* Set Java 17 in PATH.
* Please follow `emagent_chain\README.md`

### Parallelization Workflow Example

* Follow similar guidelines as given above for Prompt Chaining Workflow Example.

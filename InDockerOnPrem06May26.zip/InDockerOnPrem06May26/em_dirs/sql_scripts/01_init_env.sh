#!/bin/bash

set -e

# The 'mysql' command is available globally in the container.
# Use environment variables provided by the Docker image.

echo "Begin ... 01_init_env.sh ..."

# echo "1 $MYSQL_ROOT_PASSWORD"
echo "2 EMDB_DATABASE: $EMDB_DATABASE"
echo "3 EMDB_USER: $EMDB_USER"
#echo "4 $EMDB_PASSWORD"

echo "02 Run 02_cr_db ..."

sed "s/\${EMDB_DATABASE}/$EMDB_DATABASE/g" /sql_scripts/02_cr_db.sql | \
  sed "s/\${EMDB_USER}/$EMDB_USER/g" | \
  sed "s/\${EMDB_PASSWORD}/$EMDB_PASSWORD/g" | \
  mysql -u root -p"$MYSQL_ROOT_PASSWORD"

echo "03 Run 03_load_db ..."

# Run as mysql root is ok
echo " USE $EMDB_DATABASE ; SOURCE /sql_scripts/03_load_db.sql; " | mysql -u root -p"$MYSQL_ROOT_PASSWORD"

echo "Done ... 01_init_env.sh ..."


<%@ include file="jsp/BaseEmPrtl.jsp" %>

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * All rights reserved.
 */
-->

<%@ include file="pre_dn1_html.jsp" %>

<TITLE><%= TitleInb %> : Content Home</TITLE>

<%@ include file="pre_dn2_html.jsp" %>

<br>

<p>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2">
Content Home <br>
</font>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="1">
[Set-up this page as Content Home Page!]
</font>
<br><br>

<!-- Footer -->
<%@ include file="post_dn_html.jsp" %>

</BODY>
</HTML>



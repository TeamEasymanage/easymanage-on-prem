/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */

/*
 * SAMPLE BEAN FILE FOR WEBPROJECT CALLBEAN
 */

package em;

import java.lang.*;

public class CB_DEMO_10004_10018  {
	public String doBean() {
		return "From bean CB_DEMO_10004_10018."; 
	}
	public int getStatus() {
		return 1;
	}
}


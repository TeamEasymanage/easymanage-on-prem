<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->


<%-- Uncomment Following after specifying your bean class ....
<jsp:useBean id="CB_DEMO_10004_10018" scope="page" class="CB_DEMO_10004_10018" />
--%>

<%=bfont1%>
Jsp File: CB_DEMO_10004_10018
<BR>

<%-- Uncomment Following after specifying your bean class ....
<%=CB_DEMO_10004_10018.doBean()%>
--%>

</font><BR>
<br>

<%-- Uncomment Following after specifying your bean class ....
<% cb_stat = CB_DEMO_10004_10018.getStatus(); %>
--%>

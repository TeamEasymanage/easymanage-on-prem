<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->


<%-- Connect to DB
--%>

<%@ include file="/custom/jsp/DbConnect.jsp" %>

<%
	JConnToDb();

	if (db_stat == 1) {

	PreparedStatement stmt;
	ResultSet rset;
	String sql_qry_txt = "";

	//Get op Bal first...

	String op_bal = "";
	String op_crdr = "";
%>

<%@ include file="/custom/jsp/CB_DEMO_10006_10038_ins1.jsp" %>

<%
	//Get ledger disp values
	String[] jwptext = new String[5];

	try {

	sql_qry_txt =
	"	SELECT		"+"\n"+
	"	FLS_LED_CODE, MTHN,	  	"+"\n"+
	"	Expr1002 , Expr1003 , Expr1005    "+"\n"+
	"	FROM FN_DISP_LED_HIS5_VW 	"+"\n"+
	"	WHERE FLS_LED_CODE = ?		"+"\n"+
	"	Order by Expr1003 asc 		"+"\n";

	//Use format for Dr Cr: Format(a.Expr1005),'0.00 Cr;0.00 Dr;"";"";')

		stmt = dbconn.prepareStatement(sql_qry_txt); 

		stmt.setString(1, "1") ; //Pass LED_CODE

		//stmt.setInt(1, (int) 10019);
		//stmt.setString(2, "DEMO") ;

	if (dbconn == null || stmt == null) {
		return;
	}
	else {
            rset = stmt.executeQuery();

		//if (rset.next()) {
		while (rset.next()) {
	       for (int i=0; (i < jwptext.length) ;i++) {
			jwptext[i] = rset.getString(i+1);
%>
		| i = <%=i%> - <%=jwptext[i]%> 
<%
		} //for
%>
			<br>
<%
		} //while

		rset.close();
		stmt.close();
	} //else
	} //try
        catch (SQLException ex) {
            System.err.println(ex);
        }


	JcloseDb(); 
	}

%>


<style>
	.emstbutton {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstqrybtn  {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstselrecbtn {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstlkokbtn {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstlkbtn {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstsubbtn {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
	.emstresbtn {font-family:tahoma; font-size:8pt; height:20; background:#3985b5; color:#FFFFFF; border:0; };
</style>



<HTML>
<body  leftMargin=2 topMargin=0 marginheight=0 marginwidth=0  bgcolor=White>

<FORM name="FI10365" >
  <FONT face="Verdana" color size="1" class="emstrecinfo"><INPUT type="hidden" name="M12Fval_id" value="0"><INPUT type="hidden" name="M11Fval_id" value="0"><INPUT type="hidden" name="M10Fval_id" value="0"><INPUT type="hidden" name="M9Fval_id" value="0"><INPUT type="hidden" name="M8Fval_id" value="0"><INPUT type="hidden" name="M7Fval_id" value="0"><INPUT type="hidden" name="M6Fval_id" value="0"><INPUT type="hidden" name="M5Fval_id" value="0"><INPUT type="hidden" name="M4Fval_id" value="0"><INPUT type="hidden" name="M3Fval_id" value="0"><INPUT type="hidden" name="M2Fval_id" value="0"><INPUT type="hidden" name="M1Fval_id" value="0"></FONT><INPUT type="hidden" name="usrnm" value="HIS"><INPUT type="hidden" name="wp_id" value="10052"><INPUT type="hidden" name="screen_num" value="2"><INPUT type="hidden" name="usrnm" value="HIS"><INPUT type="hidden" name="categ_id" value="10365"><INPUT type="hidden" name="form_id" value="1"><INPUT type="hidden" name="categ_name" value><INPUT type="hidden" name="categ_typ" value="fld"><INPUT type="hidden" name="categ_levels" value="-1"><INPUT type="hidden" name="routeto" value><INPUT type="hidden" name="ieForm" value="1"><INPUT type="hidden" name="attempt" value="1"><INPUT type="hidden" name="multirec" value="12">
  <TABLE border="0" width="100%" bgcolor="DEDEDE" cellspacing="2" cellpadding="0" class="emstdattbl">
    <TR class="emstdattbltr">
      <TD bgcolor="EFEFEF" align="Left" valign="Center" colspan="1" class="emstdattbltdpmt"><FONT face="Verdana" size="1" color="000000">Month</FONT></TD>
      <TD bgcolor="EFEFEF" align="Left" valign="Center" colspan="1" class="emstdattbltdpmt"><FONT face="Verdana" size="1" color="000000">Opening
        Balance</FONT></TD>
      <TD bgcolor="EFEFEF" align="Left" valign="Center" colspan="1" class="emstdattbltdpmt"><FONT face="Verdana" size="1" color="000000">Amount</FONT></TD>
      <TD bgcolor="EFEFEF" align="Left" valign="Center" colspan="1" class="emstdattbltdpmt"><FONT face="Verdana" size="1" color="000000">Closing
        Balance</FONT></TD>
    </TR>
    <TR class="emstdattbltr">
      <TD bgcolor="FFFFFF" align="Left" valign="Center" colspan="1" class="emstdattbltddat"><INPUT type="text" name="M1F11169" class="emstinpinp" value size="10" maxlength="10"><FONT face="Verdana" color size="1" class="emsthlpdisp"></FONT></TD>
      <TD bgcolor="FFFFFF" align="Left" valign="Center" colspan="1" class="emstdattbltddat"><INPUT type="text" name="M1F11170" class="emstinpinp" value size="15" maxlength="15"><FONT face="Verdana" color size="1" class="emsthlpdisp"></FONT></TD>
      <TD bgcolor="FFFFFF" align="Left" valign="Center" colspan="1" class="emstdattbltddat"><INPUT type="text" name="M1F11171" class="emstinpinp" value size="15" maxlength="15"><FONT face="Verdana" color size="1" class="emsthlpdisp"></FONT></TD>
      <TD bgcolor="FFFFFF" align="Left" valign="Center" colspan="1" class="emstdattbltddat"><INPUT type="text" name="M1F11172" class="emstinpinp" value size="15" maxlength="15"><FONT face="Verdana" color size="1" class="emsthlpdisp"></FONT></TD>
    </TR>
  </TABLE>
</FORM>

  
    
   </body></HTML>


<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<p>IN INS1<br>

<% if (1==1) { %>

<jsp:useBean id="sdks" scope="page" class="em.sub_data_frm" />

<%
	//Use following to change database type, if req.
	//sdks.switchDbConnType("mssql");

	//Handle blank qry_id2

	sdks.WpSetConn(dbconn); 

	int p_tblqry = 2;

	sdks.WpSetParam(
	"DEMO",
	10010,
	"",
	"tbl",
	1, //categ_lev
	1, //form_id
	0, //edt_frm
	p_tblqry, //tblqry
	0,"","","",0
	);

	String v_c_function1 = "webproj";
	sdks.processRequest(request, response, v_c_function1);

	if (p_tblqry == 2) {
	//Not passing field id for 1st field gives index out of bounds error
	//&qry_sel1=Yes&qry_andor1=&field_id1=10031%3ACHAR%3A 
	//	&qry_opr1=Like&qry_case1=Yes&qry_val1=%25

	//String[][] qryln = {{ "","","","","","", }};
	//String[] qryarr = {"","","","","","",
	//		"","","","","","" };
	String[][] qryln = {{ "Yes","","10031:CHAR:","Like","","%" },
				{ "Yes","AND","10032:NUMBER:","=","","55"} };
	String[] qryarr = {"10032:NUMBER:","desc","200","1","%",
			"1","","","Yes","500","4","desc" };
	sdks.WpSetParamQrySubm(qryln,qryarr);

	}

		int l_no_of_rec = 0;

		sdks.doDbData(request); 
		int sdk_one_time = 0;

	 if (sdks.subd_stat == 1) { 

			while (sdks.moreDataRec() == 1) { 
			sdks.dbFldDatPropQry();
			sdks.doFldNLPropQry();

			while (sdks.moreRec() == 1) {
			String tt11 = sdks.doDataRec();


			if (sdk_one_time == 0) {

			/*******
			strbuf.append(
			"	<!-- Table Info -->"+"\n"+
			"	<table_info"+"\n"+
			"		id=\""+categ_id+"\""+"\n"+
			"		name=\""+wptext[22]+"\""+"\n"+
			"	>"+"\n"+
			"	</table_info>"+"\n"+
			""+"\n"
			);
			*********/

%>
			Table:<%=sdks.wptext[22]%> <br>
<%

			sdk_one_time++;
			}

			if (sdks.selfld_no == 1) {

				if (sdk_one_time == 1) {
					sdk_one_time++;
				} else {
				//strbuf.append(
				//"</datarecord>"+"\n"
				//);
				}

			//strbuf.append(
			//"<datarecord"+"\n"+
			//"	id=\""+l_val_id+"\""+"\n"+
			//">"+"\n"
			//);

%>
			Record: <%=sdks.l_val_id%> <!-- | 
			Info: <%=sdks.putRecInfo()%> --> <br>
<%

			}

			/***********
			strbuf.append(
			"	<field"+"\n"+
			"		id=\""+wptext[4]+"\""+"\n"+
			"		name=\""+wptext[0]+"\""+"\n"+
			"		datatype=\""+wptext[1]+"\""+"\n"+
			"		sqlname=\""+wptext[21]+"\""+"\n"+
			//"		value=\""+fld_val+"\""+"\n"+
			"	>"+"\n"+
			"		<value><![CDATA["+fld_val+"]]></value>"+"\n"+
			"	</field>"+"\n"
			);
			***********/

%>
			Field: <%=sdks.wptext[0]%> | 
			Field Val: <%=sdks.fld_val%> <br>
<%

			} //while moreRec

	String tt22 = sdks.doFldNLEnd();
	//strbuf.append(doFldNLEnd());
	sdks.doneLnkSelfldQry();
	sdks.doneFldDatProp();
	sdks.doneFldNLProp();
      //return (strbuf.toString());


		l_no_of_rec++;

		} //while moreDataRec

	%>

	<BR>
	<%=bfont %>
	<%=l_no_of_rec%> records processed.
	</font><br>

	<%

	} else {
%>
	<BR>
	<%=bfont %> <font color="FF0000">
	No Data Records Found.
		</font></font><br>
	<% } %>

	<% sdks.doneDataRec(); %>

<% } // if (1==1)  %>


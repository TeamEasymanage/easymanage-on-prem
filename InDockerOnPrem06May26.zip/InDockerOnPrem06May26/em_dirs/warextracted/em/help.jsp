
<%@ include file="jsp/BaseEmPrtl.jsp" %>

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * All rights reserved.
 */
-->

<%@ include file="pre_dn1_html.jsp" %>

<TITLE><%= TitleInb %> : Help</TITLE>

<%@ include file="pre_dn2_html.jsp" %>


<br>
<TABLE BORDER=0>
<TR>


<TD valign="Top" width="22%">

	
</td>


<TD valign="top" width="100%" >


	<table cellpadding="2" cellspacing="1" border="0" width="100%">
		<tr align="Left">
		<td align="right">
		<A HREF="/<%=usrproj%>/aboutemwp.jsp">
		<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="1">
		<b>About EM WebPlus Suite</b></A></font>
		</td>
		</tr>
	</table>

	<table cellpadding="2" cellspacing="1" border="0" width="100%">
		<tr align="Left">
		<td bgcolor="#3985b5">
		<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2" color="White"> <b> Help </b></font>
		</td>
		</tr>
	</table>
        



<p>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2">
<b>Online Help:</b><br>
Please refer to the online <b>Documentation</b> at one of these locations:<br>
<b><A HREF="/emdoc/index.html">Documentation in this installation</A></b><br>
<b><A HREF="http://www.EasyManage.com/emdoc/index.html">Documentation Online at EasyManage.com</A></b><br>

<br><br>

<b><em>User Guide</em></b>: 
For any user or developer related information or issues, and
<br><br>
<b><em>Administrator Guide</em></b>: 
For administration related information or issues 
including installation and set-up.
<br><br>
<br><br>

</font>




</td><td>


</td>
</tr>
</table>


<!-- Footer -->
<%@ include file="post_dn_html.jsp" %>

</BODY>
</HTML>




<%@ include file="jsp/BaseEmPrtl.jsp" %>

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * All rights reserved.
 */
-->

<%@ include file="pre_dn1_html.jsp" %>

<TITLE><%= TitleInb %> : Sign-In</TITLE>

<SCRIPT langauage="JavaScript">
<!--
function chkFrames()
{
   var tot_fr = parent.frames.length ;
   if (tot_fr >  1) {
	SendToLater();
   }
}
function SendTo()
{
	parent.location.href= "/<%=usrproj%>/index.jsp";
}
function SendToLater()
{
	window.setTimeout("SendTo();", 0000);
}
	chkFrames();
//-->
</SCRIPT>


<%@ include file="pre_dn2_html.jsp" %>

<% 
String t_secURLPrefix = "";
if (secSignInUp == 1) { 
	t_secURLPrefix = secURLPrefix;
} 
%>

    </div> <!--dummy div tbl resp.-->

    <div class="container">
        <div class="row text-center ">
            <div class="col-sm-5 col-xs-10">
                
                <h5> EasyManage</h5>
               
               <!-- <h5>(Sign In to start your session )</h5> 
                 <br />
			   -->
            </div>
        </div>
         <div class="row ">
               
                  <div class="col-sm-5 col-xs-10"> <!--class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-12 "--> <!-- col-xs-offset-1 -->
                  <!--div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3 col-xs-10 col-xs-offset-1"-->
                        <div class="panel panel-default">
                            <div class="panel-heading">
                        <strong>Sign In</strong>  
                            </div>
                            <div class="panel-body">
                                <!--form role="form" -->
								<FORM role="form" METHOD="POST" ACTION="<%=t_secURLPrefix%>/<%=usrproj%>/jsp/signin.jsp">
                                       
                                     <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"  ></i></span>
                                            <input type="text" class="form-control" placeholder="Your User ID " maxlength="20" name="p_CL_USER" />
                                        </div>
                                            <div class="form-group input-group">
                                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"  ></i></span>
                                            <input type="password" class="form-control"  placeholder="Your Password" maxlength="20" name="p_CL_PASS" />
                                        </div>
                                    <div class="form-group">
                                            <label class="checkbox-inline">
                                                <input type="checkbox" checked name="keep2w" value="1" /> Stay signed in
                                            </label>
                                            <span class="pull-right"> 
<%@ include file="index_ins2_appview.jsp" %>
											<!-- 
                                            <label class="checkbox-inline">
                                                <input type="checkbox" name="frame_opt" id="frame_opt"  value="3" /> User Menu
                                            </label>
											-->
                                            </span>
                                        </div>
                                    <div class="form-group">
											
                                            <span class="pull-right"> 
											<input type="submit" name="Submit" class="btn btn-primary" value="Sign In">
                                                 <!--  
												 <a href="#" >Forget password ? </a> 
												 -->
                                            </span>
											
												<!-- <input type="hidden" name="frame_opt" value="3"> -->
												<!-- input type="hidden" name="frame_opt" value="3" --><!-- UM, MAIN -->
												<input type="hidden" name="p_CL_AS_USER" value="">
												<input type="hidden" name="p_CL_DATA_GRP" value="">
												<input type="hidden" name="dest" value="Inbox">
												<input type="hidden" name="first_scr" value="LatAct">
												<input type="hidden" name="dashbrd" value="0">
												<input type="hidden" name="dsh_frame_opt" value="1">
                                        </div>
                                     
                                       <div class="form-group  input-group">
  		                                     <div style=" overflow: hidden;  display: inline-block; ">
<%@ include file="index_ins0.jsp" %>
											</div>
                                        </div>
                                    <!--hr /-->
                                    New User ? <A HREF="<%=t_secURLPrefix%>/<%=usrproj%>/jsp/signup_scr.jsp">Sign-Up</A>
									</form>
                            </div>
                           
                        </div>
                    </div>
                
                
        </div>
    </div>


    <div> <!--dummy div tbl resp.-->

<!-- Footer -->
<%@ include file="post_dn_html.jsp" %>

<%-- doFrameOpt
portrait phones and down (max-width: 480px)
Refer to http://www.w3schools.com/bootstrap/bootstrap_grid_system.asp
--%>
<SCRIPT langauage="JavaScript">
<!--
$( document ).ready( doFrameOpt );
$(window).resize( doFrameOpt );

function doFrameOpt( jQuery ) {
  //alert('width ' + $(this).width());
  if ($(this).width() <= 767) {
	$('#frame_opt').prop('checked', false);
  //} else {
//	$('#frame_opt').prop('checked', true);
  }
}
//-->
</SCRIPT>

</BODY>
</HTML>

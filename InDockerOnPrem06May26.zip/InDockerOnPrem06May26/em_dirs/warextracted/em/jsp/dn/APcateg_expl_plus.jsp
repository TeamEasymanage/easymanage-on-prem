<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="ctep" scope="page" class="em.Categ_expl_plus" />
<%
	ctep.setApFlg();
	ctep.processRequest(request, response);
	get_gui_str(ctep.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = ctep.emerr;
	valid_login = ctep.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> App POWER Search </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 1;
	mnu2_sel = 2;
	String usrnm = ctep.usrnm;
	app_run = 1; //ctep.app_run;
	usrnm_as = ctep.usrnm_as;
	usrnm_si = ctep.usrnm_si;
	datagrp = ctep.datagrp;

%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=ctep.categ_name%></b></font></font></td>
</td>
</tr>
</table>


<% if (ctep.attempt == 0)  { %>

	<%= bfont %> <b>App POWER Search</b></font><br>

	<% 
	   String ctg_param = "usrnm="+ctep.usrnm+"&categ_id="+ctep.categ_id+"&categ_name="+ctep.categ_name+"&categ_typ="+ctep.categ_typ+"&categ_levels="+ctep.categ_levels+"&routeto="+ctep.routeto; 
	   String expl_param = ctg_param+"&qry_val=&qry_selall=Yes&qry_limitrows=500&attempt=1"; 
	%>
	<table width="100%" cellpadding="0" cellspacing="1" border="0" >
	<tr align="center">
	<td bgcolor="#FF8888" nowrap><%=bfont1%><b>
	    Quick Links (List 500):</b>
	</font></td>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus.jsp?<%=expl_param%>&qry_categ_typ=txt">
	    <font color="#000000">Text or Folders</A></font>
	</font></td>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus.jsp?<%=expl_param%>&qry_categ_typ=tbl">
	    <font color="#000000">Tables</A></font>
	</font></td>
	<%--
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus.jsp?<%=expl_param%>&qry_categ_typ=app">
	    <font color="#000000">Applications</A></font>
	</font></td>
	--%>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus.jsp?<%=expl_param%>&qry_categ_typ=wpj">
	    <font color="#000000">WebProjects</A></font>
	</font></td>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus.jsp?<%=expl_param%>&qry_categ_typ=all">
	    <font color="#000000">All Of These</A></font>
	</font></td>
	</tr>
	<tr align="center">
	<td bgcolor="#FF8888"></td>
	<td bgcolor="#FF8888"></td>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus_fld.jsp?<%=expl_param%>">
	    <font color="#000000">Table Fields</A></font>
	</font></td>
	<td bgcolor="#FF8888" nowrap><%=bfont1%>
	    <A HREF="/<%=usrproj%>/jsp/dn/APcateg_expl_plus_wp.jsp?<%=expl_param%>">
	    <font color="#000000">WebProject Screens</A></font>
	</font></td>
	<td bgcolor="#FF8888"></td>
	</tr>
	</table>
	<br>

	<%= bfont %> <b>Search Forms</b></font><br>

	<%-- Display Form --%>
	<%= ctep.doFormQry() %>

	<%= bfont1 %><b>Note:</b> <br>
	 1. Search is case sensitive.<br> 
	 2. For wild card search add percent character (%) where required, 
	e.g. To search all field names having 'Id' in them, Search For %Id% 
	<br>
	3. In Search Table Data: Query values for DATE/DATETIME/TIME should be entered in respective
		full input format as you would on input form. Wild card(%) not allowed for DATE/DATETIME/TIME.

	</font><br>


<% } else {  %>

	<%= bfont %> <b>App POWER Search</b></font><br>

	<% ctep.doForm(request); %>

	<% if ( ctep.form_stat == 1) { %>
		<%= ctep.doFormBeg() %>
			<%= ctep.doFormFld() %>
		<% while (ctep.getRow() == 1) { %>
			<%= ctep.doFormFld() %>
		<% } %>
		<%= ctep.doFormEnd() %>
	<% } %>
	<% ctep.doneReq(); %>

<% } // elseofif ( ctep.attempt == 0) %>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

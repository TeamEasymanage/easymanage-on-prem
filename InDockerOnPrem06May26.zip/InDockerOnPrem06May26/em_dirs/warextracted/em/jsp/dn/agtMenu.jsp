<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="mo" scope="page" class="em.My_opt" />
<%
	mo.processRequest(request, response);
	get_gui_str(mo.gui_str);


%>
<%-- check valid sign-in --%>
<%	emerr = mo.emerr;
	valid_login = mo.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> AI Agents Menu</title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 8;
	mnu2_sel = 0;
	String usrnm = mo.usrnm;
	usrnm_as = mo.usrnm_as;
	usrnm_si = mo.usrnm_si;
	datagrp = mo.datagrp;

%>
<%@ include file="../pre_dn_sm.jsp" %>
<%--
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b>Tools</b></font></font></td>
</td>
</tr>
</table>
<br>
--%>
	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String SendToUrlmows = "/"+usrproj+"/jsp/dn/ws_menu.jsp?usrnm="+mo.usrnm+"&tm_now="+tm_now; 
	String SendToUrlmotbsh = "/"+usrproj+"/jsp/dn/table_schema.jsp?usrnm="+mo.usrnm+"&tm_now="+tm_now; 
	String SendToUrlmotbshint = "/"+usrproj+"/jsp/dn/table_schema_int.jsp?usrnm="+mo.usrnm+"&tm_now="+tm_now; 
	//&dodef=usedef
	//&dodef=makedef
	%>

<style>
.btn {
margin: 2px;
}
</style>

	<%= bfont %> <b>AI Agents</b></font>
	<br><br>

	<ul class="nav nav-tabs">
	  <li class="active"><a data-toggle="tab" href="#home">QuickLinks</a></li>
	  <li><a data-toggle="tab" href="#menu1">Prerequisites <i class="fa fa-arrow-circle-right"></i></a></li>
	  <li><a data-toggle="tab" href="#menu2">Run Agents <i class="fa fa-arrow-circle-right"></i></a></li>
	</ul>

	<div class="tab-content">
	  <div id="home" class="tab-pane fade in active">
		<!-- <h3>QuickLinks</h3> -->
		<br>
	<%= bfont %>
	
	<table border=1 > <!-- class="table table-bordered" -->

	<!-- html prited as commented text 
	<tr>
	<td><b>Source: </b></td>
	<td><i class="fa fa-database"></i> Db </td>
	<td bgcolor="#DDDDDD">
	<% if (mo.hasAdvAuth() == 1) { //mo.hasSUAuth() %>
     <%=mo.emDbSourceInfo().substring(0,5)%> 
		<i class="fa fa-info-circle" TITLE="<%=mo.emDbSourceInfo()%>"></i>
	<% } else { %>
		<i class="fa fa-info-circle" TITLE="Not Adv User."></i>
	<% } %>
	</td>
	</tr>
	-->
	<tr><td><b>Project <em>(Default)</em>: </b> </td>
	<td>
	Workspace 
	</td>
	<td>
	<i class="fa fa-briefcase"></i>
    <%=mo.usrnm%>
	</td>
	<td></td>
	</tr>
	
	
	<tr><td><b>Manage: </b> </td>
	<td>AI Agents
	</td>
	<td> 
	    <button class="btn btn-xs btn-primary"><A HREF="/<%=usrproj%>/jsp/dn/categ.jsp?usrnm=<%=usrnm%>&categ_id=200&categ_name=Explorer&categ_typ=all&categ_levels=1&routeto=">
	    <font color="#fff"> Studio Explorer</font></A></button> 
		|
	    <button class="btn btn-xs btn-primary"><A HREF="/<%=usrproj%>/jsp/dn/categExplore.jsp?usrnm=<%=usrnm%>&categ_id=200&categ_name=Explorer&categ_typ=all&categ_levels=1&routeto=">
	    <font color="#fff"> DATA Table Explorer</font></A></button> 
	</td>
	<td><i class="fa fa-lg fa-fw fa-arrow-circle-down" style="opacity: .5;"></i></td>
	</tr>
	<tr><td><b>Prerequisites: </b> </td>
	<td>Run Builds  </td>
	<td>
	Before Running AI Agents, Run Builds For Backend APIs, MCP Server, and then Agent Server.
	</td>
	<td><i class="fa fa-lg fa-fw fa-play-circle" style="opacity: .5;"></i></td>
	</tr>
	<tr><td> </td>
	<td>Deploy & Run</td>
	<td>
	[1] APIs: REST or GraphQL <i class="fa fa-lg fa-fw fa-arrow-circle-right" style="opacity: .5;"></i>
	[2] MCP Server: REST or GraphQL <i class="fa fa-lg fa-fw fa-arrow-circle-right" style="opacity: .5;"></i>
	[3] Agent Server 
	</td>
	<td></td>
	</tr>

	<tr><td><b>Configure: </b> </td>
	<td>On Agent Server
	</td>
	<td> 
		AI - API Settings: 
		Configure settings for API Provider, Key, Model <!-- Rules, HITL -->
	</td>
	<td><i class="fa fa-lg fa-fw fa-arrow-circle-down" style="opacity: .5;"></i></td>
	</tr>
	<tr><td> </td>
	<td>Agent Server Settings
	</td>
	<td>  
	    <button class="btn btn-xs btn-primary"><A HREF="/<%=usrproj%>/jsp/dn/auth_list.jsp?usrnm=<%=usrnm%>&selopt=agtsvr&attempt=1">
	    <font color="#fff">Agent Server Configuration</font></A></button> |
		Configure settings for Agent Server
	</td>
	<td><i class="fa fa-lg fa-fw fa-arrow-circle-down" style="opacity: .5;"></i></td>
	</tr>
	<tr><td><b>Run: </b> </td>
	<td>Agents  </td>
	<td>
	Locate Agent Projects in List AI Agents or Studio Explorer, Select Project then   
	Agent Run 
	<i class="fa fa-lg fa-fw fa-arrow-circle-up" style="opacity: .5;"></i>
	</td>
	<td><i class="fa fa-lg fa-fw fa-play-circle" style="opacity: .5;"></i></td>
	</tr>


	<tr><td><b>Dashboard: </b> </td>
	<td> AI Agents Container  </td>
	<td>
	    <button class="btn btn-xs btn-primary"><A HREF="<%="/"+usrproj+"/jsp/dn/agtproj_dashboard.jsp?usrnm="+usrnm+"&routeto="%>">
	    <font color="#fff"> AI Agents Container Dashboard</font></A></button>
		View Sessions, List your Agent Projects runtime data, drill-down.
	</td>
	<td></td>
	</tr>
	
	
	</table>
	</font>

	  </div>
	  <div id="menu1" class="tab-pane fade">
		<%= bfont %>
		<h3>Prerequisites</h3>
		
		<p>Run Builds  <i class="fa fa-lg fa-fw fa-play-circle" style="opacity: .5;"></i> 
		<br>
		Before Running AI Agents, Run Builds For MCP Server and Backend APIs
		<br>
		</p>
		
		<p>Deploy & Run<br>
		MCP Server: REST or GraphQL | APIs: REST or GraphQL
		</p>
		</font>
	  </div>
	  <div id="menu2" class="tab-pane fade">
		<%= bfont %>
		<h3>Run Agents</h3>
		<h4>After Configure Settings</h4>
		<br>
		<p> AI - API Configuration</p>
		<p> &bull; API Provider, Key, Model, Rules, HITL
		</p>
		<br>
		</font>
	  </div>
	</div>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	if (app_run == 1) {
	wp.setApFlg();
	}
	wp.processRequest(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> AI Agent and Tasks </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

	if (app_run == 1) {
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	}

%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wp.categ_name%></b></font></font></td>
</td>
</tr>
</table>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="7"> <%=bfont%> <b>Agent</b></font>
	<%=pspace1%><%=pspace1%>
	<%=bfont%> 
	<% if ( wp.agt_row == 1) { %>
		<% //ok %>
	<% } else { %>
	<%= wp.doAgtCrtLink() %>
	<% } %>
	</font>
</td>
</tr>


<tr bgcolor="EFEFEF" align="center">
<td> <%=bfont1%> </font></td>
<td> <%=bfont1%> Proj #</font></td>
<td> <%=bfont1%> Agent Type</font></td>
<td> <%=bfont1%> Agent Name</font></td>
<%-- <td> <%=bfont1%> Auto Approve (Skip HITL?)</font></td> --%>
<td><%=bfont%> <%=pspace1%></font></td>
<td><%=bfont%> <%=pspace1%></font></td>
</tr>

	<% if ( wp.agt_row == 1) { %>
		<%=wp.doPropDisp()%>
	<% } %>
</table> 

	<% if ( wp.agt_row == 1) { %>
	
	<% wp.getTasks(); %>

<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="13"> <%=bfont%> <b>Agent Tasks</b></font>
	<%=pspace1%><%=pspace1%>
	<%=bfont%> 
	<%= wp.doCrNew() %>
	</font>
</td>
</tr>

<tr bgcolor="EFEFEF" align="center">
<td><%=bfont%> <%=pspace1%></font></td>
<td><%=bfont%> <%=pspace1%></font></td>
<td><%=bfont%> <%=pspace1%></font></td>
<td> <%=bfont1%> Task Order</font></td>
<td> <%=bfont1%> Proj #</font></td>
<td> <%=bfont1%> Task #</font></td>
<td> <%=bfont1%> Task Name</font></td>
<td> <%=bfont1%> Prev Context ?</font></td>
<td> <%=bfont1%> Prev Context Sel</font></td>
<td> <%=bfont1%> Context Save Header</font></td>
<td> <%=bfont1%> Model</font></td>
<td></td>
</tr>

<% if ( wp.wp_stat ==1) { %>

	<%-- Categories --%>
	<%=wp.doCategRow()%>
	<% while (wp.moreCateg() ==1) { %>
		<%=wp.doCategRow()%>
	<% } %>

<% } else { %>
	<tr bgcolor="EFEFEF">
	<td colspan="12" align="center"> <%=bfont%> <font color="FF0000">
	 No Tasks Defined OR No Autorization. 
	     </font></font></td>
	</tr>
<% } %>

	</table> 

	<% } %>

<% wp.doneRequest(); %>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>

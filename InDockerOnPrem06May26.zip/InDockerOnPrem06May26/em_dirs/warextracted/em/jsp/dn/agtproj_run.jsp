<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	wp.processRequest(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Run Menu</title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b>Agent Proj # <%=wp.wptext_1[0]%>, Name: <%=wp.wptext_1[3]%></b></font></font></td>
</td>
</tr>
</table>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="2"> <%=bfont%> <b>Agent Run </b></font>
	<%=bfont1%> 
	</font>
</td>
<td colspan="3"> <%=bfont%> <b>Usage</b></font>
	<%=bfont1%> 
	</font>
</td>
</tr>

<% if ( wp.agt_row ==1) { %>

	<tr bgcolor="EFEFEF">
<td><%=bfont%> Agent Run Request </font></td>
<td><%=bfont%> 
<textarea id="agentprojdata" rows="8" cols="70">
<%=wp.doCategRunRow()%>
</textarea>
</font></td>
<td><%=bfont%> POST Endpoints </font></td>
	<td> <%=bfont%> 
	run-full | start <br>
	<br>
	run-full: Is with Auto Approve
	<br>
	<br>
	start: Is with Human-in-the-loop
	<br>
	<br>
	Approve your steps in Dashboard
	</font></td>
	<td> 
	Request Body: <br>
	As per generated Agent Run Request
	</td>
	</tr>
	<tr bgcolor="EFEFEF">
<td><%=bfont%> API Endpoint </font></td>
<td><%=bfont%> 
    <input type="text" id="apiEndpointVal" value="http://127.0.0.1:9030/agentserver/agent/run-full" size="70"   maxlength="100">
	POST
</font></td>
<td colspan=3><%=bfont%> 
		After Agent Run: 
	    <button class="btn btn-xs btn-primary"><A HREF="<%="/"+usrproj+"/jsp/dn/agtproj_dashboard.jsp?usrnm="+usrnm+"&routeto="%>">
	    <font color="#fff"> AI Agents Container Dashboard</font></A></button>
		<br>
		View Sessions, List your Agent Projects runtime data, drill-down.

</font></td>
	</tr>

<% } else { %>
	<tr bgcolor="EFEFEF">
	<td colspan="13" align="center"> <%=bfont%> <font color="FF0000">
	 No Screens Defined OR No Autorization. 
	     </font></font></td>
	</tr>
<% } %>

<% wp.doneRequest(); %>

	</table> 

    <button onclick="postData()">Agent Run</button><br><br>

	<%=bfont%> <b>Response: </b><br>
    <pre id="responseArea"></pre>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>

<script>
async function postData() {
    const textarea = document.getElementById('agentprojdata');
    const dataToSend = textarea.value;

    try {
        JSON.parse(dataToSend);
    } catch (e) {
        document.getElementById('responseArea').textContent = 'Error: Invalid JSON format in the textarea.';
        return;
    }

    //const apiEndpoint = 'http://127.0.0.1:9030/agentserver/agent/run-full';
    const apiEndpoint = document.getElementById('apiEndpointVal').value;
	console.log('Got Url:', apiEndpoint);
    //const payload = {
    //    content: dataToSend
    //};

    try {
        const response = await fetch(apiEndpoint, {
            method: 'POST', 
            headers: {
				'accept': '*/*',
                'Content-Type': 'application/json' 
            },
            body: dataToSend
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}

</script>

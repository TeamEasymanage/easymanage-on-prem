<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

		<div id="loading-spinner" style="display: none;"><i class="fa fa-spinner" title="Loading..."></i></div>

<style>
#loading-spinner {
  width: 15px;
  height: 15px;
  animation: spin 1s linear infinite;
}
@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>


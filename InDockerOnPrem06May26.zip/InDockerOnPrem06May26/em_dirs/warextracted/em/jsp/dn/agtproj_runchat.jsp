<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj" />
<%
	if (app_run == 1) {
	wp.setApFlg();
	}
	wp.processRequest_gen(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Chat </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

	if (app_run == 1) {
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	}

%>
<%@ include file="../pre_dn_sm.jsp" %>


<table border=0 cellspacing=1 cellpadding=0> 
<tr bgcolor="DEDEDE" align="center">
<td colspan="4"> <%=bfont%> <b>Agent Chat</b></font>
	<%=bfont1%> 
	</font>
</td>
</tr>

<%
	String[] agtSvrConf = wp.getAgtSvrConf();
	String conf_id = agtSvrConf[0];
	String url_base = agtSvrConf[1];
	String api_hdrs = agtSvrConf[2];
	String rd_only = agtSvrConf[3];

	String no_disp_hdrs = "";

	String modelOpts = wp.getOptRunModels();
	// gets "<select  id=\"runWithModel\" name=runWithModel> "+"\n"+


%>

	<tr bgcolor="EFEFEF">
<td><%=bfont%> Agent Chat </font></td>
<td><%=bfont%> 
<textarea id="agentprojdata" rows="3" cols="50" readOnly >
<%=wp.doChatRunRow()%>
</textarea>
</font></td>
<td><%=bfont%> Conf Id <br>API Endpoint <br>Headers </font></td>
<td><%=bfont%> 
	<%=conf_id%> <br>
    <input type="text" id="apiEndpointVal" value="<%=url_base%>/start" size="40"   maxlength="100" readOnly >
	POST <br>
<textarea id="agentprojhdrs" rows="1" cols="40"  <%=no_disp_hdrs%> >
<%=api_hdrs%>
</textarea>

</font></td>
	</tr>

	<tr>
<td><%=bfont%>Switch Model:  <%=modelOpts%> </font></td>
<td><%=bfont%> 
    <button id="chat_start" onclick="postDataStart()">Start Chat Session</button>
</font></td>
<td>

<%@ include file="agtproj_run_spin_ins01.jsp" %>

</td>
<td>
	    <button class="btn btn-xs btn-primary"><A HREF="/<%=usrproj%>/jsp/dn/agtproj_runchat.jsp?usrnm=<%=usrnm%>">
	    <font color="#fff">New Chat Session</font></A></button>
</td>
	</tr>

	<tr>
<td><%=bfont%> Input Prompt:</font></td>
<td><%=bfont%> 
<textarea id="chatprompt" rows="3" cols="70" readOnly >
List mcp tools available
</textarea>
</font></td>
<td style="vertical-align: middle;"><%=bfont%> 
    <button id="chat_send" onclick="postChatPrompt()" disabled ><i class="fa fa-arrow-up fa-lg"></i> Send</button>
</font></td>
<td></td>
<td></td>
	</tr>

<% wp.doneRequest(); %>


	</table> 

<table border=0 cellspacing=1 cellpadding=0> 
	<tr>
<td><%=bfont%>Response Result: </font>
</td>
<td>
<%= wp.doFormChatAgtSave() %>
<%=bfont%> Execution Id : 
    <input type="text" id="respExecutionId" value="" size="40"   maxlength="100" readOnly >

<%--
	<br><br>
    <textarea id="execResponseJson" rows="2" cols="40" readOnly ></textarea>
--%>
	</font>
</td>
<td><%=bfont%>
<!-- <button onclick="getRespAndSubmit()">Save</button>-->
<input type=submit id="respSaveSubmit" name=submit value="Save" onclick="getRespAndSubmit()" disabled >
 <i class="fa fa-info-circle" title="Save Chat's current prompt and response."></i>
</font>
</form>
</td>
<td><%=bfont%>
 <button id="viewStepsAll" onclick="getStepsAll()" >Get All Steps Result</button> 
 <i class="fa fa-info-circle" title="Get and View All steps results."></i>
</font>
</td>
<td>
 <button id="respDiscardClose" onclick="closeSessExec()" disabled >Close</button> 
 <i class="fa fa-info-circle" title="Close session on Agent Server, Click only after Save done, else Run data lost."></i>
</td>
	</tr>
	</table> 

	<%=bfont%> <b>Step Response: </b> 

<%@ include file="agtproj_runimp_chart01.jsp" %>

	<br>
    <pre id="responseStep"></pre>
	<br>

	<%=bfont%> <b>Response Details: </b><br>
    <pre id="responseArea"></pre>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>

<script>

function getHeaders() {

/*	
const myDefHeaders = {
	'Accept': '* / *',
	'Origin': 'http://127.0.0.1:8080',
	'Content-Type': 'application/json'
};
*/

//console.log('Hdrs 0 :', myDefHeaders);

const headersArr = new Headers();
headersArr.append("Accept", "*/*");
headersArr.append("Content-Type", "application/json")
//headersArr.append("Origin", "http://127.0.0.1:8080")

//console.log('Hdrs Basic :');
//console.log(new Map(headersArr));

const usrhdrs = document.getElementById('agentprojhdrs').value;
const usrhdrsobj = JSON.parse(usrhdrs);

//console.log('Hdrs Auth :');
//console.log(usrhdrsobj);

Object.entries(usrhdrsobj).forEach(([key, value]) => {
    headersArr.append(key, value);
});

//console.log('Hdrs Added :');
//console.log(new Map(headersArr));

//const inputKeyValArr = Object.entries(usrhdrsobj);

/*
        for (const key in usrhdrsobj) {
            if (Object.hasOwnProperty.call(usrhdrsobj, key)) {

			headersArr.append(key, usrhdrsobj[key]);

            }
        }
*/

return headersArr;

}

async function postDataStart() {
    const textarea = document.getElementById('agentprojdata');
    const dataToSend = textarea.value;

	const spinner = document.getElementById('loading-spinner');

    try {
        JSON.parse(dataToSend);
    } catch (e) {
        document.getElementById('responseArea').textContent = 'Error: Invalid JSON format in the textarea.';
        return;
    }

    //const apiEndpoint = 'http://127.0.0.1:9030/agentserver/agent/start';
    const apiEndpoint = document.getElementById('apiEndpointVal').value;
	console.log('Got Url:', apiEndpoint);
    //const payload = {
    //    content: dataToSend
    //};
    const switchModel = document.getElementById('runWithModel').value;

	const apiExecUrl = new URL(apiEndpoint);
	apiExecUrl.searchParams.append('switchModel', switchModel);

	const addHdrs = getHeaders();
	
    try {

		spinner.style.display = 'block'; 		
		
        const response = await fetch(apiExecUrl, {
            method: 'POST', 
			headers: addHdrs,
            //headers: {
			//	'accept': '*/*',
            //    'Content-Type': 'application/json' 
            //},
            body: dataToSend
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

		//if (result && typeof result === 'object' && result.hasOwnProperty("executionId")) {
		  console.log(`The value of 'executionId' is:`, result["executionId"]);
		  document.getElementById('respExecutionId').value = result["executionId"];
		  document.getElementById('responseStep').textContent = result["stepResult"];

		  //document.getElementById('respSaveSubmit').disabled = false;
		  document.getElementById('respDiscardClose').disabled = false;
		  
		  //document.getElementById('respExecutionId').disabled = true;

		  document.getElementById('chatprompt').value = '';
		  document.getElementById('chatprompt').readOnly = false;

		  document.getElementById('chat_send').disabled = false;
		  document.getElementById('chat_start').disabled = true;
		  document.getElementById('runWithModel').disabled = true;

		  //document.getElementById('execResponseJson').value = JSON.stringify(result, null, 2);
		  
		  //return result[executionId];
		//} else {
		//  console.log(`The field 'executionId' does not exist in the response.`);
		//}


    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
	} finally {
		spinner.style.display = 'none';
    }
}
</script>

<script>
async function postChatPrompt() {

    const textarea = document.getElementById('chatprompt');
    const dataToSend = textarea.value;

	const spinner = document.getElementById('loading-spinner');

    console.log('Chat Run Prompt:', dataToSend);

	const sessExecId = document.getElementById('respExecutionId').value;

    const apiEndpoint = 'http://127.0.0.1:9030/agentserver/agent/runchat';
    //const apiEndpoint = document.getElementById('apiEndpointVal').value;

	const apiUrl = new URL(apiEndpoint);
	apiUrl.searchParams.append('executionId', sessExecId);
	
	const chat_body = {
	  "inputPrompt": dataToSend
	};

	const addHdrs = getHeaders();

    try {

		spinner.style.display = 'block'; 		

        const response = await fetch(apiUrl, {
            method: 'POST', 
			headers: addHdrs,
            body: JSON.stringify(chat_body)
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

		  document.getElementById('responseStep').textContent = result["stepResult"];
		  //document.getElementById('respExecutionId').value = result[0]["executionId"];
		  //document.getElementById('respSaveSubmit').disabled = true;
		  //document.getElementById('respDiscardClose').disabled = true;
		  //document.getElementById('respApprSess').disabled = true;
		  
		  //document.getElementById('execResponseJson').value = JSON.stringify(result, null, 2);
		  
    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
	} finally {
		spinner.style.display = 'none';
    }
}
</script>



<%--
agentResp executionId
agentResp projId
agentResp appName
agentResp userName
agentResp taskId
agentResp stepNumber
agentResp stepResult
agentResp status
agentResp requiresApproval
agentResp message
agentResp lastStep
--%>

<script>
async function getRespAndSubmit() {

    const formElement = document.getElementById('agtsave');
			if (!(formElement instanceof HTMLFormElement)) {
                console.error("Invalid form element provided.");
                return;
            }
			
		const additionalInput = document.createElement('input');
		additionalInput.type = 'hidden';
		additionalInput.name = 'executionId';
		additionalInput.value = document.getElementById('respExecutionId').value;
		formElement.appendChild(additionalInput);

    const saveRespData = document.getElementById('responseArea').textContent;
    const respArr = JSON.parse(saveRespData);

    if (!respArr.length) {
        console.log("No response data found.");
        return;
    }

		const additionalInput2 = document.createElement('input');
		additionalInput2.type = 'hidden';
		additionalInput2.name = 'totalTasks';
		additionalInput2.value = respArr.length;
		formElement.appendChild(additionalInput2);

	let m = 0;
	//let k = 0;
    respArr.forEach((resp, index) => {
        //const userFieldSet = document.createElement('fieldset');
        //const legend = document.createElement('legend');
        //legend.innerText = `User ${index + 1}`;
        //userFieldSet.appendChild(legend);

        // 3. Iterate over the key-value pairs of each object
        for (const key in resp) {
            if (Object.hasOwnProperty.call(resp, key)) {

				const additionalInput3 = document.createElement('input');
				additionalInput3.type = 'hidden';
				additionalInput3.name = key + m;
				additionalInput3.value = resp[key];
				formElement.appendChild(additionalInput3);

				//form_data[key + m]  = resp[key];
				//const field_id + m = key;
				//const field_val = user[key];
				//k++;
            }
        }
		m++;
    });

	formElement.submit();
}

</script>


<script>
async function getStepsAll() {

	const sessExecId = document.getElementById('respExecutionId').value;

    const apiEndpoint = 'http://127.0.0.1:9030/agentserver/agent/step-results';
    //const apiEndpoint = document.getElementById('apiEndpointVal').value;

	const apiUrl = new URL(apiEndpoint);
	apiUrl.searchParams.append('executionId', sessExecId);
	
	const addHdrs = getHeaders();
	
    try {
        const response = await fetch(apiUrl, {
            method: 'GET', 
			headers: addHdrs
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

		  //document.getElementById('respExecutionId').value = result[0]["executionId"];
		  document.getElementById('respSaveSubmit').disabled = false;
		  //document.getElementById('respDiscardClose').disabled = true;

		  document.getElementById('responseStep').textContent = '';

		  //document.getElementById('execResponseJson').value = JSON.stringify(result, null, 2);
		  
    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}
</script>


<script>
async function closeSessExec() {

	const sessExecId = document.getElementById('respExecutionId').value;

    const apiEndpoint = 'http://127.0.0.1:9030/agentserver/agent/close';
    //const apiEndpoint = document.getElementById('apiEndpointVal').value;

	const apiUrl = new URL(apiEndpoint);
	apiUrl.searchParams.append('executionId', sessExecId);

	const addHdrs = getHeaders();

    try {
        const response = await fetch(apiUrl, {
            method: 'GET', 
            headers: addHdrs
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        document.getElementById('responseArea').textContent = JSON.stringify(result, null, 2);
        console.log('Success:', result);

		  //document.getElementById('respExecutionId').value = result[0]["executionId"];
		  //document.getElementById('respSaveSubmit').disabled = true;
		  document.getElementById('respDiscardClose').disabled = true;
		  //document.getElementById('respApprSess').disabled = true;
		  //document.getElementById('respRejectStep').disabled = true;

		  document.getElementById('chat_send').disabled = true;
		  document.getElementById('respSaveSubmit').disabled = true;
		  document.getElementById('viewStepsAll').disabled = true;

		  document.getElementById('responseStep').textContent = '';

		  //document.getElementById('execResponseJson').value = JSON.stringify(result, null, 2);
		  
    } catch (error) {
        document.getElementById('responseArea').textContent = 'Error: ' + error.message;
        console.error('Error:', error);
    }
}
</script>

<%@ include file="agtproj_runimp_chart02.jsp" %>

<%--
<script>
async function showRespAsFormData(formElement) {

	const form_data = {
	  executionId: document.getElementById('respExecutionId').value,
	  appName: "MYTEMP02"
	};

	// Append a new field
	//form_data.userName = "MYTEMP02";

	console.log('form_data 1');
	console.log(form_data);
	
	
    const saveRespData = document.getElementById('responseArea').textContent;
    const respArr = JSON.parse(saveRespData);

    if (!respArr.length) {
        console.log("No response data found.");
        return;
    }

	let m = 0;
    respArr.forEach((resp, index) => {
        //const userFieldSet = document.createElement('fieldset');
        //const legend = document.createElement('legend');
        //legend.innerText = `User ${index + 1}`;
        //userFieldSet.appendChild(legend);

        // 3. Iterate over the key-value pairs of each object
        for (const key in resp) {
            if (Object.hasOwnProperty.call(resp, key)) {
				form_data[key + m]  = resp[key];
				//const field_id + m = key;
				//const field_val = user[key];
            }
        }
		m++;
    });

	console.log('form_data 2');
	console.log(form_data);
}

</script>
--%>

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

	&nbsp;&nbsp;  <button id="viewMermaid" onclick="showAsMermaid()" >
	<i class="fa fa-bar-chart" title="Show response with Mermaid as Diagram. Use prompt like 'Generate Mermaid Diagram Code'. "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewChartJs" onclick="showAsChartJs()" >
	<i class="fa fa-line-chart" title="Show response with chart.js as Diagram. Use prompt like 'Generate bar chart code snippet part for chart.js in format: new Chart(ctx,{ ... }); '  "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewMd" onclick="showAsMd()" >
	<i class="fa fa-file-o" title="Show response with Markdown as Html. Use prompt like 'Return Response as Markdown'. "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewCsv" onclick="showAsCsv()" >
	<i class="fa fa-tasks" title="Show response with CSV as Html. Use prompt like 'Return response in CSV format.' "></i>
	</button> 
	&nbsp;&nbsp;  <button id="viewExcel" onclick="dnldAsExcel()" >
	<i class="fa fa-table" title="Response with CSV, Download as Excel. "></i>
	</button> 

<!--
/*
 * Copyright (c) 2023 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wpsd" scope="page" class="em.Agtproj_taskcpypst" />
<%
	wpsd.processRequest(request, response);
	get_gui_str(wpsd.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wpsd.emerr;
	valid_login = wpsd.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Project Task Paste </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wpsd.usrnm;
%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wpsd.categ_name%></b></font></font></td>
</td>
</tr>
</table>
<BR>


	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String SendToUrlwpsd = "/"+usrproj+"/jsp/dn/agtproj.jsp?usrnm="+wpsd.usrnm +"&categ_id="+wpsd.categ_id+"&categ_name="+wpsd.categ_name+"&categ_levels="+wpsd.categ_levels+"&routeto="+wpsd.routeto+"&tm_now="+tm_now; 
	%>

	<%= bfont %> <b>Agent Project Task Paste</b></font><br>

	<% wpsd.doDbDataPaste(); %>
	<% wpsd.doneReq(); %>

<SCRIPT langauage="JavaScript">
<!--
function SendTo()
{
	window.location.href= "<%=SendToUrlwpsd%>";
}
function SendToLater()
{
	window.setTimeout("SendTo();", 2000);
}
	SendTo();
//-->
</SCRIPT>
<meta http-equiv="Refresh" content="0; url=<%=SendToUrlwpsd%>">
<noscript>
  <BR> <%= bfont %> Your browser does not seem to support JavaScript. </font>
  <BR> <%= bfont %> To continue <a href="<%=SendToUrlwpsd%>">Click Here</a>.</font><BR>
</noscript>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

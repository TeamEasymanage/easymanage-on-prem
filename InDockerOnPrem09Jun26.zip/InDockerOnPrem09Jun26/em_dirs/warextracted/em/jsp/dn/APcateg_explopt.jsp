<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%
	app_run = 1;
%>

<%@ include file="categ_explopt.jsp" %>

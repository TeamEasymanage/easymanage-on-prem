# setenv.sh

export CLASSPATH="$CLASSPATH:$CATALINA_HOME/lib/servlet-api.jar:$CATALINA_HOME/lib/jsp-api.jar:$CATALINA_HOME/lib/el-api.jar:$CATALINA_HOME/lib/annotations-api.jar"
export CLASSPATH="$CLASSPATH:/usr/local/tomcat/lib_jars/*"

package com.example.agentserver; 

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

// ------------------------------------------------------------ 
// Agentic AI
// ------------------------------------------------------------ 

@SpringBootApplication
public class AgentServerApp {

	public static void main(String[] args) {
		SpringApplication.run(AgentServerApp.class, args);
	}
}

package com.example.agentserver; 

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.tool.ToolCallback; 
import org.springframework.ai.chat.prompt.ChatOptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.time.LocalDateTime;

import com.example.agentserver.model.AgentExecution;

public class ChainAgent {

	private final ChatClient chatClient;

	private final String[] inputPrompts;
	private final AgentExecution execution;
	List<ToolCallback> toolsForExecution;

	public ChainAgent(ChatClient chatClient, String[] inputPrompts, AgentExecution execution, List<ToolCallback> toolsForExecution) {
		this.chatClient = chatClient;
		this.inputPrompts = inputPrompts;
		this.execution = execution;
		this.toolsForExecution = toolsForExecution;
	}

	public String executeStep(int stepIndex, String previousStepResult) {
		if (stepIndex < 0 || stepIndex >= inputPrompts.length) {
			throw new IllegalArgumentException("Invalid step index: " + stepIndex);
		}
		
		String prompt = inputPrompts[stepIndex];
		String input = String.format("%s", prompt);

		// Add context 
		String inputContext = execution.getAgentTasks()[stepIndex].inputContext();
		if ((inputContext != null) && inputContext.trim().length() > 0) {
			input = input + String.format("\n\n%s", inputContext);
		}
/*
For prevContext understanding
tasks|prompts[3]
stepIndex (0)
stepIndex (1)
stepIndex (2)

currentStep : 0,1,2,3 
	0-init
	1-after execute 1st prompt 
	2-after execute 2nd prompt 
	3-after execute 3rd prompt 
TotalSteps: 4 (given as +1)

[
  {
    "executionId": "782b0cd4-7151-42c9-b79f-3342dfaabbab",
    "status": "COMPLETED",
    "currentStep": 3,
    "totalSteps": 4,
    "stepResults": [
    [0]  "Project Id: 5010647",
    [1]  "2026-01-07T10:51:47.130767500 RESULT RESPONSE FOR stepIndex (0) Call MCP easymanage-mcp Tool get table schema for product",
    [2]  "2026-01-07T10:51:47.146392600 RESULT RESPONSE FOR stepIndex (1) Call MCP easymanage-mcp Tool get table data from product",
    [3]  "2026-01-07T10:51:47.178032800 RESULT RESPONSE FOR stepIndex (2) You will be given product table schema and data in context. Analyze table schema and data for insights. "
    ],
    "finalOutput": "2026-01-07T10:51:47.178032800 RESULT RESPONSE FOR stepIndex (2) You will be given product table schema and data in context. Analyze table schema and data for insights. ",
    "createdAt": "2026-01-07T10:51:47.0838829",
    "updatedAt": "2026-01-07T10:51:47.1780328",
    "rejectionReason": null,
    "requiresApproval": false
  }
]
*/
		String prevContextYN = "" + execution.getAgentTasks()[stepIndex].prevContextYN();

		//int doFmt = 1; //1=prompt, 2=inpContext, 3=prevContext

		if(!prevContextYN.equals("No") && stepIndex > 0 ) {

		int selTasks[] = { -1 };

			//NOTE: getSelStepResult PrevTask == stepResults[stepIndex]

			if(prevContextYN.equals("PrevTask")) {
				selTasks = new int[] { stepIndex };
			}
			if(prevContextYN.equals("AllTasks")) {
				selTasks = new int[stepIndex];
				for (int i=0; i < stepIndex; i++) {
					selTasks[i] = i+1;
				}
			}
			if(prevContextYN.equals("SelTasks")) {
			String prevContextSel = "" + execution.getAgentTasks()[stepIndex].prevContextSel();
			if ((prevContextSel != null) && prevContextSel.trim().length() > 0) {
				selTasks = Arrays.stream(prevContextSel.split("\\|"))
                               .mapToInt(Integer::parseInt)
                               .toArray();
				if (selTasks == null || selTasks.length < 1 ) {
					selTasks = new int[] { -1 };
				}
			}
			}

			// Now that we have stepIndex array find those and add context
			input = input + String.format("\n\nPrevious Step(s) Response(s):\n");

			for (int i=0; i<selTasks.length; i++) {
				System.out.println("Prev Context selTasks stepIndex: "+selTasks[i]);

				//validate sel Tasks within range
				if(selTasks[i] > 0 && selTasks[i] <= stepIndex) {

				String contextSvPrompt = "" + execution.getAgentTasks()[selTasks[i]-1].contextSvPrompt();
				String getSelStepResult = execution.getSelStepResult(selTasks[i]);
				input = input + String.format("\n%s \n%s", contextSvPrompt, getSelStepResult);
				}
			}

		}

		System.out.println("Final Prompt Input: \n"+input);

		//return LocalDateTime.now() + " RESULT RESPONSE FOR stepIndex ("+stepIndex+") "+prompt;

		/*
			Check switchModel first
			then check assigned model for this task
		*/
		String useSpecificModel = "";
		String switchModel = execution.getSwitchModel();
		if (switchModel != null && switchModel.trim().length() > 0) {
			useSpecificModel = switchModel;
		} else {
			//check assigned model for this task
			String projModel = execution.getAgentProj().projModel();

			if (projModel != null && projModel.trim().length() > 0) {
				useSpecificModel = projModel;
			} else {

				String taskModel = execution.getAgentTasks()[stepIndex].taskModel();
				if (taskModel != null && taskModel.trim().length() > 0) {
					useSpecificModel = taskModel;
				}

			}
		}

		// -----------------------------------------------------------------
		// RAG, Sem cache handling can also be added here based on task
		//	If Agent Server side flags enabled
		/*
		Define/Get from AgentExecutionService:
		@Value("${em.redis.sc}")
		private String scEnabled;
		@Value("${em.redis.rag}")
		private String ragEnabled;
		*/

		/*
		String ragYN = "" + execution.getAgentTasks()[stepIndex].ragYN();
		String ragFilter = "" + execution.getAgentTasks()[stepIndex].ragFilter();
		String semCacheYN = "" + execution.getAgentTasks()[stepIndex].semCacheYN();
		*/
		// -----------------------------------------------------------------

		if (useSpecificModel == null || useSpecificModel.trim().length() == 0) {
		return chatClient
				.prompt(input)
				.toolCallbacks(toolsForExecution)
				.call().content();
		} else {
		return chatClient
				.prompt(input)
	            //.options(openAIspecificOptions)
	            //.options(specificOptions)
				.options(ChatOptions.builder()
						.model(useSpecificModel)
						//.temperature(0.1)
						//.maxTokens(5)
						.build())
				.toolCallbacks(toolsForExecution)
				.call().content();
		}
	}
	
	public int getStepCount() {
		return inputPrompts.length;
	}
	
	public static class ChainResult {
		private final String finalOutput;
		private final List<String> stepResults;
		
		public ChainResult(String finalOutput, List<String> stepResults) {
			this.finalOutput = finalOutput;
			this.stepResults = stepResults;
		}
		
		public String getFinalOutput() {
			return finalOutput;
		}
		
		public List<String> getStepResults() {
			return stepResults;
		}
	}
}

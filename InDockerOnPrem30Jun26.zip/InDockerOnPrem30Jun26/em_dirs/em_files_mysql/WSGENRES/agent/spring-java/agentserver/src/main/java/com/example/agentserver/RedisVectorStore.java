package com.example.agentserver; 

public class RedisVectorStore {
}

/*
import org.springframework.ai.vectorstore.redis.RedisVectorStore;
import org.springframework.ai.vectorstore.redis.RedisVectorStore.Builder;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import redis.clients.jedis.JedisPooled;

@Configuration
public class VectorStoreConfig {

    @Bean
    public RedisVectorStore redisVectorStore(EmbeddingModel embeddingModel,
				JedisConnectionFactory jedisConnectionFactory) {
        return RedisVectorStore.builder(new JedisPooled(jedisConnectionFactory.getHostName(), jedisConnectionFactory.getPort()), embeddingModel)
                .indexName("ai-index")       // Custom index name
                .prefix("doc-store:")               // Custom key prefix
                .initializeSchema(true)             // Create index on startup
                //.vectorAlgorithm(Algorithm.HNSW)    // Set search algorithm
                .build();                           // Generate the VectorStore
    }
}
*/

/* 

// Load documents into the vector store

public class VectorStoreLoader {

    @Autowired
    private RedisVectorStore vectorStore;

    public void loadData() {
        List<Document> documents = List.of(
            new Document("Spring AI provides abstractions for AI development.", Map.of("category", "AI")),
            new Document("Redis is a powerful vector database.", Map.of("category", "Database"))
        );

        // convert content to embeddings and save to Redis
        vectorStore.add(documents);
    }
}

// Use the vector store in a ChatClient advisor
    public ChatController(ChatClient.Builder builder, VectorStore vectorStore) {
        // Build the ChatClient with a QuestionAnswerAdvisor
        this.chatClient = builder
                .defaultAdvisors(new QuestionAnswerAdvisor(vectorStore)) 
                .build();
    }

// Or

// Querying the vector store and add to context for agent reasoning
public class VectorStoreQuery {

    @Autowired
    private RedisVectorStore vectorStore;

    public void queryData(String query) {
        List<Document> results = vectorStore.search(query, 5); // Search for top 5 relevant documents
        results.forEach(doc -> System.out.println(doc.getContent()));
    }
}

// Use the query results in an agent's reasoning process
public class AgentReasoning {   

    @Autowired
    private VectorStoreQuery vectorStoreQuery;

    public void reason(String userInput) {
        // Get relevant documents based on user input
        vectorStoreQuery.queryData(userInput);
        
        // Use the retrieved documents to inform the agent's response
        // (e.g., combine with LLM output, apply logic, etc.)
    }
}

// Use Redis Semantic Cache
    public ChatController(ChatClient.Builder builder, VectorStore vectorStore) {
        this.chatClient = builder
            .defaultAdvisors(new SemanticCacheAdvisor(vectorStore)) // Intercepts calls
            .build();
    }

*/


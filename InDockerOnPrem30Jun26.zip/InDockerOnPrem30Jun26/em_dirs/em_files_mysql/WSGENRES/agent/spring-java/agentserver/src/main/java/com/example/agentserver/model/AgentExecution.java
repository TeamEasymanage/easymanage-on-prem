package com.example.agentserver.model; 

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.example.agentserver.model.AgentModels.AgentProj;
import com.example.agentserver.model.AgentModels.AgentTask;

public class AgentExecution {
    
    public enum Status {
        PENDING_APPROVAL,  // Waiting for human approval
        APPROVED,          // Step approved, proceeding
        REJECTED,          // Step rejected, agent stopped
        COMPLETED,         // All steps completed
        CANCELLED          // Agent cancelled
    }
    
    private final String executionId;

    private final String projId;
    private String[] inputPrompts;

    private Status status;
    private int currentStep;
    private List<String> stepResults;
    private String finalOutput;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String rejectionReason;
    private AgentProj agentProj;
    private AgentTask[] agentTasks;
    String switchModel;
    
    public AgentExecution(
            String projId, 
            String[] inputPrompts, 
            AgentProj agentProj, 
            AgentTask[] agentTasks,
            String switchModel
            ) {
        this.executionId = UUID.randomUUID().toString();
        this.projId = projId;
        this.inputPrompts = inputPrompts;
        this.status = Status.PENDING_APPROVAL;
        this.currentStep = 0;
        this.stepResults = new ArrayList<>();
        this.stepResults.add("Project Id: " +projId); // Step 0 is the input
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();

        this.agentProj = agentProj;
        this.agentTasks = agentTasks;
        this.switchModel = switchModel;

    }

    public void setAgentTasks(AgentTask[] agentTasks) {
        this.agentTasks = agentTasks;
    }

    public void setInputPrompts(String[] inputPrompts) {
        this.inputPrompts = inputPrompts;
    }

    public AgentProj getAgentProj() {
        return agentProj;
    }

    public AgentTask[] getAgentTasks() {
        return agentTasks;
    }

    public String getExecutionId() {
        return executionId;
    }
    
    public String getProjId() {
        return projId;
    }

    // ---------- enh
    public String getAppName() {
        return getAgentProj().appName();
    }

    public String getUserName() {
        return getAgentProj().userName();
    }

    public String getTaskId() {
        return getAgentTasks()[currentStep-1].taskId();
    }
    public String getSwitchModel() {
        return switchModel;
    }
    /*
    public String getAssignedModel() {

        String modelOpt = getAgentProj().projModel();
   		if (modelOpt == null || modelOpt.trim().length() == 0) {
            modelOpt = getAgentTasks()[currentStep-1].taskModel();
        }
        return modelOpt;
    }
    */
    // ---------- enh

    public String[] getInputPrompts() {
        return inputPrompts;
    }
    
    public Status getStatus() {
        return status;
    }
    
    public void setStatus(Status status) {
        this.status = status;
        this.updatedAt = LocalDateTime.now();
    }
    
    public int getCurrentStep() {
        return currentStep;
    }
    
    public void setCurrentStep(int currentStep) {
        this.currentStep = currentStep;
        this.updatedAt = LocalDateTime.now();
    }
    
    public List<String> getStepResults() {
        return stepResults;
    }
    
    public void addStepResult(String result) {
        this.stepResults.add(result);
        this.updatedAt = LocalDateTime.now();
    }
    
    public String getFinalOutput() {
        return finalOutput;
    }
    
    public void setFinalOutput(String finalOutput) {
        this.finalOutput = finalOutput;
        this.updatedAt = LocalDateTime.now();
    }
    
    public LocalDateTime getCreatedAt() {
        return createdAt;
    }
    
    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
    
    public String getRejectionReason() {
        return rejectionReason;
    }
    
    public void setRejectionReason(String rejectionReason) {
        this.rejectionReason = rejectionReason;
        this.updatedAt = LocalDateTime.now();
    }
    
    public String getCurrentStepResult() {
        if (stepResults.isEmpty() || currentStep >= stepResults.size()) {
            return null;
        }
        return stepResults.get(currentStep);
    }

    public String getSelStepResult(int selStep) {
        if (stepResults.isEmpty() || selStep >= stepResults.size()) {
            return null;
        }
        return stepResults.get(selStep);
    }

    public boolean isLastStep() {
        return currentStep >= inputPrompts.length;
    }
    
    /**
     * Gets the step result at a specific step index.
     * 
     * @param stepIndex the step index (0 = input, 1+ = step results)
     * @return the step result, or null if index is invalid
     */
    public String getStepResult(int stepIndex) {
        if (stepIndex < 0 || stepIndex >= stepResults.size()) {
            return null;
        }
        return stepResults.get(stepIndex);
    }
    
    /**
     * Gets the number of completed steps (including input).
     * 
     * @return the number of step results available
     */
    public int getCompletedStepCount() {
        return stepResults.size();
    }
    
    /**
     * Restores the agent to a specific step.
     * Removes all steps after the restore point and resets state.
     * 
     * @param stepIndex the step index to restore to (0 = input, 1+ = step results)
     * @return true if restore was successful, false if step index is invalid
     */
    public boolean restoreToStep(int stepIndex) {
        if (stepIndex < 0 || stepIndex >= stepResults.size()) {
            return false;
        }
        
        // Remove all steps after the restore point
        if (stepIndex < stepResults.size() - 1) {
            stepResults = new ArrayList<>(stepResults.subList(0, stepIndex + 1));
        }
        
        // Reset current step to the restore point
        this.currentStep = stepIndex;
        
        // Reset status
        if (stepIndex == 0) {
            // At input step, allow execution to start
            this.status = Status.PENDING_APPROVAL;
        } else {
            // At a result step, require approval
            this.status = Status.PENDING_APPROVAL;
        }
        
        // Clear final output if it was set
        this.finalOutput = null;
        
        // Clear rejection reason if it was set
        this.rejectionReason = null;
        
        this.updatedAt = LocalDateTime.now();
        return true;
    }
    
    /**
     * Gets a list of available restore points.
     * Each restore point represents a step that can be restored to.
     * 
     * @return list of step indices that can be restored to
     */
    public List<Integer> getAvailableRestorePoints() {
        List<Integer> restorePoints = new ArrayList<>();
        for (int i = 0; i < stepResults.size(); i++) {
            restorePoints.add(i);
        }
        return restorePoints;
    }
}


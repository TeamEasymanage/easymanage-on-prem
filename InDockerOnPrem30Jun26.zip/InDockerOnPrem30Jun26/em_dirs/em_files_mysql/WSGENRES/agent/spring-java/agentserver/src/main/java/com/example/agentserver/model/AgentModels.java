package com.example.agentserver.model; 

public class AgentModels {
    
    // --------------- models 
	public static record AgentProj(
        String projId,
        String appName,
        String agentName,
        int toolLimit,
        String toolNameIncl,
        String toolNameExcl,
        String sysPrompt,
        String userName,
        String projModel
        /*
        int maxTasks,
        int maxLoops,
        String autoApprYN
        */
        ) {
	}

	public static record AgentTask(
        String taskId,
        int taskOrd,
        String taskName,
        String promptType, // main, sub, aggregator
        String inputPrompt,
        // ?EVAL assign table
        // tableId (product), utilType (CRUD), 
        // utilId (get_table_data_queried_product), utilPrompt (...)
        String inputContext,
        String prevContextYN,   //No, PrevTask, AllTasks, SelTasks
        String prevContextSel,  // '' , '1|2'
        //?String prevContextType, // json, text, log 
        String contextSvPrompt,
        String taskModel,
        String ragYN,
        String ragFilter,
        String semCacheYN
        /*
        String respJsonYN,
        String respFileYN,
        String logFileYN
        */
        ) {
	}

	public static record AgentStartRequest(
        AgentProj agentProj, 
        AgentTask[] agentTasks
        ) {
	}

	public static record ChatRequest(
        String inputPrompt
        ) {
	}

}


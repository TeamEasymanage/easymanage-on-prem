package com.example.agentserver.model; 

public class AgentStepResponse {
    
    private String executionId;
    private String projId;
    private String appName;
    private String userName;
    private String taskId;
    private int stepNumber;
    private String stepResult;
    private String status;
    private boolean requiresApproval;
    private boolean isLastStep;
    private String message;
    private String stepPrompt;
    
    public AgentStepResponse() {
    }

    public AgentStepResponse(String executionId, 
    String projId,
    String appName,
    String userName,
    String taskId,
    int stepNumber, String stepResult, 
                                String status, boolean requiresApproval, boolean isLastStep) {
        this.executionId = executionId;
    this.projId   = projId;
    this.appName  = appName;
    this.userName  = userName;
    this.taskId = taskId;
        this.stepNumber = stepNumber;
        this.stepResult = stepResult;
        this.status = status;
        this.requiresApproval = requiresApproval;
        this.isLastStep = isLastStep;
    }

    public AgentStepResponse(String executionId, 
    String projId,
    String appName,
    String userName,
    String taskId,
    int stepNumber, String stepResult, 
                                String status, boolean requiresApproval, boolean isLastStep, String stepPrompt) {
        this.executionId = executionId;
    this.projId   = projId;
    this.appName  = appName;
    this.userName  = userName;
    this.taskId = taskId;
        this.stepNumber = stepNumber;
        this.stepResult = stepResult;
        this.status = status;
        this.requiresApproval = requiresApproval;
        this.isLastStep = isLastStep;
        this.stepPrompt = stepPrompt;
    }

    public AgentStepResponse(String executionId, int stepNumber, String stepResult, 
                                String status, boolean requiresApproval, boolean isLastStep) {
        this.executionId = executionId;
        this.stepNumber = stepNumber;
        this.stepResult = stepResult;
        this.status = status;
        this.requiresApproval = requiresApproval;
        this.isLastStep = isLastStep;
    }
    
    public String getExecutionId() {
        return executionId;
    }


    public String getProjId() {
        return projId;
    }

    // ---------- enh
    public String getAppName() {
        return appName;
    }

    public String getUserName() {
        return userName;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }
    
    public int getStepNumber() {
        return stepNumber;
    }
    
    public void setStepNumber(int stepNumber) {
        this.stepNumber = stepNumber;
    }
    
    public String getStepResult() {
        return stepResult;
    }
    
    public void setStepResult(String stepResult) {
        this.stepResult = stepResult;
    }
    
    public String getStatus() {
        return status;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public boolean isRequiresApproval() {
        return requiresApproval;
    }
    
    public void setRequiresApproval(boolean requiresApproval) {
        this.requiresApproval = requiresApproval;
    }
    
    public boolean isLastStep() {
        return isLastStep;
    }
    
    public void setLastStep(boolean lastStep) {
        isLastStep = lastStep;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    public String getStepPrompt() {
        return stepPrompt;
    }
    
    public void setStepPrompt(String stepPrompt) {
        this.stepPrompt = stepPrompt;
    }
}


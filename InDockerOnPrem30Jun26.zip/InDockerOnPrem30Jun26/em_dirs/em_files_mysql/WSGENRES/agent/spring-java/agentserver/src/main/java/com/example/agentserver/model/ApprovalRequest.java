package com.example.agentserver.model; 

public class ApprovalRequest {
    
    private boolean approved;
    private String reason;
    
    public ApprovalRequest() {
    }
    
    public ApprovalRequest(boolean approved) {
        this.approved = approved;
    }
    
    public ApprovalRequest(boolean approved, String reason) {
        this.approved = approved;
        this.reason = reason;
    }
    
    public boolean isApproved() {
        return approved;
    }
    
    public void setApproved(boolean approved) {
        this.approved = approved;
    }
    
    public String getReason() {
        return reason;
    }
    
    public void setReason(String reason) {
        this.reason = reason;
    }
}

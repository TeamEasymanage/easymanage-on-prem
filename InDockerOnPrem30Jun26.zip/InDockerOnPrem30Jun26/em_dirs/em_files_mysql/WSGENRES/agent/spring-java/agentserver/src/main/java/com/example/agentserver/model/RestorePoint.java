package com.example.agentserver.model; 

public class RestorePoint {
    
    private int stepIndex;
    private String stepResult;
    private String description;
    private boolean isCurrentStep;
    
    public RestorePoint() {
    }
    
    public RestorePoint(int stepIndex, String stepResult, String description, boolean isCurrentStep) {
        this.stepIndex = stepIndex;
        this.stepResult = stepResult;
        this.description = description;
        this.isCurrentStep = isCurrentStep;
    }
    
    public int getStepIndex() {
        return stepIndex;
    }
    
    public void setStepIndex(int stepIndex) {
        this.stepIndex = stepIndex;
    }
    
    public String getStepResult() {
        return stepResult;
    }
    
    public void setStepResult(String stepResult) {
        this.stepResult = stepResult;
    }
    
    public String getDescription() {
        return description;
    }
    
    public void setDescription(String description) {
        this.description = description;
    }
    
    public boolean isCurrentStep() {
        return isCurrentStep;
    }
    
    public void setCurrentStep(boolean currentStep) {
        isCurrentStep = currentStep;
    }
}


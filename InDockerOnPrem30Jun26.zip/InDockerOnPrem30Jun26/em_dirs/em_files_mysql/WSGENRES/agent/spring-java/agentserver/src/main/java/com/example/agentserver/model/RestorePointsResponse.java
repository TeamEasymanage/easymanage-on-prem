package com.example.agentserver.model; 

import java.util.List;

public class RestorePointsResponse {
    
    private String executionId;
    private int currentStep;
    private List<RestorePoint> restorePoints;
    private String message;
    
    public RestorePointsResponse() {
    }
    
    public RestorePointsResponse(String executionId, int currentStep, List<RestorePoint> restorePoints) {
        this.executionId = executionId;
        this.currentStep = currentStep;
        this.restorePoints = restorePoints;
    }
    
    public String getExecutionId() {
        return executionId;
    }
    
    public void setExecutionId(String executionId) {
        this.executionId = executionId;
    }
    
    public int getCurrentStep() {
        return currentStep;
    }
    
    public void setCurrentStep(int currentStep) {
        this.currentStep = currentStep;
    }
    
    public List<RestorePoint> getRestorePoints() {
        return restorePoints;
    }
    
    public void setRestorePoints(List<RestorePoint> restorePoints) {
        this.restorePoints = restorePoints;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
}


package com.example.agentserver.model; 

public class RestoreRequest {
    
    /**
     * The step index to restore to (0 = input, 1+ = step results).
     */
    private int stepIndex;
    
    /**
     * Whether to re-execute from the restore point (true) or just restore state (false).
     * If true, the step at restore point will be re-executed.
     */
    private boolean reExecute;
    
    public RestoreRequest() {
    }
    
    public RestoreRequest(int stepIndex) {
        this.stepIndex = stepIndex;
        this.reExecute = false;
    }
    
    public RestoreRequest(int stepIndex, boolean reExecute) {
        this.stepIndex = stepIndex;
        this.reExecute = reExecute;
    }
    
    public int getStepIndex() {
        return stepIndex;
    }
    
    public void setStepIndex(int stepIndex) {
        this.stepIndex = stepIndex;
    }
    
    public boolean isReExecute() {
        return reExecute;
    }
    
    public void setReExecute(boolean reExecute) {
        this.reExecute = reExecute;
    }
}


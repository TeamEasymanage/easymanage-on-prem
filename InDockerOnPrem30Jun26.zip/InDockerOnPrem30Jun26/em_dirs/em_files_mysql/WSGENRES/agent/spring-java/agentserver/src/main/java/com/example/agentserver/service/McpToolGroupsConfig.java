package com.example.agentserver.service; 

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import java.util.HashMap;
import java.util.Map;

@Configuration
@ConfigurationProperties(prefix = "em.mcptools")
public class McpToolGroupsConfig {

    // Spring automatically captures all dynamic keys under "em.mcptools.mcpgroup.*"
    private Map<String, String> mcpgroup = new HashMap<>();

    public Map<String, String> getMcpgroup() {
        return mcpgroup;
    }

    public void setMcpgroup(Map<String, String> mcpgroup) {
        this.mcpgroup = mcpgroup;
    }
}

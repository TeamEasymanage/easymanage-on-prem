package com.example.agentserver.util;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.http.ProblemDetail;

import com.example.agentserver.util.BadRequestException;


@RestControllerAdvice
public class RestExceptionHandler {

    /*
    // Handles a specific custom exception
    @ExceptionHandler(ResourceNotFoundException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse handleNotFound(ResourceNotFoundException ex) {
        return new ErrorResponse("NOT_FOUND", ex.getMessage());
    }
    */

    // Handle custom business exceptions
    @ExceptionHandler(BadRequestException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ProblemDetail handleCustomBadRequest(BadRequestException ex) {

		System.err.println("Exception Error message: " + ex.getMessage()); 

        return ProblemDetail.forStatusAndDetail(HttpStatus.BAD_REQUEST, "BAD_REQUEST: " + ex.getMessage());
    }

    // Handles all other generic exceptions
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ProblemDetail handleGlobalException(Exception ex) {

		System.err.println("Exception Error message: " + ex.getMessage()); 

        return ProblemDetail.forStatusAndDetail(HttpStatus.INTERNAL_SERVER_ERROR, "An unexpected error occurred: " + ex.getMessage());
    }
}

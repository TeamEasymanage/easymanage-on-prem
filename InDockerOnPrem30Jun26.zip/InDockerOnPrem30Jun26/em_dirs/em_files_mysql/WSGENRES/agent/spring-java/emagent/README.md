# AI Agents - Spring Java

## AI Agent `emagent`

* Agentic System Workflows with agentic patterns Prompt-Chaining, Prallelization with access to MCP Tools
* Low-code customize to build AI solutions

## Prompt Chaining Workflow Example

This project module demonstrates the Prompt Chaining workflow pattern for Large Language Models (LLMs) using Spring AI. The pattern decomposes complex tasks into a sequence of steps, where each LLM call processes the output of the previous one.

### Implementation

This implementation has a three-step workflow automation for retriving table schema & data from MCP Server tools, and analyze it for insights and trends.

## Parallelization Workflow Example

This project module demonstrates the implementation of the Parallelization Workflow pattern using Spring AI, enabling efficient concurrent processing of multiple Large Language Model (LLM) operations.

### Implementation

This implementation has a three-step workflow automation
   - Retriving table schema & data from MCP Server tools in parallel, 
   - their output aggregation,
   - and finally analyze it for insights and trends.

## Prerequisite

* Note: We recommend using REST as more features are implemented/available.

* EasyManage : Backend : Spring Java - REST
   - Build and Run project from
   - `backend/spring-java/emapi`
   - Test APIs are running: http://127.0.0.1:9080/swagger-ui/index.html
* EasyManage MCP Server For REST : Server Transport : STDIO
 - Project location
 - `mcp/spring-java/emmcp`
 - Build project
 - `mvn clean install`
 - Make sure below maven artifact is available for Agent project : 
 - `com.example.emmcp:base-app`

Log part from `mvn clean install`

 ```
 [INFO] --- install:3.1.3:install (default-install) @ base-app ---
[INFO] Installing C:\Users\JohnDoe\Downloads\EmGenDir_JohnDoe_WS_50202_T1\WS_50202\ai\spring-java\emmcp\lib\base-app\pom.xml to C:\Users\JohnDoe\.m2\repository\com\example\emmcp\base-app\1.0-SNAPSHOT\base-app-1.0-SNAPSHOT.pom
[INFO] Installing C:\Users\JohnDoe\Downloads\EmGenDir_JohnDoe_WS_50202_T1\WS_50202\ai\spring-java\emmcp\lib\base-app\target\base-app-1.0-SNAPSHOT.jar to C:\Users\JohnDoe\.m2\repository\com\example\emmcp\base-app\1.0-SNAPSHOT\base-app-1.0-SNAPSHOT.jar
 ```

* How is MCP project run? : When using transport STDIO, Agent project will invoke MCP project internally with cmd like:
 - `java -jar ../../../mcp/spring-java/emmcp/app/mcprest/target/mcprest-1.0-SNAPSHOT.jar`
 - Refer: `emagent\src\main\resources\mcp.json`

## Getting Started

* Set env var: `OPENAI_API_KEY`

1. Build the project:
   ```bash
   ./mvnw clean install
   ```

2. Run the application:
   ```bash
   ./mvnw spring-boot:run
   ```

## Prompt Chaining Vs Parallel

* Edit/set in App file:
  - Edit `src\main\java\com\example\emagent\app\EmAgentSpringApp.java`
  - Default is Chaining: `String runPattern = "chain"; //chain|parallel`
  - To Set Parallel: `String runPattern = "parallel"; //chain|parallel`


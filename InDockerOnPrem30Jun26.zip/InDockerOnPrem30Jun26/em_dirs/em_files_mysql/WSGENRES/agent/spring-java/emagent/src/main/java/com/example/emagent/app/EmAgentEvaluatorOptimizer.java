package com.example.emagent.app; 
 
import org.springframework.ai.chat.client.ChatClient; 
 
import java.util.*; 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 

public class EmAgentEvaluatorOptimizer { 

	private static final Logger logger = LoggerFactory.getLogger(EmAgentEvaluatorOptimizer.class); 

	private String processMode = "Plan";

	private static int loopCounter = 1;
	//private int maxLoops = 4;
	/*
	public static final String generatorPrompt = """
			Your goal is to Call MCP easymanage-mcp Tool and fetch table schema and data for the input tables. 

			Respond with table schema and data as text response and your thoughts.

			""";
	*/

	public static final String generatorPrompt = """
			Your goal is to complete the task based on the input. If there are feedback
			from your previous generations, you should reflect on them to improve your solution.

			CRITICAL: Your response must be a SINGLE LINE of valid JSON with NO LINE BREAKS except those explicitly escaped with \\n.
			Here is the exact format to follow, including all quotes and braces:

			{"thoughts":"Brief description here","response":"public class Example {\\n    // Code here\\n}"}

			Rules for the response field:
			1. ALL line breaks must use \\n
			2. ALL quotes must use \\"
			3. ALL backslashes must be doubled: \\
			4. NO actual line breaks or formatting - everything on one line
			5. NO tabs or special characters
			6. Java code must be complete and properly escaped

			Example of properly formatted response:
			{"thoughts":"Implementing counter","response":"public class Counter {\\n    private int count;\\n    public Counter() {\\n        count = 0;\\n    }\\n    public void increment() {\\n        count++;\\n    }\\n}"}

			Follow this format EXACTLY - your response must be valid JSON on a single line.
			""";

	/*
	public static final String evaluatorPrompt = """
			Evaluate supplied table schemas and data for fitness for AI model training, assesses it against criteria:

			Criterion 1: (Sensitive Data): Are there columns that come under Sensitive data, PII (Personally Identifiable Information), Confidential Business Information, Data revealing sensitive personal information? 
			Criterion 2: (Compliance): Does it comply with GDPR, HIPAA, and other regulations? 
			Criterion 3: (Bias and fairness): Verify data is acceptable as per Legal; Ethical; Unbiased; Non-discriminatory 
			Criterion 4: (Data Available): Is table data available and complete and good quality? 

			Respond with EXACTLY this JSON format on a single line:

			{"evaluation":"PASS, NEEDS_IMPROVEMENT, or FAIL", "feedback":"Your feedback here"}

			The evaluation field must be one of: "PASS", "NEEDS_IMPROVEMENT", "FAIL"
			Use "PASS" only if all criteria are met with no improvements needed.
			""";
	*/

	public static final String evaluatorPrompt = """
			Evaluate this code implementation for correctness, time complexity, and best practices.
			Ensure the code have proper javadoc documentation.
			Respond with EXACTLY this JSON format on a single line:

			{"evaluation":"PASS, NEEDS_IMPROVEMENT, or FAIL", "feedback":"Your feedback here"}

			The evaluation field must be one of: "PASS", "NEEDS_IMPROVEMENT", "FAIL"
			Use "PASS" only if all criteria are met with no improvements needed.
			""";


	private final ChatClient chatClient; 

	public static record Generation(String response, String thoughts) {
	}
	public static record EvaluationResponse(Evaluation evaluation, String feedback) {

		public enum Evaluation {
			PASS, NEEDS_IMPROVEMENT, FAIL
		}
	}
	public static record RefinedResponse(String solution, List<Generation> chainOfThought) {
	}
 
	public EmAgentEvaluatorOptimizer(ChatClient chatClient) { 
		this.chatClient = chatClient; 
	} 

	public RefinedResponse loop(String task) {
		List<String> memory = new ArrayList<>();
		List<Generation> chainOfThought = new ArrayList<>();

		System.out.println("--------------------");
		System.out.println("Process Mode = ["+processMode+"]");
		//System.out.println("Set maxLoops = ["+maxLoops+"]");
		System.out.println("1st loop loopCounter = ["+loopCounter+"]");

		return loop(task, "", memory, chainOfThought);
	}
	private RefinedResponse loop(String task, String context, List<String> memory,
			List<Generation> chainOfThought) {

		System.out.println("--------------------");
		System.out.println("Loop loopCounter = ["+loopCounter+"]");

		Generation generation = generate(task, context);

		memory.add(generation.response());
		chainOfThought.add(generation);

		EvaluationResponse evaluationResponse = evalute(generation.response(), task);

		if (evaluationResponse.evaluation().equals(EvaluationResponse.Evaluation.PASS)) {
			// Solution is accepted!
			return new RefinedResponse(generation.response(), chainOfThought);
		}

		// Accumulated new context including the last and the previous attempts and
		// feedbacks.
		StringBuilder newContext = new StringBuilder();
		newContext.append("Previous attempts:");
		for (String m : memory) {
			newContext.append("\n- ").append(m);
		}
		newContext.append("\nFeedback: ").append(evaluationResponse.feedback());

		System.out.println("newContext ["+loopCounter+"]: "+newContext);

		/*
		// For maxLoops breaker
		if (loopCounter >= maxLoops) {
			return new RefinedResponse(generation.response(), chainOfThought);
		}
		*/

		loopCounter++;

		return loop(task, newContext.toString(), memory, chainOfThought);
	}

	private Generation generate(String task, String context) {
		Generation generationResponse = chatClient.prompt()
				.user(u -> u.text("{prompt}\n{context}\nTask: {task}")
						.param("prompt", this.generatorPrompt)
						.param("context", context)
						.param("task", task))
				.call()
				.entity(Generation.class);

		System.out.println(String.format("\n=== GENERATOR OUTPUT ===\nTHOUGHTS: %s\n\nRESPONSE:\n %s\n",
				generationResponse.thoughts(), generationResponse.response()));
		return generationResponse;
	}

	private EvaluationResponse evalute(String content, String task) {

		System.out.println("\n=== Processing Evaluator Prompt ["+loopCounter+"]: ===\n");
		//System.out.println(this.evaluatorPrompt);

		EvaluationResponse evaluationResponse = chatClient.prompt()
				.user(u -> u.text("{prompt}\nOriginal task: {task}\nContent to evaluate: {content}")
						.param("prompt", this.evaluatorPrompt)
						.param("task", task)
						.param("content", content))
				.call()
				.entity(EvaluationResponse.class);

		System.out.println(String.format("\n=== EVALUATOR OUTPUT ===\nEVALUATION: %s\n\nFEEDBACK: %s\n",
				evaluationResponse.evaluation(), evaluationResponse.feedback()));
		return evaluationResponse;
	}

} 

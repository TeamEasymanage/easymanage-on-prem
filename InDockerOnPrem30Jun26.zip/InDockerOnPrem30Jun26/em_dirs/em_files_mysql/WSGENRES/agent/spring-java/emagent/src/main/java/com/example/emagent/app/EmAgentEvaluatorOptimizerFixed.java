package com.example.emagent.app; 
 
import org.springframework.ai.chat.client.ChatClient; 
 
import java.util.*; 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 

public class EmAgentEvaluatorOptimizerFixed { 

	private static final Logger logger = LoggerFactory.getLogger(EmAgentEvaluatorOptimizer.class); 

	private String processMode = "Plan";

	private static int loopCounter = 1;
	public static final String generatorPrompt = """
			Your goal is to Call MCP easymanage-mcp Tool and fetch table schema and data for the input tables. 

			Respond with table schema and data as text response and your thoughts.

			""";

	public static final String[] evaluationCriteria = {
			"Criterion 1: (Sensitive Data): Are there columns that come under Sensitive data, PII (Personally Identifiable Information), Confidential Business Information, Data revealing sensitive personal information? ",
			"Criterion 2: (Compliance): Does it comply with GDPR, HIPAA, and other regulations? ",
			"Criterion 3: (Bias and fairness): Verify data is acceptable as per Legal; Ethical; Unbiased; Non-discriminatory ",
			"Criterion 4: (Data Available): Is table data available and complete and good quality? "
	};
	private int maxLoops = evaluationCriteria.length;

	public static final String evaluatorPrompt = """
			Evaluate supplied table schemas and data for fitness for AI model training, assesses it against criteria:

			%s

			Respond with EXACTLY this JSON format on a single line:

			{"evaluation":"PASS, NEEDS_IMPROVEMENT, or FAIL", "feedback":"Your feedback here"}

			The evaluation field must be one of: "PASS", "NEEDS_IMPROVEMENT", "FAIL"
			Use "PASS" only if all criteria are met with no improvements needed.
			""";


	private final ChatClient chatClient; 

	public static record Generation(String response, String thoughts) {
	}
	public static record EvaluationResponse(Evaluation evaluation, String feedback) {

		public enum Evaluation {
			PASS, NEEDS_IMPROVEMENT, FAIL
		}
	}
	public static record RefinedResponseFixed(String solution, List<Generation> chainOfThought) {
	}
 
	public EmAgentEvaluatorOptimizerFixed(ChatClient chatClient) { 
		this.chatClient = chatClient; 
	} 

	public RefinedResponseFixed loop(String task) {
		List<String> memory = new ArrayList<>();
		List<Generation> chainOfThought = new ArrayList<>();

		System.out.println("--------------------");
		System.out.println("Process Mode = ["+processMode+"]");
		System.out.println("Set maxLoops = ["+maxLoops+"]");
		System.out.println("1st loop loopCounter = ["+loopCounter+"]");

		return loop(task, "", memory, chainOfThought);
	}
	private RefinedResponseFixed loop(String task, String context, List<String> memory,
			List<Generation> chainOfThought) {

		System.out.println("--------------------");
		System.out.println("Loop loopCounter = ["+loopCounter+"]");

		Generation generation = new Generation("","");
		if (processMode.equals("Plan")) {
		generation = new Generation("Gen Resp "+loopCounter,"Thoughts "+ loopCounter);
		} else {
		generation = generate(task, context);
		}

		memory.add(generation.response());
		chainOfThought.add(generation);

		EvaluationResponse evaluationResponse = new EvaluationResponse(EvaluationResponse.Evaluation.NEEDS_IMPROVEMENT,"");

		if (processMode.equals("Plan")) {
		evaluationResponse = new EvaluationResponse(EvaluationResponse.Evaluation.NEEDS_IMPROVEMENT, "Feedback "+loopCounter);
		} else {
		evaluationResponse = evalute(generation.response(), task);
		}

		if (evaluationResponse.evaluation().equals(EvaluationResponse.Evaluation.PASS)) {
			// Solution is accepted!
			return new RefinedResponseFixed(generation.response(), chainOfThought);
		}

		// Accumulated new context including the last and the previous attempts and
		// feedbacks.
		StringBuilder newContext = new StringBuilder();
		newContext.append("Previous attempts after ["+loopCounter+"]:");
		for (String m : memory) {
			newContext.append("\n- ").append(m);
		}
		newContext.append("\nFeedback: ").append(evaluationResponse.feedback());

		System.out.println("evaluationCriteria at ["+loopCounter+"]: "+evaluationCriteria[loopCounter-1]);
		System.out.println("newContext ["+loopCounter+"]: "+newContext);

		if (loopCounter >= maxLoops) {
			return new RefinedResponseFixed(generation.response(), chainOfThought);
		}

		loopCounter++;

		return loop(task, newContext.toString(), memory, chainOfThought);
	}

	private Generation generate(String task, String context) {
		String genResponse = chatClient.prompt()
				.user(u -> u.text("{prompt}\n{context}\nTask: {task}")
						.param("prompt", this.generatorPrompt)
						.param("context", context)
						.param("task", task))
				.call()
				.content();
				//.entity(Generation.class);
		Generation generationResponse = new Generation(genResponse, "Done");

		System.out.println(String.format("\n=== GENERATOR OUTPUT ===\nTHOUGHTS: %s\n\nRESPONSE:\n %s\n",
				generationResponse.thoughts(), generationResponse.response()));
		return generationResponse;
	}

	private EvaluationResponse evalute(String content, String task) {

		System.out.println("\n=== Processing Evaluator Prompt ["+loopCounter+"]: ===\n");
		System.out.println(String.format(this.evaluatorPrompt, evaluationCriteria[loopCounter-1]));

		EvaluationResponse evaluationResponse = chatClient.prompt()
				.user(u -> u.text("{prompt}\nOriginal task: {task}\nContent to evaluate: {content}")
						.param("prompt", String.format(this.evaluatorPrompt, evaluationCriteria[loopCounter-1]))
						.param("task", task)
						.param("content", content))
				.call()
				.entity(EvaluationResponse.class);

		System.out.println(String.format("\n=== EVALUATOR OUTPUT ===\nEVALUATION: %s\n\nFEEDBACK: %s\n",
				evaluationResponse.evaluation(), evaluationResponse.feedback()));
		return evaluationResponse;
	}

} 

package com.example.emagent.app; 
 
import org.springframework.ai.chat.client.ChatClient; 
 
import java.util.*; 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 
import org.springframework.util.Assert;

public class EmAgentOrchestratorWorkers { 

	private static final Logger logger = LoggerFactory.getLogger(EmAgentOrchestratorWorkers.class); 

	private static int loopCounter = 1;
	//private int maxLoops = 4;

	public static final String orchestratorPrompt = """
			Analyze this task and break it down into 2-3 distinct approaches:

			Task: {task}

			Return your response in this JSON format:
			\\{
			"analysis": "Explain your understanding of the task and which variations would be valuable.
			             Focus on how each approach serves different aspects of the task.",
			"tasks": [
				\\{
				"type": "formal",
				"description": "Write a precise, technical version that emphasizes specifications"
				\\},
				\\{
				"type": "conversational",
				"description": "Write an engaging, friendly version that connects with readers"
				\\}
			]
			\\}
			""";

	public static final String workerPrompt = """
			Generate content based on:
			Task: {original_task}
			Style: {task_type}
			Guidelines: {task_description}
			""";

	private final ChatClient chatClient; 

	public static record Task(String type, String description) {
	}

	public static record OrchestratorResponse(String analysis, List<Task> tasks) {
	}

	public static record FinalResponse(String analysis, List<String> workerResponses) {
	}
 
	public EmAgentOrchestratorWorkers(ChatClient chatClient) { 
		this.chatClient = chatClient; 
	} 

	@SuppressWarnings("null")
	public FinalResponse process(String taskDescription) {
		Assert.hasText(taskDescription, "Task description must not be empty");

		// Step 1: Get orchestrator response
		OrchestratorResponse orchestratorResponse = this.chatClient.prompt()
				.user(u -> u.text(this.orchestratorPrompt)
						.param("task", taskDescription))
				.call()
				.entity(OrchestratorResponse.class);

		System.out.println(String.format("\n=== ORCHESTRATOR OUTPUT ===\nANALYSIS: %s\n\nTASKS: %s\n",
				orchestratorResponse.analysis(), orchestratorResponse.tasks()));

		// Step 2: Process each task
		List<String> workerResponses = orchestratorResponse.tasks().stream().map(task -> this.chatClient.prompt()
				.user(u -> u.text(this.workerPrompt)
						.param("original_task", taskDescription)
						.param("task_type", task.type())
						.param("task_description", task.description()))
				.call()
				.content()).toList();

		System.out.println("\n=== WORKER OUTPUT ===\n" + workerResponses);

		return new FinalResponse(orchestratorResponse.analysis(), workerResponses);
	}

} 

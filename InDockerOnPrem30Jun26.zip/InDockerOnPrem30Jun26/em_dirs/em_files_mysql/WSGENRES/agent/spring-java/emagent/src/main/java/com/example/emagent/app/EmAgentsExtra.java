package com.example.emagent.app; 
 
import java.util.*; 
 
import org.slf4j.Logger; 
import org.slf4j.LoggerFactory; 
 
import org.springframework.ai.chat.client.ChatClient; 
 
import com.example.emagent.app.EmAgentEvaluatorOptimizerFixed.RefinedResponseFixed; 
import com.example.emagent.app.EmAgentEvaluatorOptimizer.RefinedResponse; 
import com.example.emagent.app.EmAgentOrchestratorWorkers.FinalResponse;

// ------------------------------------------------------------ 
// Agentic Workflows Extra
// ------------------------------------------------------------ 
 
public class EmAgentsExtra { 

	private static final Logger logger = LoggerFactory.getLogger(EmAgentsExtra.class); 

	private final ChatClient chatClient; 

	public EmAgentsExtra(ChatClient chatClient) { 
		this.chatClient = chatClient; 
	} 


	boolean runEmAgentParallel = false;
	boolean runEmAgentEvaluatorOptimizerFixed = false; 
	boolean runEmAgentEvaluatorOptimizer = false; 
	boolean runEmAgentOrchestratorWorkers = false; 
	boolean runEmAgentRouting = false; 

	public void runAgentsExtra() { 
 
		logger.info("------- Run EmAgentExtra ------------ "); 
 
			if (runEmAgentParallel) {
				logger.info("------- Run EmAgentParallel ------------ ");  
				new EmAgentParallel(chatClient).agenticParallel();  
			} 
 
			if (runEmAgentEvaluatorOptimizerFixed) {

			logger.info("------- Run EmAgentEvaluatorOptimizerFixed ------------ ");  
 
			RefinedResponseFixed refinedResponseFixed = new EmAgentEvaluatorOptimizerFixed(chatClient) 
					.loop(""" 
					<user input> 
					table_name 
					</user input> 
					"""); 
 
			System.out.println("---------------------------"); 
			System.out.println("FINAL OUTPUT:\n : " + refinedResponseFixed); 
			}
 
			if (runEmAgentEvaluatorOptimizer) {
			logger.info("------- Run EmAgentEvaluatorOptimizer ------------ ");  
 
			RefinedResponse refinedResponse = new EmAgentEvaluatorOptimizer(chatClient) 
					.loop(""" 
					<user input> 
					Implement a Stack in Java with: 
					1. push(x) 
					2. pop() 
					3. getMin() 
					All operations should be O(1). 
					All inner fields should be private and when used should be prefixed with 'this.'. 
					</user input> 
					"""); 
 
					// examples 
 					//Generate personalized marketing content for customerId 1001 
					//Generate Customer service response for ticketId 503020 
 
			System.out.println("---------------------------"); 
			System.out.println("FINAL OUTPUT:\n : " + refinedResponse); 
			}
 
			if (runEmAgentOrchestratorWorkers) {
 
			logger.info("------- Run EmAgentOrchestratorWorkers ------------ ");  
 
			FinalResponse finalResponse = new EmAgentOrchestratorWorkers(chatClient) 
					.process("""
					your goal is to list top 10 AI insights and trends that can be derived,
					from studying important table schema & data available in MCP easymanage-mcp Tool 
					"""); 
					//line-1 option
					//your goal is to list top 10 AI workflows that can be implemented,
 
			System.out.println("---------------------------"); 
			System.out.println("FINAL OUTPUT:\n : " + finalResponse); 
			}
 
			if (runEmAgentRouting) {
			logger.info("------- Run EmAgentRouting ------------ ");  
 
			Map<String, String> supportRoutes = Map.of(
					"billing",
					"""
							You are a billing support specialist. Follow these guidelines:
							1. Always start with "Billing Support Response:"
							2. First acknowledge the specific billing issue
							3. Explain any charges or discrepancies clearly
							4. List concrete next steps with timeline
							5. End with payment options if relevant

							Keep responses professional but friendly.

							Input: """,

					"technical",
					"""
							You are a technical support engineer. Follow these guidelines:
							1. Always start with "Technical Support Response:"
							2. List exact steps to resolve the issue
							3. Include system requirements if relevant
							4. Provide workarounds for common problems
							5. End with escalation path if needed

							Use clear, numbered steps and technical details.

							Input: """,

					"account",
					"""
							You are an account security specialist. Follow these guidelines:
							1. Always start with "Account Support Response:"
							2. Prioritize account security and verification
							3. Provide clear steps for account recovery/changes
							4. Include security tips and warnings
							5. Set clear expectations for resolution time

							Maintain a serious, security-focused tone.

							Input: """,

					"product",
					"""
							You are a product specialist. Follow these guidelines:
							1. Always start with "Product Support Response:"
							2. Focus on feature education and best practices
							3. Include specific examples of usage
							4. Link to relevant documentation sections
							5. Suggest related features that might help

							Be educational and encouraging in tone.

							Input: """);


			/*
			// e.g. to get ticket list from database table customer_tickets
			List<CustomerTickets> list01CustomerTickets = new ArrayList<CustomerTickets>(); 
			CustomerTicketsEmAgentUtil util01CustomerTickets = new CustomerTicketsEmAgentUtil(chatClient); 
			list01CustomerTickets = util01CustomerTickets.get_table_data_customer_tickets(" get table data from customer_tickets table"); 
			//get_table_data_queried_customer_tickets(" get table data as pages from customer_tickets table queried as ' ticketDate = 'today_date' ");

			List<String> tickets = new ArrayList<String>();

			Iterator<CustomerTickets> customerTicketsIterator = CustomerTicketsList.iterator(); 
			while (customerTicketsIterator.hasNext()) { 
				CustomerTickets customerTickets = customerTicketsIterator.next(); 
				tickets.add("Subject: " + customerTickets.getSubject() + "\nMessage: "+ customerTickets.getMessage()); 
			} 
			*/
			
			// ticket list for testing
			List<String> tickets = List.of(
					"""
							Subject: Can't access my account
							Message: Hi, I've been trying to log in but keep getting an 'invalid password' error.
							- Name 1""",

					"""
							Subject: Unexpected charge on my card
							Message: I just noticed a charge of INR 900 on my credit card from your company, but I thought it should be INR 499
							- Name 2""");

			var routerWorkflow = new EmAgentRouting(chatClient);

			int i = 1;
			for (String ticket : tickets) {
				System.out.println("\nTicket " + i++);
				System.out.println("------------------------------------------------------------");
				System.out.println(ticket);
				System.out.println("------------------------------------------------------------");
				System.out.println(routerWorkflow.route(ticket, supportRoutes));
			}
 
			System.out.println("---------------------------"); 

			}			
 

	} 
} 
 

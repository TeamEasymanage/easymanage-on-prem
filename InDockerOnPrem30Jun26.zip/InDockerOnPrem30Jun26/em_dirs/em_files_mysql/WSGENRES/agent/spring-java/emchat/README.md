# AI Agents - Spring Java

## AI Agent `emchat`

* Chat Agent with access to MCP Tools

## Implementation

* Chat Agent Accessing MCP Tools

A simple command-line chat application with access to EasyManage MCP Server Tools available, to chat with AI models.

This implementation has
- Spring AI's ChatClient capabilities
- Access MCP Tools

## Prerequisites

Make available EasyManage MCP Server:
   - MCP Server For REST (Streamable HTTP)

## Getting Started

1. Build the project:
   ```bash
   ./mvnw clean install
   ```

2. Run the application:
   ```bash
   ./mvnw spring-boot:run
   ```

## Example Interaction

Once started, you'll see the Spring Boot banner and then:

```text
Chat With AI Model:
USER: easymanage-mcp get table data products 
MODEL: 
```

```
## Table Data

The data you gave has these fields, but actually includes a **primarySupplier** which is not in the schema (this might be metadata or from a related table), and lacks values for Price, StockQuantity, CreatedAt, UpdatedAt.

Sample data:

 ProductID | ProductName       | Category        | PrimarySupplier |
-----------|-------------------|-----------------|-----------------|
 101       | Smartphone Model X| Electronics     | Supplier A      |
 102       | Vacuum Cleaner Pro| Home Appliances | Supplier B      |
 103       | Learning JSON     | Books           | Supplier C      |
```

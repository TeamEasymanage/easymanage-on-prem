package com.example.emagent.app;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Arrays;
import java.util.Scanner;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.ToolCallback;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

// ------------------------------------------------------------
// Chat, MCP
// ------------------------------------------------------------

@SpringBootApplication
public class EmAgentSpringApp {

	private static final Logger logger = LoggerFactory.getLogger(EmAgentSpringApp.class);

	public static void main(String[] args) {
		SpringApplication.run(EmAgentSpringApp.class, args);
	}

	@Bean
	public CommandLineRunner commandLineRunner(ChatClient.Builder chatClientBuilder, ConfigurableApplicationContext context, ToolCallbackProvider tools) {
		return args -> {

			logger.info("------- List MCP Tools Available ------------ ");

			ToolCallback[] toolCallbacks = tools.getToolCallbacks();

			logger.info("------- Total MCP Tools Available: {} ------------ ",toolCallbacks.length); 

			for (ToolCallback callback : toolCallbacks) {
				System.out.println("Tool Name: " + callback.getToolDefinition().name());
				//System.out.println("Tool Description: " + callback.getToolDefinition().description());
				//To inspect the input schema:
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema());
			}

			logger.info("------- Filter|Use MCP Tools ------------ "); 

			List<ToolCallback> selectedToolCallbacks = Arrays.asList(toolCallbacks);

			List<ToolCallback> filteredToolCallbacks = selectedToolCallbacks.stream()
				.filter(tool -> 
					!tool.getToolDefinition().name().contains("update_") &&
					!tool.getToolDefinition().name().contains("create_") &&
					!tool.getToolDefinition().name().contains("delete_") 
					) // Filter out specific tools by name
				.collect(Collectors.toList());
				selectedToolCallbacks = filteredToolCallbacks;
			//chatClient.call(new Prompt(userMessage, new ChatOptionsBuilder().withTools(selectedToolCallbacks).build()));

			logger.info("------- Selected MCP Tools ------------ "); 

			logger.info("------- Total Selected MCP Tools: {} ------------ ",selectedToolCallbacks.size()); 

			for (ToolCallback callback : selectedToolCallbacks) { 
				System.out.println("Tool Name: " + callback.getToolDefinition().name()); 
				//System.out.println("Tool Description: " + callback.getToolDefinition().description()); 
				//To inspect the input schema: 
				//System.out.println("Tool Input Schema: " + callback.getToolDefinition().inputSchema()); 
			} 


		logger.info("------- Build ChatClient  ------------ ");

			String systemPrompt =
			""" 
			You are a senior data analyst specializing in data insights.
			"""
			;
			/*
			// For feature engineering
			"""
			You are a data scientist agent. Based on the table schema and data inputs,
			identify the most relevant features for predicting customer churn.
			Explain your process and feature importance before outputting the final feature list.
			""";
				*/

			ChatClient chatClient = chatClientBuilder
					.defaultSystem(systemPrompt)
					.defaultToolCallbacks(selectedToolCallbacks)
					//.defaultToolCallbacks(tools)
					.defaultAdvisors(MessageChatMemoryAdvisor.builder(MessageWindowChatMemory.builder().build()).build())
					.build();

		logger.info("------- Run EmAgent ------------ ");

			Scanner scanner = new Scanner(System.in);
            System.out.println("\nChat With AI Model:");
			System.out.println("\nStarting interactive chat session. Type 'exit' to quit.");

			try {
				while (true) {
					System.out.print("\nUSER: ");
					String input = scanner.nextLine();

					if (input.equalsIgnoreCase("exit")) {
						System.out.println("Ending chat session.");
						break;
					}

					System.out.print("MODEL: \n");
					System.out.println(chatClient.prompt().user(input).call().content());
				}
			} finally {
				scanner.close();
				context.close();
			}

		};
	}

}


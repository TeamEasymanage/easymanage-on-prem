# EasyManage

## Backend : Express Server - GraphQL (Apollo Server) | REST

EasyManage Backend for GraphQL | REST APIs in Express. 

* Implemented in Express.js (Node.js) TypeScript
	- typeorm, mysql
	- GraphQL (Apollo Server, graphql, express)
	- REST (express)

* Databases
	- Database: default "mysql".  (mysql is included in package.json and installed)
	- Databases supported for runtime are : "mysql", "postgres", "mariadb", "oracle", "mssql"
	- Note: Please install the database npm package for the database to use, if not using mysql.

* Extending
	- Low-code Customize to extend APIs, use multiple data sources, create data mesh.

### Installation

* Locate your project
    - ```<PROJECTDIR>``` is referenced as project folder, locate dir ```backend\express\emapi```

* cd to <PROJECTDIR>
```
cd <PROJECTDIR>
```

* Install setup
```
npm install

or

npm install --force
```

### Configure Database and Environment Variables

Configure database connection properties in:
./src/appDataSource.ts

Review or set environment variables in:
./.env

### Build and Run

To compile project and run, use command:

```
npm start
```

To only compile project
```
npm run compile
```


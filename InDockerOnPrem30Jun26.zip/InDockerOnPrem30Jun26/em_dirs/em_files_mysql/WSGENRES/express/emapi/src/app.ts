import * as dotenv from 'dotenv';
dotenv.config();

// ---------- typeorm
import "reflect-metadata"

// ---------- for REST
import { restServer } from './restServer.js';

// ---------- for Graphql
import { graphqlServer } from './graphqlServer.js';

//------------------------ Graphql or REST -------------------------------------
/*
    NOTE: Use only one of them in one project. i.e. set one to true, other to false.
    If need both, copy project, and run each type from separate projects.
*/

//------------------------ Graphql -------------------------------------
/*
    Using Apollo Server 4 
    https://www.npmjs.com/package/@apollo/server
    @apollo/server graphql
    Note: Apollo Server expressMiddleware is used and NOT startStandaloneServer
*/

var isApiGraphql = process.env.isApiGraphql

if (isApiGraphql === 'Yes') {
    // ---- Graphql ----------------------------------
//call graphql API server
graphqlServer();
} else {
    // ---- REST -------------------------------------
//call REST API server
restServer();
}

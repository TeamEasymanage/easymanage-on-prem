import basicAuth from 'express-basic-auth';
import * as dotenv from 'dotenv';
dotenv.config();
 
 
// ---------- Local functions 
function myAuthorizer(username, password, cb) {

    var apiUserName = process.env.apiUserName
    //console.log('INFO: apiUserName = '+apiUserName)
    var apiPassword = process.env.apiPassword

    const userMatches = basicAuth.safeCompare(username, apiUserName)
    const passwordMatches = basicAuth.safeCompare(password, apiPassword)

    if (userMatches && passwordMatches) {
        //console.log('Credentials match ok')
        cb(null, true)
    } else {
        //console.log('Credentials match fail')
        cb(null, false)
    }
}

function getUnauthorizedResponse(req) {
    return req.auth
        ? ('Credentials ' + req.auth.user + ':' + req.auth.password + ' rejected')
        : 'No credentials provided'
}


// ---------- Add Basic Auth 
function authBasic(app: any) { 

    var isApiSecureBasicAuth = process.env.isApiSecureBasicAuth
    if (isApiSecureBasicAuth == 'Yes') {
        console.log('INFO: Secure API - Basic Auth: Yes');
        app.use(basicAuth({ authorizer: myAuthorizer,authorizeAsync: true, unauthorizedResponse: getUnauthorizedResponse }))
    }
 
} 
 
export {authBasic} 

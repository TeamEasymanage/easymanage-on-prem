
// ---------- Lib Functions ------------------

// [1] SortBuilder 
// * Parse words from sortBy : Remove ',' 

export function sortBuiderGetWords (pSortBy: string) {

	if (pSortBy === null || pSortBy === undefined || pSortBy === "") { 
		return null;
	} else {		
		//console.log('original pSortBy: '+pSortBy);

		let sortBy = pSortBy.trimStart().trim();

		if (sortBy === "") { 
			return null;
		} else {

		//replace commas and multiple spaces by 1
		sortBy = pSortBy.replace(/,/g ,' ').replace(/\s+/g, ' ').trimStart().trim();
		//console.log('sortBy removed commas: '+sortBy);
		const words = sortBy.split(" ");
		return words;
		}
	}
	return null;
}

// [2] Query Conditions Builder 
// * Parse conditions / words from searchBy: Groups [4] 

export function predicatesBuilderGetConditions(pSearchBy: string) {

	if (pSearchBy === null || pSearchBy === undefined || pSearchBy === "") { 
		return null;
	} else {
		//console.log('original pSearchBy: '+pSearchBy);
		//replace commas and multiple spaces by 1

		let searchBy = "and "+pSearchBy.trimStart() +" ";

		//operators 
		//var regex: RegExp = /([aA][nN][dD]|[oO][rR])\s*?(\w+?)\s*?(=|equalsIgnoreCase|equals|eq|!=|ne|notEqualsIgnoreCase|notEquals|>|gt|<|lt|>=|goe|<=|loe|likeIgnoreCase|like|notLike|containsIgnoreCase|contains|isNull|isNotNull)\s*?(['?][^']*?['?]|[\"?][^']*?[\"?]|\w+?|\w+?[,\.]*\w+?)\s*? /g;

		//Implemented operators 
		var regex: RegExp = /([aA][nN][dD]|[oO][rR])\s*?(\w+?)\s*?(=|!=|>|<|>=|<=|like)\s*?(['?][^']*?['?]|[\"?][^']*?[\"?]|\w+?|\w+?[,\.]*\w+?)\s*? /g;

		var matcherWithGroups = searchBy.matchAll(regex);
		//console.log(matcher);

		var matcher = [];
		let ctr = 0;
		for (const match of matcherWithGroups) {

			var matchGrp = [ 
						match[1] , 
						match[2], 
						match[3], 
						match[4].replace(/'/g ,'') 
					]; 
			matcher[ctr++] = matchGrp;
		  }

		//console.log(matcher);
		return matcher;
	}
	return null;

}

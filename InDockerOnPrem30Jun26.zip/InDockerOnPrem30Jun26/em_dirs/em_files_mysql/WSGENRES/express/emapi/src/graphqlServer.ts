
//import * as express from "express"
import express from 'express';

// ---------- typeorm
import { myDataSource } from "./appDataSource.js"
import "reflect-metadata"

// ---------- for Graphql
import { ApolloServer } from '@apollo/server';
import { expressMiddleware } from '@apollo/server/express4';
import { ApolloServerPluginDrainHttpServer } from '@apollo/server/plugin/drainHttpServer';
import http from 'http';
import cors from 'cors';
import bodyParser from 'body-parser';

interface MyContext {
  token?: String;
}

import { authBasic } from './authBasic.js';

// ---------- Schema , resolvers
import { typeDefs } from './gql/emSchema.js';
import { resolvers } from './gql/emResolvers.js';

async function graphqlServer()  {

// establish database connection
myDataSource
    .initialize()
    .then(() => {
        console.log("Data Source has been initialized!")
    })
    .catch((err) => {
        console.error("Error during Data Source initialization:", err)
    })

// create and setup express app
const app = express()

//------------------------ Basic Auth -------------------------------------
// Enable if flag set in .env
authBasic(app);

//------------------------ Graphql -------------------------------------
/*
    Using Apollo Server 4 
    https://www.npmjs.com/package/@apollo/server
    @apollo/server graphql
    Note: Apollo Server expressMiddleware is used and NOT startStandaloneServer
*/

// Our httpServer handles incoming requests to our Express app.
// Below, we tell Apollo Server to "drain" this httpServer,
// enabling our servers to shut down gracefully.
const httpServer = http.createServer(app);

// Same ApolloServer initialization as before, plus the drain plugin
// for our httpServer.
const server = new ApolloServer<MyContext>({
  typeDefs,
  resolvers,
  plugins: [ApolloServerPluginDrainHttpServer({ httpServer })],
});
// Ensure we wait for our server to start
await server.start();

// Set up our Express middleware to handle CORS, body parsing,
// and our expressMiddleware function.
app.use(
  '/',
  cors<cors.CorsRequest>(),
  // 50mb is the limit that `startStandaloneServer` uses, but you may configure this to suit your needs
  bodyParser.json({ limit: '50mb' }),
  // expressMiddleware accepts the same arguments:
  // an Apollo Server instance and optional configuration options
  expressMiddleware(server, {
    context: async ({ req }) => ({ token: req.headers.token }),
  }),
);

// Modified server startup
await new Promise<void>((resolve) => httpServer.listen({ port: 4000 }, resolve));
console.log(`🚀 Apollo Express GraphQL Server ready at http://localhost:4000/`);
    
//------------------------ Graphql -------------------------------------

}

export {graphqlServer}

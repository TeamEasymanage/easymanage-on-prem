import express from 'express';  

// ---------- typeorm 
import { myDataSource } from './appDataSource.js' 
import 'reflect-metadata' 
 
// ---------- for REST 
import { Request, Response, NextFunction } from 'express' 

import { restPaths } from './restPaths.js';
import { authBasic } from './authBasic.js';
 
function restServer()  { 
 
// establish database connection 
myDataSource 
    .initialize() 
    .then(() => { 
        console.log('Data Source has been initialized!') 
    }) 
    .catch((err) => { 
        console.error('Error during Data Source initialization:', err) 
    }) 
 
     
// create and setup express app 
const app = express() 

//------------------------ REST ------------------------------------- 
app.use(express.json()) 

//-------------------------------------------------------------------
//Error handling
  // Error object used in error handling middleware function
  class AppError extends Error{
    statusCode: number;

    constructor(statusCode: number, message: string) {
      super(message);
  
      Object.setPrototypeOf(this, new.target.prototype);
      this.name = Error.name;
      this.statusCode = statusCode;
      Error.captureStackTrace(this);
    }
}

// Middleware function for logging the request method and request URL
 const requestLogger = (
  request: Request, 
  response: Response, 
  next:   NextFunction) => {

    console.log(`${request.method} url:: ${request.url}`);
    next()
}

app.use(requestLogger)  

// Error handling Middleware functions

// Error handling Middleware function for logging the error message
const errorLogger = (
      error: Error, 
      request: Request, 
      response: Response, 
      next: NextFunction) => {
        console.log( `error ${error.message}`) 
        next(error) // calling next middleware
  }
  
// Error handling Middleware function reads the error message 
// and sends back a response in JSON format  
const errorResponder = (
    error: AppError, 
    request: Request, 
    response: Response, 
    next: NextFunction) => {
        response.header("Content-Type", 'application/json')
          
        const status = error.statusCode || 400
        response.status(status).send(error.message)
  }

  // Attach the first Error handling Middleware
  // function defined above (which logs the error)  
  app.use(errorLogger)

  // Attach the second Error handling Middleware
  // function defined above (which sends back the response)
  app.use(errorResponder)

//Error handling
//-------------------------------------------------------------------

//------------------------ Basic Auth -------------------------------------
// Enable if flag set in .env
authBasic(app);

//------------------------ REST Paths ------------------------------------- 
restPaths(app)  
 
// start express server 
console.log('Starting server(s)...'); 
const port = 4000; 
console.log('Starting REST server'); 
 
// ----- To NOT Exit on errors, Uncomment Below 

// Logging Of Catching Unhandled Promise Rejections and uncaughtException 
process.on('uncaughtException', function (err) { 
    //console.log('Caught exception: ', err); 
    console.error(`Caught exception: ${err}\n` + `Exception origin: ${err.stack}`);
}); 
 
process.on('unhandledRejection', (reason: string, p: Promise<any>) => {
  console.error('Unhandled Rejection at:', p, 'reason:', reason);
});
 
app.listen(port, () => { 
  console.log(`Express REST Server Running On http://localhost:${port}/api`); 
}); 
 
} 
 
export {restServer} 
 
 

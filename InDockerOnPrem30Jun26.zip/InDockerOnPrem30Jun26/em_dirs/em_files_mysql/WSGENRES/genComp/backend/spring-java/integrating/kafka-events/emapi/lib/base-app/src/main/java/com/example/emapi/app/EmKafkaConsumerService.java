package com.example.emapi.app;

import org.apache.kafka.clients.admin.NewTopic;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;

import com.example.emapi.app.EmKafkaEvent;

@Configuration
@EnableKafka
public class EmKafkaConsumerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmKafkaConsumerService.class);

	@KafkaListener(
			/* or
			topics = "#{${spring.kafka.topic.name}}",
			groupId = "#{${spring.kafka.consumer.group-id}}"
			 */
			topics = "em_kafka_topic",
			groupId = "em_kafka_group"

	)
	public void consume(EmKafkaEvent event){
		LOGGER.info(String.format("EmKafkaEvent Event consumed in --- Service => %s", event.getMessage() + " " + event.getEmEntity()));

		/* 
		
		// Consume event specific to a record or data model e.g. Orders
		// e.g. for shipping service to create orders -
		
		Add imports
		import com.fasterxml.jackson.databind.ObjectMapper;
		e.g. for shipping service to create orders -
		import com.example.emapi.app.Orders.Orders;
		import com.example.emapi.app.Shipping.Shipping;
		import com.example.emapi.app.Shipping.ShippingService;
		
		*/
		
		/*

			// STEP: Capture Event
			
			// LOGGER.info(String.format("EmKafkaEvent T = %s",event.getEmEntity().getClass()));
			// LinkedHashMap 

			Orders _Orders = new Orders();
			ObjectMapper mapper = new ObjectMapper();
			_Orders = mapper.convertValue(event.getEmEntity(), Orders.class);

		*/

		/*

			// STEP: Extract Event Metadata, data

			long orderId = _Orders.getOrderId();
			long orderQuantity = _Orders.getOrderQuantity();
			long customerId = _Orders.getCustomerId();
			long tenantId = _Orders.getTenantId();
			long productId = _Orders.getProductId();

			// Create shipping record for the given order
			// using shipping table gen code, e.g.
			// shippingService.ShippingCreate()

			Calendar currTime = Calendar.getInstance();
			currTime.setTime(new java.util.Date());

			Shipping shippingRec = new Shipping();
			shippingRec.setShippingId(orderId);
			shippingRec.setOrderId(orderId);
			shippingRec.setCustomerId(customerId);
			shippingRec.setTenantId(tenantId);
			shippingRec.setProductId(productId);
			shippingRec.setShippingQuantity(orderQuantity);
			shippingRec.setShippingDate(currTime);
			shippingRec.setCreated(currTime);

		*/

		/*

			// STEP: Process Event Options

			// OPTION : Event-Driven AI Workflows:  From Event Trigger, invoke AI Workflow 

// Option: Re-search via AI chat
easymanage what tool is available to create shipping record

want to see an example of how to use this tool

run the tool with values as below 
{
  "shippingId": "4001",
  "orderId": "4001",
  "customerId": "501",
  "productId": "1501",
  ...
  "created": "2023-03-19 15:53"
  ...
}

// Option: Invoke AI Workflow 
// Call AI Workflow: via WebClient
// example given as curl

curl -X 'POST' \
  'http://localhost:9030/agentserver/agent/run-full' \
  -H 'accept: * / *' \
  -H 'Content-Type: application/json' \
  -d '{
  "agentProj": {
    "projId": "101",
    "appName": "OrderEvent",
    "agentName": "ConsumeOrderEvent",
    "toolLimit": 0,
    "toolNameIncl": "event",
    "toolNameExcl": "",
    "sysPrompt": "",
    "userName": "JohnDoe",
    "projModel": ""
  },
  "agentTasks": [
    {
      "taskId": "5001",
      "taskOrd": 1,
      "taskName": "CreateShipping",
      "promptType": "Input",
      "inputPrompt": "run the tool for creating shipping record with values <shippingRec json> ",
      "inputContext": "",
      "prevContextYN": "No",
      "prevContextSel": "",
      "contextSvPrompt": "",
      "taskModel": ""
    }
  ]
}'

		*/

		/*

			// STEP: Process Event in Backend

			// Create shipping entry

			Shipping _Shipping =
					shippingService.ShippingCreate(shippingRec);

			LOGGER.info(String.format("EmKafkaEvent Event consume : Shipping created for orderId => %s", orderId));
			LOGGER.info(String.format("EmKafkaEvent Event consume : Shipping Saved => %s", _Shipping.toString()));

		LOGGER.info(String.format("EmKafkaEvent Event consume processed --- Service => %s", event.getMessage() + " " + event.getEmEntity()));
		
		*/
		
		// handle actions post consuming here ...
	}

} 
 

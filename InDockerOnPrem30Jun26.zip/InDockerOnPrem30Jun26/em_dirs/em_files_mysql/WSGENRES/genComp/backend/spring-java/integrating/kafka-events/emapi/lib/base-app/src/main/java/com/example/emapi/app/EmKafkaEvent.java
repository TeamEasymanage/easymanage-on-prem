package com.example.emapi.app;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
@NoArgsConstructor
public class EmKafkaEvent<T>  implements Serializable {
    private String message;
    private String status;
    private T emEntity;

    public EmKafkaEvent(
            String message,
            String status,
            T emEntity
    ) {
        this.message = message;
        this.status = status;
        this.emEntity = emEntity;
    }

}

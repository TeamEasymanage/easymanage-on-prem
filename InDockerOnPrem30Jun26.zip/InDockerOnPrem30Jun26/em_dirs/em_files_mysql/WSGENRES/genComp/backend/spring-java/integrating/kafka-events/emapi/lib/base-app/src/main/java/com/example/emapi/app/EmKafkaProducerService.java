package com.example.emapi.app;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.apache.kafka.clients.admin.NewTopic;
import com.example.emapi.app.EmKafkaEvent;
import org.springframework.stereotype.Service;

@Service
public class EmKafkaProducerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmKafkaProducerService.class);

	@Autowired
	private NewTopic topic;

	@Autowired
	private KafkaTemplate<String, EmKafkaEvent> kafkaTemplate;


	/*
	public EmKafkaProducerService(NewTopic topic, KafkaTemplate<String, EmKafkaEvent> kafkaTemplate) {
		this.topic = topic;
		this.kafkaTemplate = kafkaTemplate;
	}
	 */

	public void producerSendMessage(EmKafkaEvent event){
		LOGGER.info(String.format("Producer: EmKafkaEvent Event => %s ", event.getMessage() + " " + event.getEmEntity()));

		Message<EmKafkaEvent> messageEmKafkaEvent = MessageBuilder
				.withPayload(event)
				.setHeader(KafkaHeaders.TOPIC, topic.name())
				.build();
		kafkaTemplate.send(messageEmKafkaEvent);
	}

} 
 

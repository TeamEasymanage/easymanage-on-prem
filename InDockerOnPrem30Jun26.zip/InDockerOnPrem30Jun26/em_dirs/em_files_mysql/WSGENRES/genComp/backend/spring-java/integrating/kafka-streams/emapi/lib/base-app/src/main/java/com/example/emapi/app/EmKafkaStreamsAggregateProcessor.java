package com.example.emapi.app;

import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.kstream.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.Serde;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

@Component
public class EmKafkaStreamsAggregateProcessor {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmKafkaStreamsAggregateProcessor.class);

    @Autowired
    void createPipeline(StreamsBuilder kafkaStreamsBuilder) {
        KStream<String, String> inputMsgStream = kafkaStreamsBuilder
                .stream("em_kafka_topic", Consumed.with(Serdes.String(), Serdes.String()));

        //e.g. word count
        KTable<String, Long> countWords = inputMsgStream
                .mapValues((ValueMapper<String, String>) String::toLowerCase)
                .flatMapValues(stringValue -> Arrays.asList(stringValue.split("\\W+")))
                .groupBy((key, value) -> value, Grouped.with(Serdes.String(), Serdes.String()))
                .count(Materialized.as("word_counts"));
                //.count();


		LOGGER.info(String.format("Word Count => %s", countWords.toString()));

                /*
                //Or
                .flatMapValues(value -> Arrays.asList(value.toLowerCase().split("\\W+")))
                .groupBy((key, value) -> value)
                .count(Materialized.as("word_counts"));
                 */

    }
}

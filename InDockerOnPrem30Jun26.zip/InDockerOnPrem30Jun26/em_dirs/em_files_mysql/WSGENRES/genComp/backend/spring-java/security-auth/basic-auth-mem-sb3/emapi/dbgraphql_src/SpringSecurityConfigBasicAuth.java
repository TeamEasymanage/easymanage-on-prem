
/* ---------------------------------------------
	To enable Spring Security - Http Basic Auth
   ---------------------------------------------
*/


package com.example.emapi.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.DefaultSecurityFilterChain;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityConfigBasicAuth {

	@Bean
	DefaultSecurityFilterChain springWebFilterChain(HttpSecurity http) throws Exception {
		return http
				.cors(withDefaults -> {})
				.csrf(csrf -> csrf.disable())
				.authorizeHttpRequests()
				.anyRequest().authenticated()
				.and()
				.httpBasic(withDefaults())
				.build();

	}

	@Bean
	public static InMemoryUserDetailsManager userDetailsService() {

		User.UserBuilder userBuilder = User.builder();
		UserDetails emUser = userBuilder.username("emUser").password(passwordEncoder().encode("emUser123")).roles("USER").build();
		UserDetails emAdmin = userBuilder.username("emAdmin").password(passwordEncoder().encode("emAdmin123")).roles("USER", "ADMIN").build();
		return new InMemoryUserDetailsManager(emUser, emAdmin);
	}


	@Bean
	public static PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}


}


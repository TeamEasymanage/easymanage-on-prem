package com.example.emapi.app;
 
import java.util.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;
 
// Uncomment For Communicate Consumer-Service and Data Mesh API 
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.HttpHeaders; 
import org.springframework.http.MediaType; 
import reactor.core.publisher.Mono; 
import org.springframework.core.ParameterizedTypeReference; 

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

// ------------- response Token ----------------
@Getter
@Setter
@NoArgsConstructor
class jwtToken implements Serializable {
	String access_token;
	int expires_in;
	int refresh_expires_in;
	String refresh_token;
	String token_type;
	int not_before_policy;
	String session_state;
	String scope;
}

// ------------- RequestBody POST  ----------------
@Getter
@Setter
@NoArgsConstructor
class RequestUser implements Serializable {
	String username;
	String password;
}

// ------------- controller ----------------
@CrossOrigin
@RestController 
@RequestMapping("/emlogin")
public class EmLoginBffDataRestController {

	@Value("${spring.security.oauth2.client.provider.keycloak.issuer-uri}")
	private String issuer_uri;

	@Value("${spring.security.oauth2.client.registration.keycloak.client-id}")
	private String client_id;

	@Value("${spring.security.oauth2.client.registration.keycloak.client-secret}")
	private String client_secret;

// -------------------- getToken -------------------------

//----------------------------------------------------------------------------
// Get Access Tokens With Keycloak API
//----------------------------------------------------------------------------

@PostMapping("oauth2/getToken")
public ResponseEntity<jwtToken> oauth2ClientGetToken(@RequestBody RequestUser reqUser)
		throws Exception
{

	// curl -d "client_id=login-app&client_secret=CpHGX36kE&username=emUser&password=emUser123&grant_type=password"
	// http://127.0.0.1:8180/realms/emapi/protocol/openid-connect/token

	MultiValueMap<String, String> tokRequest = new LinkedMultiValueMap<>();
	tokRequest.add("client_id", client_id);
	tokRequest.add("client_secret", client_secret);
	tokRequest.add("username", reqUser.getUsername());
	tokRequest.add("password", reqUser.getPassword());
	tokRequest.add("grant_type", "password");

	//String get_data_rest_url = "http://127.0.0.1:8180/realms/emapi/protocol/openid-connect/token";
	String get_data_rest_url = issuer_uri + "/protocol/openid-connect/token";
	WebClient webClientRest = WebClient.builder().baseUrl(get_data_rest_url)
			.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

	Mono<jwtToken> responseRest =
			webClientRest.post()
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(BodyInserters.fromFormData(tokRequest))
					.retrieve()
					.bodyToMono(jwtToken.class)
					;

	jwtToken gotToken = responseRest.block();

	//System.out.println("Token: "+gotToken.toString());
	//----------------------------------------------------------------------------

	if (Objects.isNull(gotToken)) {
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	return new ResponseEntity<>(gotToken, HttpStatus.OK);
}

//----------------------------------------------------------------------------
// Refresh Access Tokens With Keycloak API
//----------------------------------------------------------------------------
@PostMapping("oauth2/refreshToken")
public ResponseEntity<jwtToken> oauth2ClientRefreshToken(@RequestBody String refToken)
		throws Exception
{
	// RequestBody is one field, From Swagger just send refToken string, without double quotes wrapping
	//System.out.println("Ref Token: "+refToken);

	MultiValueMap<String, String> tokRequest = new LinkedMultiValueMap<>();
	tokRequest.add("client_id", client_id);
	tokRequest.add("client_secret", client_secret);
	tokRequest.add("refresh_token", refToken);
	tokRequest.add("grant_type", "refresh_token");

	String get_data_rest_url = issuer_uri + "/protocol/openid-connect/token";
	WebClient webClientRest = WebClient.builder().baseUrl(get_data_rest_url)
			.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

	Mono<jwtToken> responseRest =
			webClientRest.post()
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(BodyInserters.fromFormData(tokRequest))
					.retrieve()
					.bodyToMono(jwtToken.class)
					;

	jwtToken gotToken = responseRest.block();

	//System.out.println("Token: "+gotToken.toString());
	//----------------------------------------------------------------------------

	if (Objects.isNull(gotToken)) {
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

	return new ResponseEntity<>(gotToken, HttpStatus.OK);
}

} 
 

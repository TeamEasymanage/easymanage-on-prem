
# README - Agent MCP Pack

## What Are Agent MCP Packs

Generate and Build Docker Containers for Agent MCP Packs mapped to your data sources. They include below.

* AI Agents
* MCP Server
* APIs REST

## Agent MCP Pack

* Agent MCP Pack Docker Containers

Agent MCP Pack records in EasyManage Builder app are created to re-present Agent MCP Pack docker containers. They help in knowing your containers and Testing.

* Agent MCP Pack records in EasyManage Builder ← Agent MCP Pack docker containers 

#### Primary Agent MCP Pack

If you have multiple MCP Servers mapped to various data sources, Make first Container's Agent MCP Pack as Primary. Add all your MCP Servers to its AgentServer configuration to get AI-Ready data from across all your data sources.

Use Primary Agent MCP Pack's Agent Server in EasyManage Builder : AI Agents : Agent Server Configuration.

### Steps to Create Agent MCP Pack record

* After Sign-In: e.g.
- [http://127.0.0.1:8080/em](http://127.0.0.1:8080/em)

* Go To
    - Platform Views : AI Agents
* Select Menu Link
    - Agent MCP : Agent MCP Packs

* Create New MCP Pack Record.
* Use the record values to replace in docker `.env` file later on.

* `.env` Compose Profile

```
# Comment out below to disable agent server in this container
COMPOSE_PROFILES=agentserver-enabled
```

## Docker Container Setup

After Generate Code : List Builds | Download 

* Extract zip, e.g.
    - `Downloads\EmGenDir_MYTEMP01_WS_51246\WS_51246`
* Copy `WS_51246` to your preferred location, e.g.
    - `EmDockerAgentPacks\WS_51246`
* `cd EmDockerAgentPacks\WS_51246`

Please view environment variables and update your values in file:
- `.env` 

### Environment Variables

#### If Using Redis, Kafka

* If Backend configurations for Redis, Kafka are selected,
      - Select appropriate matching profile

* `.env` Compose Profile

```
# Uncomment below to enable all 
COMPOSE_PROFILES=agentserver-enabled,redis-enabled,kafka-enabled
```

* NOTE: 
    - When configured and Redis, Kafka containers are not started, the backend APIs will error/exit.
    - Agent Server also uses Redis

#### Container-1

* `EmDockerAgentPacks\WS_51246\.env`
```
COMPOSE_PROJECT_NAME=ws_51246

# Service ports
EMAPI_PORT=9080
EMMCP_PORT=9040
EMAGENT_PORT=9030

...
```

#### Container-2

* `EmDockerAgentPacks\WS_51247\.env`
```
COMPOSE_PROJECT_NAME=ws_51247

# Service ports
EMAPI_PORT=9081
EMMCP_PORT=9041
EMAGENT_PORT=9031

...
```

* Tip: Ports needs to be unique across all containers on a given host machine.

### Environment Variables For Data Source

Recommended to utilize below `.env` vars for API Data Source

```
# API Data Source
EMAPI_DB_NAME=mysqldb
EMAPI_DB_URL=jdbc:mysql://dbhost:3306/${DB_NAME}?useUnicode=true&characterEncoding=utf8
EMAPI_DB_USER=
EMAPI_DB_PASS=
```

Define all values, Specify correct `EMAPI_DB_URL` for your database type. Sample url examples are given in `application.properties` mentioned below.


Once defined replace them in API `application.properties`:
* Edit file, e.g.
- `WS_51246\backend\spring-java\emapi\app\dbrest\src\main\resources\application.properties`

Locate `spring.datasource` block and Replace as below. 

```
# -- Datasource Prop Added --
spring.datasource.url=${EMAPI_DB_URL}
spring.datasource.username=${EMAPI_DB_USER}
spring.datasource.password=${EMAPI_DB_PASS}
```

## Container Setup Details

Details given for `EmDockerAgentPacks\WS_51246`, You can repeat these steps for next containers.

* `cd EmDockerAgentPacks\WS_51246`

### Build and Run

Build and Run: 

`docker-build-run.bat`

OR

`docker compose up -d`

### Container Lifecycle

#### Start | Stop containers

Start existing containers
`docker compose start`

Stops running containers
`docker compose stop`

#### Monitor | Troubleshooting

* Container Logs

e.g.
```
docker logs ws_51246-agentserver-1
```

* Verify internal Network Connectivity to emmcp (service as host)
```
docker exec -it ws_51246-emapi-1 ping emmcp
```

```
docker compose ps
docker compose logs
docker compose logs -f

docker compose images
docker compose config
```

### Container Removal

Caution: Your Data will be lost!

* Remove Container
`docker compose down`
- Also remove the volumes associated
`docker compose down -v`


### Steps For Making Primary Agent MCP Pack

Lets make Container-1 as Primary. 

* `cd EmDockerAgentPacks\WS_51246`

Add all your MCP Servers to its AgentServer configuration:
* Edit file:
- `WS_51246\agent\spring-java\agentserver\src\main\resources\application.properties`

* Locate properties section below

```
# Streamable HTTP transport Mode
spring.ai.mcp.client.streamable-http.connections.server1.url=http://${EMMCP_HOST:localhost}:${EMMCP_PORT:9040}
spring.ai.mcp.client.streamable-http.connections.server1.endpoint=/mcp
#spring.ai.mcp.client.streamable-http.connections.server2.url=http://otherserver:8081
#spring.ai.mcp.client.streamable-http.connections.server2.endpoint=/custom-sse
```

* Uncomment and use `server2` properties to map to your Container-2 MCP Server. You will use machine host as the MCP server is in another docker container.
e.g.

```
spring.ai.mcp.client.streamable-http.connections.server2.url=http://host.docker.internal:9041
spring.ai.mcp.client.streamable-http.connections.server2.endpoint=/mcp
```

Note: For added MCP Server, Use host as `host.docker.internal`, this is to access machine host from inside docker container service. If you use `localhost` or `127.0.0.1`, it will not work as added MCP Server is not in same docker container.


* If you have more MCP Servers, copy these properties for `server3`, `server4` ... and use them.
* All the MCP Servers added, must be running.

* Re-build and Re-start Container-1 AgentServer
    - docker compose down -v
    - From Docker Desktop, Delete docker image ws_51246-agentserver
    - docker compose up -d

* Verify Tools are available via Swagger:

```
http://localhost:9030/swagger-ui/index.html
```
GET
/agentserver/agent/list-mcp-server-wise-tools

Sample output
```
MCP Server 1 : 
  Server Name : mcprest_9041
  Client Name : server2

  ----- Total MCP Tools Available: {} ------------ [10]

Tool Name: get_table_data_inventory
Tool Name: get_all_table_schema
...

===================================================================

MCP Server 2 : 
  Server Name : mcprest_9040
  Client Name : server1

  ----- Total MCP Tools Available: {} ------------ [10]

Tool Name: get_table_data_product
Tool Name: get_all_table_schema
...

```

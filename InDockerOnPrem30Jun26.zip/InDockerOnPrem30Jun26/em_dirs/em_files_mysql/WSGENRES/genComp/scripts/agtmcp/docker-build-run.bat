
rem ----@echo off

rem ----------------------------
SET bat_dir=%~dp0%
SET base_dir=%bat_dir%

echo "----------------------------"
echo The script directory is : %base_dir%

echo "----------------------------"
echo "Docker Build and Run"

echo "Run: docker compose up -d "

docker compose up -d

echo "Done"

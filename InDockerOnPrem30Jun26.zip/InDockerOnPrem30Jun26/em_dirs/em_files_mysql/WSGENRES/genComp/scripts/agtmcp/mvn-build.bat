
rem ----@echo off

rem ----------------------------
SET bat_dir=%~dp0%
SET base_dir=.

SET api_type=rest

echo "----------------------------"
echo The script directory is : %base_dir%


echo "----------------------------"
echo "Stage: Backend"
echo "Build backend REST APIs"

CD %base_dir%\backend\spring-java\emapi
dir 

echo "Run: mvn clean package -B "

call mvn clean package -B 

cd %bat_dir%

echo "----------------------------"
echo "Stage: MCP"
echo "Build mcp REST"

CD %base_dir%\mcp\spring-java\emmcp
dir 

echo "Run: mvn clean install -B "

call mvn clean install -B 

cd %bat_dir%

echo "----------------------------"
echo "Stage: Agent Server"
echo "Build agentserver"

CD %base_dir%\agent\spring-java\agentserver
dir 

echo "Run: mvn clean package -B "

call mvn clean package -B 

cd %bat_dir%

echo "Done"

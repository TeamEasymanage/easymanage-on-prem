# EasyManage MCP Server

## MCP Server

This Readme describes common features and how to setup multiple MCP Servers to leverage getting insights from multiple enterprise data sources.

### Server Transport

#### Streamable HTTP

* The MCP Server supports transport mode (Default)
  - Streamable HTTP

Note: Streamable HTTP Replaces SSE

#### STDIO

* The MCP Server can be customized to support transport mode
  - STDIO Mode 
* Please follow Readme for MCP REST:
  - `README-mcprest-stdio.md`
* Similar changes can enable STDIO for MCP GraphQL.

NOTE: Supported using either STDIO or Streamable HTTP, NOT both together on same machine.

### MCP Server For REST

To Configure and use individual MCP Server For REST refer to:
  - `README-mcprest.md`

### MCP Server For GraphQL

To Configure and use individual MCP Server For GraphQL refer to:
  - `README-mcpgraphql.md`

## Data Mesh Knowledge Framework

A data mesh is a framework for organizing and distributing data in a decentralized approach. Data products or databases are owned and managed by domain-oriented teams.

EasyManage MCP Servers solution connects to all of your data sources.

Data Mesh Knowledge Framework term is referring to concept of giving AI Models access to multiple enterprise databases and feeding their schema. So that you can derive insights holistically from combined enterprise data.


## How to setup multiple MCP Servers

### Cursor

Setup individual MCP Server For REST and GraphQL.

> * Name the MCP Server in a way which can identify database.
>  - e.g. database-crm, database-orders, em-db-shipping

Add all the servers to Global MCP Servers list:
  - Add to file:
  - `C:\Users\<username>\.cursor\mcp.json`

Multiple MCP Servers sample json configuration file:
```
{
  "mcpServers": {
    "database-crm": {
      "command": "C:/ProgFiles/Java/jdk-17/bin/java.exe",
      "args": 
      ["-jar", 
	     "path_to_proj_crm/emmcp/app/mcprest/target/mcprest-1.0-SNAPSHOT.jar"
      ],
      "env": {
       "em.mcp.apiUrl": "http://127.0.0.1:9080/emdbrest",
       "em.mcp.authType": "None",
       "em.mcp.authToken": ""
      }
    }
  },
    "database-orders": {
      "command": "C:/ProgFiles/Java/jdk-17/bin/java.exe",
      "args": 
      ["-jar", 
	     "path_to_proj_orders/emmcp/app/mcprest/target/mcprest-1.0-SNAPSHOT.jar"
      ],
      "env": {
       "em.mcp.apiUrl": "http://127.0.0.1:9090/emdbrest",
       "em.mcp.authType": "None",
       "em.mcp.authToken": ""
      }
    }
  }
}
```

## How to Setup Data Mesh Knowledge Framework

* Use chat inputs to feed schema to AI Models and use that as context

```
database-orders get all table schema

describe and analyze database-orders features from schema

database-crm get all table schema

describe and analyze database-crm features from schema
```

## Get Insights from Multiple Databases

```
database-orders get table data from tenant table

database-crm get table data from pipeline

database-orders get table data from orders table then from tool database-crm get customers list who have not placed any order this month
```

# EasyManage MCP Server

## MCP Server For GraphQL

We will configure and use MCP Server For GraphQL from path:
  - `mcp/spring-java/emmcp/app/mcpgraphql/target/mcpgraphql-1.0-SNAPSHOT.jar`

## How To Configure MCP Server in AI Editor

### Cursor

Define Global MCP Servers
  - Create or Add to file:
  - `C:\Users\<username>\.cursor\mcp.json`

MCP Server For GraphQL sample json configuration file:
`mcpgraphql-mcp.json`
```
{
  "mcpServers": {
    "easymanage": {
      "command": "C:/ProgFiles/Java/jdk-17/bin/java.exe",
      "args": 
      ["-jar", 
	     "path_to_proj/emmcp/app/mcpgraphql/target/mcpgraphql-1.0-SNAPSHOT.jar"
      ],
      "env": {
       "em.mcp.apiUrl": "http://127.0.0.1:9070/graphql",
       "em.mcp.authType": "None",
       "em.mcp.authToken": ""
      }
    }
  }
}
```

NOTE: 
  - For "command" : Give full path, Use Java 17+
  - `--em.mcp.apiUrl` : Specify EasyManage dbgraphql APIs Url 
  - e.g. "--em.mcp.apiUrl=http://127.0.0.1:9070/graphql"
  - `em.mcp.authType`: Specify one of "None", "Basic" , "Bearer"
    - "None" - No API Security
    - "Basic" - API Secured with Basic Auth
    - "Bearer" - API Secured with Bearer Token
      - e.g. OAuth2
  - `em.mcp.authToken`: Give Value for your Auth Type
      - Basic Auth - Give base64Encoded $username:$password
      - Bearer - Give token

### Other AI Editors

* You may use Cline, Windsurf or other AI Editor

## Server Reference

The server supports transport mode
* STDIO Mode

## Available Tools

> NOTE: Some @Tools are commented as prefixed by **//**, you can enable or disable them inside generated code via global edits easily. Please see section: `How to Enable/Disable Tools` in `README-mcprest.md`

For each table below @Tools available. Shown here for `tenant` table

```
	@Tool(description = "get table data from tenant table")
	public List<Tenant> get_table_data_tenant()

	//@Tool(description = "get table data as pages from tenant table")
	//public List<Tenant> get_table_data_paged_tenant(int page, int size)

	@Tool(description = "get table data queried and sorted as per parameter strings as pages from tenant table")
	public List<Tenant> get_table_data_queried_tenant(String searchBy, String sortBy, int page, int size)

	@Tool(description = "get table data by key column from tenant table")
	public List<Tenant> get_table_data_by_key_tenant(long tenantId)

	// For GraphQL @SubscriptionMapping type APIs
	//@Tool(description = "get table data as stream by key column from tenant table")
	//public List<Tenant> get_table_data_stream_by_key_tenant(long tenantId)

```

## Sample Chats

### General

```
easymanage get table data from tenant table

easymanage get table data from tenant table in table format

easymanage get table data from tenant table in csv format

who is the first and last tenant 
```

### Get Paged Data

```
easymanage get table data as pages from tenant table in table format for 2 pages with size 2
```

### Get Paged Data With Queried & Sorted

* To get queried and sorted as per parameter strings as pages

```
easymanage get table data as pages from tenant table queried as "tenantId > 2" sorted by "tenantName desc" with 1 page size 100
```

Below parameters will be constructed by Cursor to call @Tool `get_table_data_queried_tenant` :

```
{
  "searchBy": "tenantId > 2",
  "sortBy": "tenantName desc",
  "page": 1,
  "size": 10
}
```

### Get Data By key column 

```
easymanage get table data from tenant table for key 3
easymanage get table data from tenant table for key 3 format as table
```

### Get Data As Stream 

```
easymanage get table data as stream from tenant table for key 3 in table format
```

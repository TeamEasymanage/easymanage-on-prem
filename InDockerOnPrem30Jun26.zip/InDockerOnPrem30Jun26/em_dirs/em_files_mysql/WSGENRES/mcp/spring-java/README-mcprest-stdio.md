# EasyManage MCP Server

## MCP Server For REST

### STDIO

### Server Transport Change

#### STDIO

* The MCP Server can be customized to support transport mode
  - STDIO Mode

* Please follow the steps in this page.

### Customize Code

### Edit `application.properties`

Edit `app\mcprest\src\main\resources\application.properties`

* NOTE: Un-Comment 3 properties in STDIO section for using STDIO

e.g.
```
spring.main.banner-mode=off
logging.pattern.console=
spring.ai.mcp.server.stdio=true
```

### Build Project Run

Build Project with maven goals: package

Run MCP Server

```
java -jar app\mcprest\target\mcprest-1.0-SNAPSHOT.jar
```

## How To Configure MCP Server (STDIO) in AI Editor

### Cursor

Please see example usage in `README-mcprest.md`

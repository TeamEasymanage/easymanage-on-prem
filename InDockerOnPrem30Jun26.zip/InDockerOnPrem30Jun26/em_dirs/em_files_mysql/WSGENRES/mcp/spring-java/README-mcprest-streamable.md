# EasyManage MCP Server

## MCP Server For REST

### Streamable HTTP

**WebMVC Server Transport**

Full MCP Server features support with Streamable HTTP server transport based on Spring MVC.
* Automatically configured Streamable HTTP endpoints
* Ref to Spring AI docs:
  - [MCP Server Boot Starter](https://docs.spring.io/spring-ai/reference/api/mcp/mcp-server-boot-starter-docs.html)
  - [WebMVC Server Transport](https://docs.spring.io/spring-ai/reference/api/mcp/mcp-server-boot-starter-docs.html#_webmvc_server_transport)


### Server Transport Change

#### Streamable HTTP

* The MCP Server can be customized to support transport mode
  - Streamable HTTP Mode

* Please follow the steps in this page.

### Customize Code

### Edit `application.properties`

Edit `app\mcprest\src\main\resources\application.properties`

* NOTE: Comment out 3 properties in STDIO section for using Streamable HTTP

e.g.
```
#spring.main.banner-mode=off
#logging.pattern.console=
#spring.ai.mcp.server.stdio=true
```

NOTE: 
* The Streamable HTTP endpoint  by default is configured and available via:

```
spring.ai.mcp.client.streamable-http.connections.server1.url=http://localhost:9040
spring.ai.mcp.client.streamable-http.connections.server1.endpoint=/mcp
```

### Build Project Run

Build Project with maven goals: package

Run MCP Server

```
java -jar app\mcprest\target\mcprest-1.0-SNAPSHOT.jar
```

## How To Configure MCP Server (Streamable HTTP) in AI Editor

### Cursor

MCP Server For REST (Streamable HTTP) sample json configuration file:
`mcprest-mcp.json`
```
{
  "mcpServers": {
    "easymanage": {
	  "name": "easymanage",
	  "url": "http://localhost:9040/mcp",
      "headers": {
       "em.mcp.apiUrl": "http://127.0.0.1:9080/emdbrest",
       "em.mcp.authType": "None",
       "em.mcp.authToken": ""
      }
    }
  }
}
```

Cursor will show available tools.

The MCP Server log will show client request
```
2025-10-14T07:54:47.031+05:30  INFO 10876 --- [nio-9040-exec-5] i.m.server.McpAsyncServer                : Client initialize request - Protocol: 2025-06-18, Capabilities: ClientCapabilities[experimental=null, roots=RootCapabilities[listChanged=false], sampling=null], Info: Implementation[name=cursor-vscode, version=1.0.0]
2025-10-14T07:54:47.038+05:30  WARN 10876 --- [nio-9040-exec-5] i.m.server.McpAsyncServer                : Client requested unsupported protocol version: 2025-06-18, so the server will sugggest the 2024-11-05 version instead
```

Use Cursor chat input to call tools, e.g.
```
easymanage get table data tenant
```

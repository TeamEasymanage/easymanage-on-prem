# EasyManage MCP Server

## MCP Server For REST

### Server Transport

* Server Transport
  - Streamable HTTP
    - The MCP Server supports transport mode (Default): Streamable HTTP Mode
  - STDIO
    - The MCP Server can be customized to support transport mode: STDIO Mode 
* Please follow Readme for MCP REST with STDIO:
  - `README-mcprest-stdio.md`
* Please follow Readme for MCP REST with Streamable HTTP:
  - `README-mcprest-streamable.md`

### Server Path

We will configure and use MCP Server For REST from path:
  - `mcp/spring-java/emmcp/app/mcprest/target/mcprest-1.0-SNAPSHOT.jar`

## How To Configure MCP Server in AI Editor

### Cursor

Define Global MCP Servers
  - Create or Add to file:
  - `C:\Users\<username>\.cursor\mcp.json`

MCP Server For REST with STDIO sample json configuration file:
`mcprest-mcp.json`
```
{
  "mcpServers": {
    "easymanage": {
      "command": "C:/ProgFiles/Java/jdk-17/bin/java.exe",
      "args": 
      ["-jar", 
	     "path_to_proj/emmcp/app/mcprest/target/mcprest-1.0-SNAPSHOT.jar"
      ],
      "env": {
       "em.mcp.apiUrl": "http://127.0.0.1:9080/emdbrest",
       "em.mcp.authType": "None",
       "em.mcp.authToken": ""
      }
    }
  }
}
```

NOTE: 
  - For "command" : Give full path, Use Java 17+
  - `em.mcp.apiUrl` : Specify EasyManage dbrest APIs Url 
  - e.g. "em.mcp.apiUrl" : "http://127.0.0.1:9080/emdbrest"
  - `em.mcp.authType`: Specify one of "None", "Basic" , "Bearer"
    - "None" - No API Security
    - "Basic" - API Secured with Basic Auth
    - "Bearer" - API Secured with Bearer Token
      - e.g. OAuth2
  - `em.mcp.authToken`: Give Value for your Auth Type
      - Basic Auth - Give base64Encoded $username:$password
      - Bearer - Give token


### Other AI Editors

* You may use Cline, Windsurf or other AI Editor

## Server Reference

The server supports transport mode (default)
* STDIO Mode

## Available Tools

> NOTE: Some @Tools are commented as prefixed by **//**, you can enable or disable them inside generated code via global edits easily. Please see section: `How to Enable/Disable Tools` in `README-mcprest.md`

For each table below @Tools available. Shown here for `tenant` table

```
	@Tool(description = "get all api docs")
	public String get_all_api_docs()

	@Tool(description = "get all table schema")
	public String get_all_table_schema()

	@Tool(description = "get table data from tenant table")
	public List<Tenant> get_table_data_tenant()

	//@Tool(description = "get table data as pages from tenant table")
	//public List<Tenant> get_table_data_paged_tenant(int page, int size)

	@Tool(description = "get table data queried and sorted as per parameter strings as pages from tenant table")
	public List<Tenant> get_table_data_queried_tenant(String searchBy, String sortBy, int page, int size)

	@Tool(description = "get table data by key column from tenant table")
	public List<Tenant> get_table_data_by_key_tenant(long tenantId)

	//@Tool(description = "get table data as stream from tenant table")
	//public Flux<List<Tenant>> get_table_data_stream_tenant()

  //transactions tools

	@Tool(description = "create table data record in tenant table") 
	public long create_table_data_record_tenant(Tenant TenantTblRec1) 

	//@Tool(description = "update table data record in tenant table") 
	//public long update_table_data_record_tenant(long tenantId, Tenant TenantTblRec1) 

	//@Tool(description = "delete table data record in tenant table") 
	//public long delete_table_data_record_tenant(long tenantId) 
```

### Available Tools For Data Modeling

Note: For Tools on data modeling, naming and default disable mode differs, see examples below. Naming is shortened as max name length permitted is 60 chars.

For each data model (table join relations) below @Tools available. Shown here for `ErpProductErpInventory1Multi` table join relation

```
	//@Tool(description = "get table join data from ErpProductErpInventory1Multi tables") 
	//public List<ErpProductErpInventory> get_all_ErpProductErpInventory1Multi() 

	//@Tool(description = "get table join data as pages from ErpProductErpInventory1Multi tables") 
	//public List<ErpProductErpInventory> get_paged_ErpProductErpInventory1Multi(int page, int size) 

	@Tool(description = "get table join data queried and sorted as per parameter strings as pages from ErpProductErpInventory1Multi tables") 
	public List<ErpProductErpInventory> get_queried_ErpProductErpInventory1Multi(String searchBy, String sortBy, int page, int size) 

	@Tool(description = "get table join data by key column from ErpProductErpInventory1Multi tables") 
	public List<ErpProductErpInventory> get_via_key_ErpProductErpInventory1Multi(long productId) 

```


## Sample Chats

### General

```
easymanage get table data from tenant table

easymanage get table data from tenant table in table format

easymanage get table data from tenant table in csv format

who is the first and last tenant 
```

### Get Paged Data

```
easymanage get table data as pages from tenant table in table format for 2 pages with size 2
```

### Get Paged Data With Queried & Sorted

* To get queried and sorted as per parameter strings as pages

```
easymanage get table data as pages from tenant table queried as "tenantId > 2" sorted by "tenantName desc" with 1 page size 100
```

Below parameters will be constructed by Cursor to call @Tool `get_table_data_queried_tenant` :

```
{
  "searchBy": "tenantId > 2",
  "sortBy": "tenantName desc",
  "page": 1,
  "size": 10
}
```

### Get Data By key column 

```
easymanage get table data from tenant table for key 3
```

### Get Data As Stream 

```
easymanage get table data as stream from tenant table in table format
```

Sample Input for next prompt:
```
I want to see a sample of the actual data from the "tenant" table in a table format?
```

### Get Schema Details

```
easymanage get all api docs
```

Subsequent chat inputs after above for table e.g. ErpProduct :

```
get details for entity ErpProduct 

get schema for ViewAll
```

Get recommendations for tables e.g. ErpProduct and ErpInventory:
```
recommend join column for ErpProduct and ErpInventory
```

* AI Model can suggest direct join or via intermediary entity

## AI Transactions - Create, Update, Delete

### Create

```
easymanage what tool is available to create tenant record

want to see an example of how to use this tool
```

```
run the tool with values as below
{
  "tenantId" : 2,
  "tenantName" : "Tenant 2",
  ...
} 
```
### Update

```
easymanage what tool is available to update tenant record

want to see an example of how to use this tool
```

```
run the tool with values as below
{
  "tenantId" : 2,
  "TenantTblRec1":
  {
  "tenantId" : 2,
  "tenantName" : "New Name Tenant 2",
  ...
  }
} 
```
### Delete

```
easymanage what tool is available to delete tenant record

want to see an example of how to use this tool
```

```
run the tool with value 3
```

### How to Enable/Disable Tools

NOTE: Some @Tools are commented as shown prefixed by **//** in above list, you can enable or disable them inside generated code via global edits easily.

* Open emmcp project in Visual Studio Code
* Please search for below labels or tags and edit, Global Replace
* Goal is to comment out or uncomment code for those Tools

Look For `-TOOL-` or `-AI-TRAN-` or `-TOOL-DM-` in generated code.

You will see:

For tables:

```
/*BEG-TOOL-ViewAll*/
/*END-TOOL-ViewAll*/
/*BEG-TOOL-ViewAllPaged* 
*END-TOOL-ViewAllPaged*/ 
/*BEG-TOOL-SelectWhere*/ 
/*END-TOOL-SelectWhere*/ 
/*BEG-TOOL-Query*/
/*END-TOOL-Query*/
/*BEG-TOOL-Stream*
*END-TOOL-Stream*/
```

For AI Transactions:

```
/*BEG-AI-TRAN-ADD*/
/*END-AI-TRAN-ADD*/
/*BEG-AI-TRAN-EDIT*
*END-AI-TRAN-EDIT*/
/*BEG-AI-TRAN-DEL* 
*END-AI-TRAN-DEL*/

```

For data models, table joins relations:

```
/*BEG-TOOL-DM-ViewAll*
*END-TOOL-DM-ViewAll*/
/*BEG-TOOL-DM-ViewAllPaged* 
*END-TOOL-DM-ViewAllPaged*/ 
/*BEG-TOOL-DM-SelectWhere*/ 
/*END-TOOL-DM-SelectWhere*/ 
/*BEG-TOOL-DM-Query*/
/*END-TOOL-DM-Query*/
```

Some examples: 

* To disable TOOL-ViewAll for tables globally, edit replace
  - `/*BEG-TOOL-ViewAll*/` by `/*BEG-TOOL-ViewAll*`
  - `/*END-TOOL-ViewAll*/` by `*END-TOOL-ViewAll*/`

* To enable AI Transaction Tool AI-TRAN-EDIT globally, edit replace
  - `/*BEG-AI-TRAN-EDIT*` by `/*BEG-AI-TRAN-EDIT*/`
  - `*END-AI-TRAN-EDIT*/` by `/*END-AI-TRAN-EDIT*/`

* To disable TOOL-DM-SelectWhere for data models globally, edit replace
  - `/*BEG-TOOL-DM-SelectWhere*/` by `/*BEG-TOOL-DM-SelectWhere*`
  - `/*END-TOOL-DM-SelectWhere*/` by `*END-TOOL-DM-SelectWhere*/`

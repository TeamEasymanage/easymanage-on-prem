package com.example.emmcp.app; 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean; 
 
import org.springframework.http.HttpHeaders;

@Configuration 
public class EmMcpConfigGraphql {

	private static String apiUrl;
	private static String authType;
	private static String authToken;

	@Autowired
	public EmMcpConfigGraphql(
				@Value("${em.mcp.apiUrl:}") String apiUrl,
				@Value("${em.mcp.authType:}") String authType,
				@Value("${em.mcp.authToken:}") String authToken
				) {

		this.apiUrl = apiUrl;
		//System.out.println("apiUrl = "+apiUrl);
		this.authType = authType;
		this.authToken = authToken;
	}

	@Bean 
	public String EmMcpApiUrl() {
		return apiUrl;
	}

	@Bean
	public HttpHeaders EmMcpApiHeaders() {
		HttpHeaders apiHeaders = new HttpHeaders();
		if (authType.equals("Bearer")) {
			apiHeaders.add("Authorization", "Bearer " + authToken);
		} else if (authType.equals("Basic")) {
			apiHeaders.add("Authorization", "Basic " + authToken);
		} else {
			apiHeaders.add("EM-AUTH-NONE", "true");
		}
		return apiHeaders;
	}

} 
 

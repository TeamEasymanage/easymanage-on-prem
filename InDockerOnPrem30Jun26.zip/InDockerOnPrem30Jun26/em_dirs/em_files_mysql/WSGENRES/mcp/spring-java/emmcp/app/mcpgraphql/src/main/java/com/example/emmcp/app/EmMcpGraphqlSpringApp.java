package com.example.emmcp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmMcpGraphqlSpringApp {

    public static void main(String[] args) {
        SpringApplication.run(EmMcpGraphqlSpringApp.class, args);
    }

}

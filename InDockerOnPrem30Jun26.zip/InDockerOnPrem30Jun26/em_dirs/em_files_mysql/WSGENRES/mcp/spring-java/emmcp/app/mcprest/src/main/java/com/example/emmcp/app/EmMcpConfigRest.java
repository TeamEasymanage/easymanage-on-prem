package com.example.emmcp.app; 
 
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.ai.tool.method.MethodToolCallbackProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean; 
 
import org.springframework.http.HttpHeaders;

@Configuration 
public class EmMcpConfigRest {

	private static String apiUrl;
	private static String authType;
	private static String authToken;

	@Autowired
	public EmMcpConfigRest(
				@Value("${em.mcp.apiUrl:}") String apiUrl,
				@Value("${em.mcp.authType:}") String authType,
				@Value("${em.mcp.authToken:}") String authToken
				) {

		this.apiUrl = apiUrl;
		//System.out.println("apiUrl = "+apiUrl);
		this.authType = authType;
		this.authToken = authToken;
	}

	@Bean 
	public String EmMcpApiUrl() {
		return apiUrl;
	}

	@Bean
	public HttpHeaders EmMcpApiHeaders() {
		HttpHeaders apiHeaders = new HttpHeaders();
		if (authType.equals("Bearer")) {
			apiHeaders.add("Authorization", "Bearer " + authToken);
		} else if (authType.equals("Basic")) {
			apiHeaders.add("Authorization", "Basic " + authToken);
		} else {
			apiHeaders.add("EM-AUTH-NONE", "true");
		}
		return apiHeaders;
	}

	@Bean
	public ToolCallbackProvider buildToolsEmMcpRest(com.example.emmcp.app.EmMcpRestService emMcpRestService) {
		return MethodToolCallbackProvider.builder().toolObjects(emMcpRestService).build();
	}

} 
 

package com.example.emmcp.app; 
 
import java.lang.*; 
import java.util.*; 
 
import org.springframework.ai.tool.annotation.Tool; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.HttpHeaders; 
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;
import org.springframework.core.ParameterizedTypeReference;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.apache.pdfbox.multipdf.Splitter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.io.RandomAccessReadBuffer;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.pdf.PagePdfDocumentReader;
import org.springframework.ai.reader.pdf.config.PdfDocumentReaderConfig;
import org.springframework.core.io.ByteArrayResource;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.ai.reader.tika.TikaDocumentReader;

@Service
public class EmMcpRestService {
 
	private static String apiUrl; 
	private HttpHeaders apiHeaders; 

    @Autowired
    private ResourceLoader resourceLoader;

	@Autowired
	public EmMcpRestService(EmMcpConfigRest emMcpConfigRest) {
 
		this.apiUrl = emMcpConfigRest.EmMcpApiUrl(); 
		//System.out.println("apiUrl = "+apiUrl); 
		apiHeaders = emMcpConfigRest.EmMcpApiHeaders(); 
		/* 
		System.out.println("All Headers: "); 
		apiHeaders.forEach((key, value) -> { 
			System.out.println(key + ": " + value); 
		}); 
		*/ 
 
	} 

	// ---- MCP Tools : Service : Call Producer-Service --------------------------
	// Get data from Rest API calls via WebClient
	// Get OpenAPI definition : API Docs from e.g.
	// http://127.0.0.1:9080/v3/api-docs 
	// Refer to emdbrest application.properties
	//----------------------------------------------------------------------------
	@Tool(description = "get all api docs")
	public String get_all_api_docs()
			throws Exception
	{
		String get_rest_base_url = apiUrl.substring(0,apiUrl.lastIndexOf("/"));
		String get_rest_path_url = "/v3/api-docs";

		return getApiStringResponse(get_rest_base_url, get_rest_path_url);

	}

	@Tool(description = "get all table schema")
	public String get_all_table_schema()
			throws Exception
	{
		String get_rest_base_url = apiUrl.substring(0,apiUrl.lastIndexOf("/"));
		String get_rest_path_url = "/v3/api-docs";

		String v3_api_docs =  getApiStringResponse(get_rest_base_url, get_rest_path_url);

			ObjectMapper objectMapper = new ObjectMapper();
			JsonNode rootNode = objectMapper.readTree(v3_api_docs);

			// Navigate to components -> schemas
			JsonNode schemasNode = rootNode.path("components").path("schemas");

			if (schemasNode.isMissingNode() || !schemasNode.isObject()) {
				System.out.println("No 'schemas' found under 'components' or it's not an object.");
				return "";
			}

			return schemasNode.toString();

			/*
			System.out.println("Component Schemas:");
			Iterator<Map.Entry<String, JsonNode>> fields = schemasNode.fields();
			while (fields.hasNext()) {
				Map.Entry<String, JsonNode> entry = fields.next();
				String schemaName = entry.getKey();
				JsonNode schemaDefinition = entry.getValue();

				System.out.println("  Schema Name: " + schemaName);
				System.out.println("  Schema Definition: " + schemaDefinition.toPrettyString());
				System.out.println();
			}
			 */

	}

	// ------------- Common Lib Function For Mono --------------
	public String getApiStringResponse(String get_rest_base_url, String get_rest_path_url)
			throws Exception
	{
		String apiResponse = "";

		WebClient webClientRest = WebClient.builder().baseUrl(get_rest_base_url)
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();


		Mono<String> responseRest =
				webClientRest.get()
						.uri(uriBuilder -> uriBuilder
								.path(get_rest_path_url)
								.build())
						.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
						.headers(headers ->  headers.addAll(apiHeaders))
						.retrieve()
						.bodyToMono(new ParameterizedTypeReference<String>() {});

		apiResponse = responseRest.block();

		//System.out.println("Fetched From Producer-Service: "+apiResponse);
		//----------------------------------------------------------------------------

		return apiResponse;
	}



	@Tool(description = "get pdf text")
    public List<Document> get_pdf_text(String fileWithpath, int numPages)
			throws Exception
	{

	// fileWithpath example: "classpath:file1.pdf" or "file:/var/tmp/file1.pdf"
 	Resource pdfResource = resourceLoader.getResource(fileWithpath);

	if (numPages > 0) {

		try (PDDocument fullDoc = Loader.loadPDF(new RandomAccessReadBuffer(pdfResource.getInputStream()))) {
			Splitter splitter = new Splitter();
			splitter.setStartPage(1);
			splitter.setEndPage(numPages);
			
			try (PDDocument subDoc = splitter.split(fullDoc).get(0)) {
				ByteArrayOutputStream out = new ByteArrayOutputStream();
				subDoc.save(out);
				
				Resource subResource = new ByteArrayResource(out.toByteArray());
				
				PdfDocumentReaderConfig config = PdfDocumentReaderConfig.builder()
						.withPagesPerDocument(1)
						.build();
				
				return new PagePdfDocumentReader(subResource, config).read();
			}
		}

	} else {
		PagePdfDocumentReader pdfReader = new PagePdfDocumentReader(pdfResource);
        return pdfReader.get(); 
	}
    }


	@Tool(description = "get doc text")
    public List<Document> get_doc_text(String fileWithpath)
			throws Exception
	{

		// fileWithpath example: "classpath:file1.doc" or "file:/var/tmp/file1.doc"
		Resource docResource = resourceLoader.getResource(fileWithpath);

		TikaDocumentReader tikaReader = new TikaDocumentReader(docResource);

        return tikaReader.get(); 
    }

}
 
 

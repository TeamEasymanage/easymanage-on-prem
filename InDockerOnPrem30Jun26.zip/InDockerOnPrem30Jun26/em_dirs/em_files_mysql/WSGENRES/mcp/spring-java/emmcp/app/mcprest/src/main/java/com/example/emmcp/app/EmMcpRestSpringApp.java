package com.example.emmcp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmMcpRestSpringApp {

    public static void main(String[] args) {
        SpringApplication.run(EmMcpRestSpringApp.class, args);
    }

}

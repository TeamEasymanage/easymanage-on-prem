
# React Project in Next.js

## Start a New React Project

* Guideline from https://react.dev/learn/start-a-new-react-project
    - If you want to build a new app or a new website fully with React, we recommend picking one of the React-powered frameworks popular in the community.

## Production-grade React frameworks : Next.js 

Next.js is a full-stack React framework.

>System Requirements:
>
>>Node.js 18.17 or later.
>>macOS, Windows (including WSL), and Linux are supported.

### Project Creation/Setup

`em_app` project is Next.js project, created with:

Node v20.9.0

```
npx create-next-app@latest
```

Options selected:

```
npx create-next-app@latest
Need to install the following packages:
  create-next-app@14.0.2
Ok to proceed? (y) y
√ What is your project named? ... em_app
√ Would you like to use TypeScript? ... Yes
√ Would you like to use ESLint? ... Yes
√ Would you like to use Tailwind CSS? ... Yes
√ Would you like to use `src/` directory? ... Yes
√ Would you like to use App Router? (recommended) ... Yes
√ Would you like to customize the default import alias (@/*)? ... No
```

#### Install/setup:

Follow instructions in `em_app/README.md`

```
cd em_app
```

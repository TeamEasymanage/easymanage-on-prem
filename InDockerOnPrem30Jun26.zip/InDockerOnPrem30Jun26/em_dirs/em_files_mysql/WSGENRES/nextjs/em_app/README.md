
This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

## Getting Started


### Install/setup:

```
npm install --force
```

### Build project

Build project and generate static pages / server side rendered pages :

```
npm run build
```

### Run project

Run project:

Note: Pre-requisite project must be built first with `npm run build`

```
npm run start
```

> INFO
>> If Using Java-Spring APIs
>> * Please set proper values as below
>> * `NEXT_PUBLIC_apiPageStartAtZero=Yes` in `.env`
>> * `apiPageStartAtZero=Yes` in `.env.local`


### Run in development mode

For interactive editing during development, Run the development server:

```
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

You can start editing the page by modifying `app/page.tsx`. The page auto-updates as you edit the file.

This project uses [`next/font`](https://nextjs.org/docs/basic-features/font-optimization) to automatically optimize and load Inter, a custom Google Font.


### Project Info `em_app`


#### Environment Files `.env` and `.env.local`

* `.env` is used by / for Client Components | in Migrated CRA Apps
* `.env.local` is used by / for Next.js Server Components

#### App Router : Rendering Environments

There are two environments where web applications can be rendered: the client and the server.

em_app project has both parts client side rendering (CSR) and server side rendering (SSR).

#### Rendering Client Components | Client Side Rendering (CSR)

Inside folder `em_app\src\app\pages\csr`, pages & routes are based on client components with client side rendering (CSR).

#### Server Side Rendering (SSR) 

Inside folder `em_app\src\app\pages\ssr`, pages & routes are based on Server Side Rendering (SSR).

#### Static Export | Static Site Generation (SSG) 

Inside folder `em_app\src\app\pages\ssg`, pages & routes are based on Static Site Generation (SSG).

#### Incremental Static ReGeneration (ISR) 

Inside folder `em_app\src\app\pages\isr`, pages & routes are based on Incremental Static ReGeneration (ISR).

## Learn More

To learn more about Next.js, take a look at the following resources:

- [Next.js Documentation](https://nextjs.org/docs) - learn about Next.js features and API.
- [Learn Next.js](https://nextjs.org/learn) - an interactive Next.js tutorial.

You can check out [the Next.js GitHub repository](https://github.com/vercel/next.js/) - your feedback and contributions are welcome!


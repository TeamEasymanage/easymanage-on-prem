'use client'
import React, { useState } from 'react';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

import { SideBarNavEntries } from './emNav';
import { SideNavEntry } from './SideNavEntry';

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronDown } from "@fortawesome/free-solid-svg-icons";

const SideBar = () => {
  return (
    <div>
    <style>{`
    .scroll1 {
      overflow-y: scroll;  
    }
    `}</style>
    <div className="md:w-60 bg-white h-screen flex-1 fixed border-r border-zinc-200 hidden md:flex">
      <div className="flex flex-col space-y-6 w-full">

      <div className='pb-2'>
        <Link
          href="/"
          className="flex flex-row space-x-3 items-center justify-center md:justify-start md:px-6 border-b border-zinc-200 h-12 w-full"
          >
          <span className="h-7 w-7 bg-zinc-300 rounded-lg" />
          <span className="font-bold text-xl hidden md:flex">EM App</span>
        </Link>
      </div>

        <div className="scroll1 flex flex-col space-y-2  md:px-6 ">
          {SideBarNavEntries.map((entry, idx) => {
            return <MenuEntry key={idx} entry={entry} />;
          })}
        </div>
      </div>
    </div>
    </div>
  );
};

export default SideBar;

const MenuEntry = ({ entry }: { entry: SideNavEntry }) => {
  const pathname =  usePathname();
  const [subMenuOpen, setSubMenuOpen] = useState(false);
  //let subMenuOpen = false;

  const toggleSubMenu = () => {
    setSubMenuOpen(!subMenuOpen);
  };

  return (
    <div className="">
      {entry.hasSubMenu ? (
        <>
          <button
            onClick={toggleSubMenu}
            className={`flex flex-row entrys-center p-2 rounded-lg hover-bg-zinc-100 w-full justify-between hover:bg-zinc-100 ${
              pathname.includes(entry.path) ? 'bg-zinc-100' : ''
            }`}
          >
            <div className="flex flex-row space-x-4 entrys-center">
              {entry.icon}
              <span className="text-left  flex">{entry.label}</span>
            </div>

            <div className={`${subMenuOpen ? 'rotate-180' : ''} flex`}>
              <FontAwesomeIcon icon={faChevronDown} style={{ color:'grey', fontSize: 18 }} />        
            </div>
          </button>

          {subMenuOpen && (
            <div className="my-2 ml-12 flex flex-col space-y-4">
              {entry.subMenuList?.map((subEntry, idx) => {
                return (
                  <Link
                    key={idx}
                    href={subEntry.path}
                    className={`${
                      subEntry.path === pathname ? 'font-bold' : ''
                    }`}
                  >
                    <span>{subEntry.label}</span>
                  </Link>
                );
              })}
            </div>
          )}
        </>
      ) : (
        <Link
          href={entry.path}
          className={`flex flex-row space-x-4 entrys-center p-2 rounded-lg hover:bg-zinc-100 ${
            entry.path === pathname ? 'bg-zinc-100' : ''
          }`}
        >
          {entry.icon}
          <span className="text-left flex">{entry.label}</span>
        </Link>
      )}
    </div>
  );
};

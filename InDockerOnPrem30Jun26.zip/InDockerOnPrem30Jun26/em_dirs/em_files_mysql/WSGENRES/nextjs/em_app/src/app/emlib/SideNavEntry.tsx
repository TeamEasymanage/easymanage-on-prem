
export type SideNavEntry = {
  label: string;
  path: string;
  icon?: JSX.Element;
  hasSubMenu?: boolean;
  subMenuList?: SideNavEntry[];
};

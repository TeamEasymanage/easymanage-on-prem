
/*
  - reads environment variables from .env.local 
*/

export function getApiPageNo(pageNo: number) {

  var apiPageStartAtZero = process.env.apiPageStartAtZero;

  if (apiPageStartAtZero === 'Yes') {
    return Number(pageNo - 1);
  }
  return pageNo;
}

export function getApiHeaders(meth?: number | undefined) {
  var headers = {};
  //console.log(process.env.isApiCallSecure);
  
  var apiSecure = process.env.isApiCallSecure;

  //create/edit
  if (meth === 2) {
    headers = 
      { 
      "Content-Type": "application/json",
      };
  }
  if (apiSecure == 'Yes') {
    console.log('Secure API Yes Server Component');
  if (meth === 2) {
    headers = 
      { 
        "Content-Type": "application/json",
        "Authorization":  getBasicAuthString() 
      };
  } else {
    headers = 
      { 
      "Authorization":  getBasicAuthString() 
      };
  }
  }
  //console.log(headers);
  return headers;
}

function getBasicAuthString() {
  var user = process.env.apiUsername;
  var password = process.env.apiPassword;
  var userPass = user + ":" + password;
  var authString = Buffer.from(userPass).toString('base64'); //btoa(token);
  return "Basic " + authString;
}

export function getEmUri() {
  var p1 = process.env.apiScheme  || 'http';
  var p2 = process.env.apiUrl || '127.0.0.1:9080';
  var p3 = process.env.apiPathPrefix || '/emdbrest';
  return p1 + '://' + p2 + p3 ;
}

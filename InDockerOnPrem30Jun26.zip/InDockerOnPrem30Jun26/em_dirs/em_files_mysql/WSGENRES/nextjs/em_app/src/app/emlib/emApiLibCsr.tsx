
/*
  - reads environment variables from .env 
*/
//"Access-Control-Allow-Origin": "http://127.0.0.1:3000/",

export function getApiPageNo(pageNo: number) {

  var apiPageStartAtZero = process.env.NEXT_PUBLIC_apiPageStartAtZero;

  if (apiPageStartAtZero === 'Yes') {
    return Number(pageNo - 1);
  }
  return pageNo;
}

export function getApiHeaders(meth?: number | undefined) {
  var headers = {};
  //console.log(process.env.NEXT_PUBLIC_isApiCallSecure);
  
  var apiSecure = process.env.NEXT_PUBLIC_isApiCallSecure;

  //create/edit
  if (meth === 2) {
    headers = 
      { 
        "Content-Type": "application/json",
      };
  }

  if (apiSecure == 'Yes') {
    console.log('Secure API Yes CSR');
  if (meth === 2) {
    headers = 
      { 
        "Content-Type": "application/json",
        "Authorization":  getBasicAuthString() 
      };
  } else {
    headers = 
      { 
        "Authorization":  getBasicAuthString() 
      };
  }
  }
  //console.log(headers);
  return headers;
}

function getBasicAuthString() {
  var user = process.env.NEXT_PUBLIC_apiUsername;
  var password = process.env.NEXT_PUBLIC_apiPassword;
  var userPass = user + ":" + password;
  var authString = Buffer.from(userPass).toString('base64'); //btoa(token);
  return "Basic " + authString;
}

export function getEmUri() {
  var p1 = process.env.NEXT_PUBLIC_apiScheme  || 'http';
  var p2 = process.env.NEXT_PUBLIC_apiUrl || '127.0.0.1:9080';
  var p3 = process.env.NEXT_PUBLIC_apiPathPrefix || '/emdbrest';
  return p1 + '://' + p2 + p3 ;
}

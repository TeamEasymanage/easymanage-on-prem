
/*
  - function library 
*/

export function GetCurrDateAsStr() {
  var myDate = new Date();   
  var yyyy = myDate.getFullYear().toString();
  var MM = pad(myDate.getMonth() + 1,2);
  var dd = pad(myDate.getDate(), 2);
  var hh = pad(myDate.getHours(), 2);
  var mm = pad(myDate.getMinutes(), 2)
  var ss = pad(myDate.getSeconds(), 2)

  var dateStr = yyyy + '-' + MM + '-'+ dd + ' '+  hh + ':' + mm + ':'+ ss;
  return dateStr;
}

function pad(number: number, length: number) {
  var str = '' + number;
  while (str.length < length) {
      str = '0' + str;
  }
  return str;
}

export function parseEmNumber(value: string){
  const numVal = Number(value);

  return Number.isNaN(numVal) ? 0 : numVal; 
}

export function parseEmBoolean(value: string){
  if (!value) {
    return false
  }

  switch (value.toLocaleLowerCase()) {
    case 'true':
    case 't':
    case '1':
    case 'on':
    case 'yes':
    case 'y':
        return true
    case 'false':
    case 'f':
    case '0':
    case 'off':
    case 'no':
    case 'n':
        return false
    default:
      return false
  }
}

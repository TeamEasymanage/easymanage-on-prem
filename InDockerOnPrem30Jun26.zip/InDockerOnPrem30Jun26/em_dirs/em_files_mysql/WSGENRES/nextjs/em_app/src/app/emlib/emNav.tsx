
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHome, faCog, faInfoCircle } from "@fortawesome/free-solid-svg-icons";

import { SideNavEntry } from './SideNavEntry';
import { SideBarNavEntriesEmNav }  from '@/app/pages/nav/emNavList';

const SideBarNavEntriesPrefix: SideNavEntry[] = [
  {
    label: 'Home',
    path: '/',
    icon: <FontAwesomeIcon icon={faHome}  style={{ color:'grey', fontSize: 18 }} /> ,
  },
];

const SideBarNavEntriesSuffix: SideNavEntry[] = [
  {
    label: 'Settings',
    path: '/',
    icon: <FontAwesomeIcon icon={faCog} style={{ color:'grey', fontSize: 18 }} /> ,
  },
  {
    label: 'Help',
    path: '/',
    icon: <FontAwesomeIcon icon={faInfoCircle} style={{ color:'grey', fontSize: 18 }} /> ,
  },
];

export const SideBarNavEntries: SideNavEntry[] = SideBarNavEntriesPrefix.concat(SideBarNavEntriesEmNav, SideBarNavEntriesSuffix);

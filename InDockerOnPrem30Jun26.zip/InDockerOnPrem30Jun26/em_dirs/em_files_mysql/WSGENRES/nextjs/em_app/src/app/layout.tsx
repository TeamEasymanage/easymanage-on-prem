import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

import Link from 'next/link';
import SideBar from './emlib/SideBar';

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";

const inter = Inter({ subsets: ['latin'] })

import "@fortawesome/fontawesome-svg-core/styles.css";
import { config } from "@fortawesome/fontawesome-svg-core";
config.autoAddCss = false;

export const metadata: Metadata = {
  title: 'EM App',
  description: 'EM App',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="flex">
          <SideBar />
          <main className="flex-1">
            <div className="flex flex-col md:ml-60 sm:border-r sm:border-zinc-700 min-h-screen">

              <div className="sticky inset-x-0 top-0 z-30 w-full transition-all border-b border-gray-200 border-b border-gray-200 bg-white">
                <div className="flex h-[47px] items-center justify-between px-4">
                  <div className="flex items-center space-x-4">
                    <Link
                      href="/"
                      className="flex flex-row space-x-3 items-center justify-center md:hidden"
                    >
                      <span className="h-7 w-7 bg-zinc-300 rounded-lg" />
                      <span className="font-bold text-xl flex ">Logo</span>
                    </Link>
                  </div>

                  <div className="hidden md:block">
                    <div className="h-8 w-8 rounded-full bg-zinc-300 flex items-center justify-center text-center">
                      <span className="font-semibold text-sm">
                      <FontAwesomeIcon icon={faUser} style={{ color:'grey', fontSize: 18 }} />        
                      </span>
                    </div>
                  </div>
                </div>
              </div>




              <div className="flex flex-col pt-2 px-4 space-y-2 bg-zinc-100 flex-grow pb-4">
                {children}
              </div>
            </div>
          </main>
        </div>
      </body>
    </html>
  )
}

/*

            <div
      className="sticky inset-x-0 top-0 z-30 w-full transition-all border-b border-gray-200 border-b border-gray-200 bg-white/75 backdrop-blur-lg"
      >



<div className="flex flex-col md:ml-60 sm:border-r sm:border-zinc-700 min-h-screen">

              <div className="flex flex-col pt-2 px-4 space-y-2 bg-zinc-100 flex-grow pb-4">
                <p></p>        

                <Link
                  href="/"
                  className="flex flex-row space-x-3 entrys-center justify-center md:justify-start md:px-6 border-b border-zinc-200 h-12 w-full"
                  >
                  <span className="h-7 w-7 bg-zinc-300 rounded-lg" />
                  <span className="font-bold hidden md:flex">EM App</span>
                </Link>
              </div>

              <div className="flex flex-col pt-2 px-4 space-y-2 bg-zinc-100 flex-grow pb-4">
                {children}
              </div>
            </div>
*/
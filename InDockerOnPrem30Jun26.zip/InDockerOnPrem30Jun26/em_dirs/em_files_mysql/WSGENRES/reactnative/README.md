# EasyManage

## Frontend : React Native (Preview)

Supports EasyManage GraphQL APIs. Customize to use your own graphql APIs.

### Installation

* Create your react native project
    - ```<PROJECTDIR>``` is project folder, usually ```emapp```
* Copy files from ```./emapp``` directory to your project dir
* Edit and set correct location dir of Android SDK in file `<PROJECTDIR>\android\local.properties`
    - Set correct value for `sdk.dir=`
	- Create file if not there

* cd to <PROJECTDIR>
```
cd <PROJECTDIR>
```

* Install setup
```
npm install --force
```

* **IMP**
* 1) Apply patch for ```react-native-reanimated": "^3.0.2"```
    - Copy provided `../patch/NativeProxyCommon.java` to target dir and replace same file:
    - `<PROJECTDIR>\node_modules\react-native-reanimated\android\src\main\java\com\swmansion\reanimated\nativeProxy`
* 2) Make sure `<PROJECTDIR>\android\app\src\main\java\com\emapp\MainActivity.java` has needed edits as per `../patch/MainActivity.java`.

* Update setup
```
npm update --force
```

* Update EmNav.js with correct machine IP Address (your desktop IP Address) where GraphQL is running 
    - e.g. ```uri: 'http://192.168.1.106:9080/graphql', ```


### Build and Run

```
npm start
```

From 2nd Terminal

Make sure an android virtual machine or USB connected device is available via
```
adb devices
```

Run
```
npm run android
```

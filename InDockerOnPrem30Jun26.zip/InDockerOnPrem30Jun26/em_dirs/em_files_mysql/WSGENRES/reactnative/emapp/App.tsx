import 'react-native-gesture-handler';

import * as React from 'react';

import {  AppNav }  from './EmNav';

function App() {
  return (
      AppNav()
      );
}

export default App;

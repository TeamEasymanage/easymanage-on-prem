import * as React from 'react';

import { NavigationContainer, DefaultTheme , DarkTheme } from '@react-navigation/native';
import { createNativeStackNavigator  } from '@react-navigation/native-stack';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { Button } from 'react-native-elements';

import { ApolloClient } from 'apollo-client';
import { InMemoryCache } from 'apollo-cache-inmemory';
import { HttpLink } from 'apollo-link-http';
import { ApolloProvider } from 'react-apollo';

import { AppNavScreens } from './EmNavScreens';

export { AppNav }

const cache = new InMemoryCache();
const client = new ApolloClient({
  cache,
  link: new HttpLink({
    uri: 'http://192.168.1.106:9070/graphql',
  }),
});


const Stack = createNativeStackNavigator();
const Drawer = createDrawerNavigator();

function AppNav() {
  return (
    <ApolloProvider client={client}>
      <AppNavScreens/>
      </ApolloProvider>
  );
}
  
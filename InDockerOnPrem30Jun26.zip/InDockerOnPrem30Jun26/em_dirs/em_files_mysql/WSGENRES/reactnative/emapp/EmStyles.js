import { StyleSheet } from 'react-native';

module.exports = StyleSheet.create({
  container: {
      flex: 1,
      paddingBottom: 22
  },
  subContainer: {
      flex: 1,
      paddingBottom: 20,
      borderBottomWidth: 2,
      borderBottomColor: '#CCCCCC',
  },
  item: {
      padding: 10,
      fontSize: 18,
      height: 44,
  },
  activity: {
      position: 'absolute',
      left: 0,
      right: 0,
      top: 0,
      bottom: 0,
      alignItems: 'center',
      justifyContent: 'center'
  },
  emText: {
      //backgroundColor:"white", 
      color: "grey"
  }
})

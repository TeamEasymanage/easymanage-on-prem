
rem ----@echo off

rem ----------------------------
SET bat_dir=%~dp0%
SET base_dir=%bat_dir%..\..\..\

SET run_dir=%CD%

SET api_type=rest

set OPENAI_API_KEY=%OPENAI_API_KEY%
rem ----------------------------

rem ----------------------------
rem --- build only 1 at a time
set apiBuild="True"
set mcpBuild="True"
set agtBuild="True"

@echo off
SET condition_var=A

IF "%1%" == "" (
echo "All set"
)
IF "%1%" == "1" (
set mcpBuild="False"
set agtBuild="False"
echo "Only API set"
)
IF "%1%" == "2" (
set apiBuild="False"
set agtBuild="False"
echo "Only MCP set"
)
IF "%1%" == "3" (
set apiBuild="False"
set mcpBuild="False"
echo "Only AGT set"
)
rem ----------------------------

IF %agtBuild% == "True" (

echo "----------------------------"
echo Check OPENAI_API_KEY set ...

IF "%OPENAI_API_KEY%"=="" (
    ECHO Error: OPENAI_API_KEY is empty. Edit/Set as env or in this script and re-run.
    EXIT /B 1
)
)

echo "----------------------------"
echo The RUN directory is : %run_dir%
echo The script directory is : %base_dir%


IF %apiBuild% == "True" (

echo "----------------------------"
echo "Stage: Backend"
echo "Build and run backend REST APIs"

CD %base_dir%\backend\spring-java\emapi
dir 

echo "Run: mvn clean package -B "

call mvn clean package -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

echo "Run: START APIs Jar"
start java -jar app\db%api_type%\target\db%api_type%-1.0-SNAPSHOT.jar

timeout /t 10

cd %run_dir%

)

IF %mcpBuild% == "True" (

echo "----------------------------"
echo "Stage: MCP"
echo "Build and run mcp REST"

CD %base_dir%\mcp\spring-java\emmcp
dir 

echo "Run: mvn clean install -B "

call mvn clean install -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

echo "Run: START MCP Jar"
start java -jar app\mcp%api_type%\target\mcp%api_type%-1.0-SNAPSHOT.jar

timeout /t 10

cd %run_dir%

)

IF %agtBuild% == "True" (

echo "----------------------------"
echo "Stage: Agent Server"
echo "Build and run agentserver"

CD %base_dir%\agent\spring-java\agentserver
dir 

echo "Run: mvn clean package -B "

call mvn clean package -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

echo "Run: START Agent Server Jar"
start java -jar target\agentserver-1.0-SNAPSHOT.jar

timeout /t 10

cd %run_dir%

)

echo "Done"


rem ----@echo off

rem ----------------------------
SET bat_dir=%~dp0%
SET base_dir=%bat_dir%..\..\..\

SET run_dir=%CD%

SET api_type=rest

rem ----------------------------

rem ----------------------------
rem --- build only 1 at a time
set apiBuild="True"
set mcpBuild="True"
set agtBuild="True"

@echo off
SET condition_var=A

IF "%1%" == "" (
echo "All set"
)
IF "%1%" == "1" (
set mcpBuild="False"
set agtBuild="False"
echo "Only API set"
)
IF "%1%" == "2" (
set apiBuild="False"
set agtBuild="False"
echo "Only MCP set"
)
IF "%1%" == "3" (
set apiBuild="False"
set mcpBuild="False"
echo "Only AGT set"
)
rem ----------------------------


echo "----------------------------"
echo The RUN directory is : %run_dir%
echo The script directory is : %base_dir%


IF %apiBuild% == "True" (

echo "----------------------------"
echo "Stage: Backend"
echo "Clean backend REST APIs"

CD %base_dir%\backend\spring-java\emapi
dir 

echo "Run: mvn clean -B "

call mvn clean -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

timeout /t 2

cd %run_dir%

)

IF %mcpBuild% == "True" (

echo "----------------------------"
echo "Stage: MCP"
echo "Clean mcp REST"

CD %base_dir%\mcp\spring-java\emmcp
dir 

echo "Run: mvn clean -B "

call mvn clean -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

timeout /t 2

cd %run_dir%

)

IF %agtBuild% == "True" (

echo "----------------------------"
echo "Stage: Agent Server"
echo "Clean agentserver"

CD %base_dir%\agent\spring-java\agentserver
dir 

echo "Run: mvn clean -B "

call mvn clean -B 
if not "%ERRORLEVEL%"=="0" echo "Maven clean failed. Exiting." & exit /b %ERRORLEVEL%

timeout /t 2

cd %run_dir%

)

echo "Done"

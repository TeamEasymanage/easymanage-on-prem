# EasyManage: Templates

Repository containing EasyManage template projects

---

## Templates 

Each folder contains a template project which can be used with EasyManage generated code. Template projects contain sample apps, examples, customizations and enhancements to use with EasyManage generated code. 

Details on how to deploy the template project is specified in respective READMEs.

You may refer to our core docs at [EasyManage Docs](https://easymanage.com/res/docs/intro)

> Note: If a template contains customizations or enhancements to be merged with generated code, please make sure first that the generated code project is able to build & run.

### Backend Templates 

* Code Coverage - SonarQube, JaCoCo
    - Code Coverage Analysis [backend/spring-java/code-coverage](https://github.com/TeamEasymanage/templates/tree/main/backend/spring-java/code-coverage)
* Extend
  - Identifiers, @GeneratedValue
  - Validations
  - DTO (Data Transfer Object)
* Security 
  - OAuth2
  - Keycloak
  - Social (Google, Github, ...)
* Logging - ELK (Elasticsearch, Logstash, and Kibana)
* Integrating - Kafka
* Testing
  - System Testing - Performance, Load testing
  - TDD (Test Driven Development)
  - Smoke Testing
  - BDD (Behavior-Driven Development)


# README - Kestra

Kestra is an open-source AI Agents workflow scheduling platform. It allows you to schedule Agent Runs, Execute & View past Executions. Create Schedules i.e. Flows by writing simple YAML configuration files.

## Docker Container Setup

After Generate Code : List Builds | Download 

* In extracted zip folders, cd to, e.g.:
    - `cd EmGenDir_MYTEMP01_WS_51246\WS_51246\tools\kestra`

Please view environment variables and update your values in file:
- `.env` 

### Build and Run

Build and Run: 

`docker compose up -d`

## Using Kestra UI

* Access UI at: [http://127.0.0.1:9020/](http://127.0.0.1:9020/)
* Using User and password from `.env` file.

### Create Agent Schedule and Execute

* Create New Flow using sample file `flow_agent_5005235.yml`
    - Copy file
    - Replace `body:` with Agent Run Auto Screen.
* Kestra : Flows : Create
    - Paste the yml : Save
    - Note: To access AgentServer on host machine, use `host.docker.internal` as host in uri
    - Schedule/Triggers: Are set by yml section `triggers:`
* Once created `flow_agent_5005235` is listed in Kestra : Flows.
    - Select Flow : `flow_agent_5005235`
* View Schedule of Agent Run under
    - Triggers
* Execute Flow
    - Executions : View Results Of Agent Runs

* Email Agent Run reports: 
	- To send an output report via email in Kestra, use the MailSend task

### Container Lifecycle

* Start | Stop containers

Start existing containers
`docker compose start`

Stops running containers
`docker compose stop`

* Container Removal

Caution: Your Data will be lost!

* Remove Container and the volumes associated
`docker compose down -v`

# EasyManage Templates

## DevOps

DevOps is a collection of practices, processes, and tools that allow development and operations teams to work together, to help streamline development.

### CI/CD

CI/CD (continuous integration/continuous delivery) practices help to deliver code changes rapidly and reliably. So they help ensure the reliable delivery of frequent code changes. 

### Shift Left

Shift left is the practice of moving testing, quality, security evaluation early in the development process, integrated with CI.

### Shift Right

Shift right is the practice of maintaining software reliability and performance in production, integrated with CD.

### Shift Left Vs Shift Right

Consider the software development cycle as a continous loop (in shape of horizontal 8), from left to right.

On the left side are pre-production proceses: plan, develop, and test software.
The main goal is building software that meets design criteria.

On the right side are processes after release of software into production and made available to users. The main goal in production is ensure performance, resilience and reliability.

## CI/CD Tools

### Jenkins

[Jenkins](https://www.jenkins.io/) is a popular open source DevOps CI/CD tool cum automation server used by many.

It manages and controls continuous integration process of software build, testing, packaging, and static code analysis via pipeline jobs. 

Jenkins pipelines are commonly triggered by code changes in repositories like GitHub and integrate with build tools like Maven. 

Please refer to [EasyManage Templates - Jenkins Readme](./jenkins/README-jenkins.md) for using Jenkins CI/CD.

### Jenkins X 

[Jenkins X](https://jenkins-x.io/) automates and accelerates CI/CD for developers on the cloud. It is integrated Cloud Native solution than traditional non cloud Jenkins.

*"Jenkins X is used for automated CI/CD GitOps based Tekton pipelines"*
*"Rather than having to have deep knowledge of Kubernetes, containers or Tekton, Jenkins X will automate awesome Tekton pipelines for your projects that fully implements CI and CD which you can manage via GitOps"*

### GitLab CI/CD

[GitLab CI/CD](https://docs.gitlab.com/ee/ci/) is a continuous method of software development, where you continuously build, test, deploy, and monitor iterative code changes.

* The `.gitlab-ci.yml` file
    - To use GitLab CI/CD, you start with a `.gitlab-ci.yml` file at the root of your project which contains the configuration for your CI/CD pipeline. 
    - Sample file provided: `emapi\.gitlab-ci.yml`

# EasyManage Templates

## Jenkins

Jenkins is used for CI/CD.

### Run Jenkins in Docker 

Please refer to [Downloading and running Jenkins in Docker](https://www.jenkins.io/doc/book/installing/docker/)

## CI/CD Pipelines

Jenkins can run pipeline job with various stages in software build, testing, verification, packaging, deployment, etc.

### Testing, Code Coverage

According to DevOps principles, automating tests in CI/CD pipelines is a best practice. Tests need to be run after source code change triggers like PR, in unattended fashion to be effective. Run Unit testing and integration testing in CI/CD.

### Build and Deploy to Development

Automate building project and deploying to docker development environment.

### Jenkin pipeline stages

View pipeline stages that can be setup and are run, in sample file provided: `emapi\Jenkinsfile`

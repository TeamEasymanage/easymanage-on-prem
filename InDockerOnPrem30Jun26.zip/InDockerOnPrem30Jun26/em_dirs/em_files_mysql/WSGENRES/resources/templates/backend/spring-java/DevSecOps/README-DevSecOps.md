# EasyManage Templates

## DevSecOps

DevSecOps is an extension of DevOps that integrates security into the entire software development process, specifically into CI/CD pipeline.

## DevSecOps Tools

## For Backend - Java Spring Boot

### SonarQube 

SonarScanner used for assessing code quality, analyze the code including
- Static Code Analysis
- Security Analysis

* Please see Jenkin pipeline sonar scan stage in `emapi\Jenkinsfile`

### Maven Dependency Analysis

* Please see Jenkin pipeline Maven Dependency Analysis stage in `emapi\Jenkinsfile`

### OWASP dependency check Maven

Note: 1st Run >20Min

* Please see Jenkin pipeline OWASP dependency check stage in `emapi\Jenkinsfile`

### Sonatype Lifecycle

> Note: Using Sonatype Nexus IQ requires buying license.

[Sonatype Lifecycle](https://help.sonatype.com/en/sonatype-lifecycle.html)

Sonatype Lifecycle is the solution to identify open-source risks and to secure your software supply chain. With Lifecycle, you create custom policies which are enforceable across all stages of your software development lifecycle (SDLC).

Please refer to [Sonatype Lifecycle Readme](./sonatype/README-sonatype.md)

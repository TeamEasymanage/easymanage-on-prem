# EasyManage Templates

## Sonatype Lifecycle

> Note: Using Sonatype Nexus IQ requires buying license.

[Sonatype Lifecycle](https://help.sonatype.com/en/sonatype-lifecycle.html)

Sonatype Lifecycle is the solution to identify open-source risks and to secure your software supply chain. With Lifecycle, you create custom policies which are enforceable across all stages of your software development lifecycle (SDLC).

Sonatype Lifecycle Security Evaluation produces a report: 
* The Application Composition Report serves as a point-in-time report representing risk associated with component usage for a specific application. 
* It contains a summary, a Policy Violation Table, and Vulnerabilities Lists.


## Run Sonatype Nexus IQ in Docker 

Please refer to [Sonatype Nexus IQ Server Docker](https://hub.docker.com/r/sonatype/nexus-iq-server)

`cd emapi`

Building the Sonatype Container with docker-compose
`docker-compose -f docker-compose-sonatype.yml build`

Running Sonatype Container
`docker-compose -f docker-compose-sonatype.yml up -d`

* Once running, apply IQ Server product license
    - Access UI: [http://localhost:8070](http://localhost:8070)
    - With Default admin credentials: admin / admin123

## CI/CD Pipelines

### Sonatype Lifecycle pipeline usage

Use Maven Plugin

### Sonatype CLM for Maven

Doc page [Sonatype CLM for Maven](https://help.sonatype.com/en/sonatype-clm-for-maven.html)

Sonatype CLM for Maven is a Maven plugin that allows users to evaluate any Maven-based software projects. Run Sonatype CLM for Maven from a command line interface to integrate with any CI server or IDE.


#### Maven Goals

* `evaluate` goal invocation example:

```
mvn package com.sonatype.clm:clm-maven-plugin:evaluate -Dclm.additionalScopes=test,provided -Dclm.applicationId=test -Dclm.serverUrl=http://localhost:8070 -Dclm.username=admin -Dclm.password=admin123
```

* Evaluate goal example results

```
[INFO] --- clm-maven-plugin::evaluate (default-cli) @ line-comm-03 ---
[INFO] Starting scan...
...
[INFO] Evaluating policies on http://localhost:8070 ...
[ERROR] Sonatype IQ reports policy 'Security-Critical' failing for 
  component 'org.apache.logging.log4j:log4j-core:2.9.0' with hash '052f6548ae1688e126c2' due to 
    constraint 'Critical risk CVSS score': 
      Security Vulnerability Severity >= 9 because: Found security vulnerability CVE-2021-44228 with severity >= 9 (severity = 10.0)
[INFO] ------------------------------------------------------------------------
[INFO] Policy Action: Failure
[INFO] Number of components affected: 1 critical, 0 severe, 0 moderate
[INFO] Number of open policy violations: 2 critical, 0 severe, 1 moderate
[INFO] Number of grandfathered policy violations: 0
[INFO] Number of components evaluated: 5
[INFO] The detailed report can be viewed at: http://localhost:8070/ui/links/application/local-iq-app/report/755d19e970fd491ca2e23f21bea35d58
[INFO] ------------------------------------------------------------------------
[INFO] BUILD FAILURE
------------------------------------------------------------------------
```

* To generate JSON file with scan result information, add parameter to maven goal execution:

` -Dclm.resultFile=./sonatype-nexus-scan-resultfile.txt `

A file is created with evaluation results in below format:
```
{
    "applicationId" : "...",
    "scanId" : "...",
    "reportHtmlUrl" : "http://...",
    "reportPdfUrl" : "http://.../pdf",
    "reportDataUrl" : "http://.../raw",
    "policyAction" : "None",
    "policyEvaluationResult" : {
        "alerts" : [...detailed list of components which caused the violation...],
        "affectedComponentCount" : 15,
        "criticalComponentCount" : 4,
        "severeComponentCount" : 65,
        "moderateComponentCount" : 36,
        "criticalPolicyViolationCount" : 4,
        "severePolicyViolationCount" : 85,
        "moderatePolicyViolationCount" : 46,
        "grandfatheredPolicyViolationCount" : 0,
        "legacyViolationCount" : 0
     }
}
```

#### Using specific sonatype plugin version

Add Maven dependency with specific version:

To evaluate emapi multi-module project, add dependency to root level pom.xml:
* Edit `emapi\pom.xml` and add below

```
	<!--conf-sonatype-->
	<dependencies>
		<dependency>
			<groupId>com.sonatype.clm</groupId>
			<artifactId>clm-maven-plugin</artifactId>
			<version>2.47.12-01</version>
		</dependency>
	</dependencies>
```

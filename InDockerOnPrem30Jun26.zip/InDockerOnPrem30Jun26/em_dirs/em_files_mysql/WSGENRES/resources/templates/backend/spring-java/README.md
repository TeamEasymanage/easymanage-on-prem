# EasyManage Templates

## Backend Spring Java

### Extend with EasyManage Templates

> Tip: Extend generated code with EasyManage templates. Template projects contain sample apps, examples, customizations and enhancements to use with EasyManage generated code. 

## EasyManage: Templates Backend Spring Java  : List

### TOC

* [Code Coverage](./code-coverage/README-code-coverage.md)

* Extend
	- [DTO](./extend/DTO/README-DTO.md)
	- [identifiers](./extend/identifiers/README-identifiers.md)
	- [validation](./extend/validation/README-validation.md)

* Integrating
	- [Kafka Events](./integrating/kafka/README-kafka.md)
	- [Kafka Streams](./integrating/kafka-streams/README-kafka-streams.md)

* Logging
	- [ELK](./logging/elk/README-elk.md)

* Security
	- [Security - Authentication & Authorization](./security-auth/README-security-auth.md)
	- [Security - OAuth2 Keycloak](./security-auth/security-keycloak/README-security-keycloak.md)
	- [Security - OAuth2](./security-auth/security-oauth2/README-security-oauth2.md)
	- [Security - Social](./security-auth/security-social/README-security-social.md)

* testing
	- [TDD](./testing/TDD/README-TDD.md)
	- [BDD](./testing/BDD/README-BDD.md)
	- [System Testing](./testing/system-testing/README-system-testing.md)
	- [Smoke Testing](./testing/smoke-testing/README-smoke-testing.md)

For previous projects migrate,
* [Migrating to Spring Boot 3 and Java 17](./migrate-to-springboot3/README-migrate-to-springboot3.md)

# EasyManage

## Caching : Redis

Redis cache can store and retrieve data quickly to improve the performance of your APIs. It is primarily designed as an in-memory data store for high-performance, low-latency data access.

The Spring Framework provides support for transparently adding caching to an application.

How-to: Provision Redis in docker side car container and enable caching.

### How to Use Redis Cache

Please refer to Documentation page:
[How to Use Redis Cache](https://easymanage.com/res/docs/backend/reference/api-how-tos#how-to-use-redis-cache)

## Run Redis in Docker Container

`cd emapi`

Building the Redis Container with docker-compose
`docker-compose -f docker-compose-redis.yml build`

Running Redis Container
`docker-compose -f docker-compose-redis.yml up -d`


### Reference

* Guide [Caching Data with Spring](https://spring.io/guides/gs/caching)
* Spring Boot features [Caching](https://docs.spring.io/spring-boot/docs/2.0.x/reference/html/boot-features-caching.html)

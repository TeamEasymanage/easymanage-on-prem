# EasyManage Templates

## Code Coverage Analysis Template

Do static source code analysis and ensure code quality with SonarQube. 

## How to Use this template

Copy/Merge below mentioned `SOURCE` folder contents into `DEST` folder.

`SOURCE` : `templates\backend\spring-java\code-coverage\emapi`

`DEST` : generated code `..\backend\spring-java\emapi`

Be careful, if you have modified generated code's `DEST\pom.xml` and do the Verify/Merge properly with `SOURCE\pom.xml`

Now Follow further instructions for/with `DEST` folder.

## Code Analysis - Code Coverage, Code Quality

Do static source code analysis, find code coverage and ensure code quality with SonarQube. 

Please refer to Documentation page:
https://easymanage.com/res/docs/backend/reference/developer-resources#code-analysis


Included below is short information for quick reference.

#### Enable flag in `pom.xml`

Note: In root level `pom.xml` Set skipTests to false, as same flag value is re-used to enable:
- tests compile
- unit tests running
- sonar scanner enable
- jacoco reports enable

* Edit `emapi\pom.xml` set property to false
- `<skipTests>false</skipTests>`

* Run maven goal
```
mvn clean verify
```

Local Code Coverage Reports are generated.
* A separate coverage report will be generated for each module.
* Also Aggregate Report of all the module-specific reports into one project-level report is generated at:
	- `emapi\coverage\target\site\jacoco-aggregate\index.html`

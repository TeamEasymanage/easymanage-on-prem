# EasyManage Templates

## Extend : DTO (Data Transfer Object)

### What is DTO

DTO is a design pattern to exchange of data between layers, often between the business logic layer and the persistence layer. For combined entities based business objects, this reduces the number of method calls between these layers by aggregating data into a single transfer object.

So DTOs (Data Transfer Objects) can facilitating efficient communication between different layers, can promote maintainability. They can reduce network calls in microservices communications also.

### When to use or not use DTO

* DTO increases mapper classes and the code lines, more codes, more bugs.
* Not advisable for the small or medium projets.
* Advisable if big project with >5 dev
* Don't create DTO for each entity, just the ones where aggregated data is transferred.
* Alternatives JsonView, JsonIgnore to custom the response.
* Alternative use GraphQL queries which can combine multiple data object queries on the fly.
* Use a mapper library

### Creating DTOs

#### Data Modeling DTOs

You can use data modeling to create nested objects with 1:1 or 1:M relationship. For other DTO needs, use example below to create a DTO:

#### Custom DTOs

DTO Pattern - To Bring all required data in one go from multiple entities.

Implement with:
 - DTO (Data Transfer Object)
 - Mapper (Convert Entity to DTO)

**Implementation Steps**

* Convert the domain objects to the DTO in the service layer as part of Business Logic.
* Reduce the accessability of domain objects only to service layer. 
* Reduce the business logic inside controllers, use them for/as Presentation Layer.

|   |   | Presentation Layer |  | Business Logic |  | Data Access |  | | 
| ---  | ---  | ---  |---  |---  |---  |--- |--- |---  |
| Request  | ⇔ | Controller (DTO)  | ⇔ | Service Layer<br> (DTO ⇔ Entity) | ⇔ | Repository (Entity) | ⇔ | Entity | 


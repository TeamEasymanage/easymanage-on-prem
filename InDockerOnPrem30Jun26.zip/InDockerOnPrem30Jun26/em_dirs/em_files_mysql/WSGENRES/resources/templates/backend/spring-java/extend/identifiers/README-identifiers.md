# EasyManage Templates

## Extend : Identifiers - Use @GeneratedValue

Identifiers in JPA/Hibernate are the primary key of an entity on database table. They are defined with @Id annotation. Usually first column of table.

### Using @GeneratedValue 

Use @GeneratedValue annotation to automatically generate the primary key value for @Id. There are four generation types: AUTO, IDENTITY, SEQUENCE and TABLE. And `GenerationType.UUID` used With java type `UUID`, and has length char (36).

> Tip: To fetch back generated value from repository use `saveAndFlush` method:

```
Product _Product = ProductTblRec1Repository.saveAndFlush(ErpProductTblRec1);
```

### GenerationType.SEQUENCE - Recommended Type

Use this when databse supports SEQUENCES. It is faster and scalable.

Use sequence creation definition like.

* PostgreSQL
    - `CREATE SEQUENCE product_id_seq START 1;`

```
	@Id 
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_generator")
    @SequenceGenerator(name="seq_generator", sequenceName = "product_id_seq", allocationSize=1)
	@Column(name = "product_id")
	private long productId;
```

### GenerationType.IDENTITY - Next Recommended Type

Use this when database supports IDENTITY columns. Use column definition like.

* MS SQL Server
    - `product_id   INT IDENTITY(1,1) NOT NULL`
* MySQL:
    - `product_id   INT NOT NULL AUTO_INCREMENT`

```
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "product_id")
	private long productId;
```

### GenerationType.AUTO - Falls back to other types

With AUTO, Hibernate will choose one of the strategies to generate your id,
* i.e. either identity column, sequence or table depending on the underlying database support.

Rather use the individual type yourself.

### GenerationType.TABLE - Simple usage for beginners

Note: This is Not efficient and don't use in production.

Pre-requisites: Create below in database using SQL:
```
CREATE TABLE hibernate_sequences ( next_val BIGINT, sequence_name char(50) );
insert hibernate_sequences (next_val, sequence_name) VALUES (100, 'default');
```
Then use it on numeric @Id column e.g. productId

```
	@Id 
	@GeneratedValue(strategy = GenerationType.TABLE)
	@Column(name = "product_id")
	private long productId;
```

Caveat: The generated value for a table is not in sequence (will have gaps),  as it will spread with all the places used.

### GenerationType.UUID - For generating UUID values

Use GenerationType.UUID for field of type `UUID` java type, the respective database column can be `char (36)`

```
@Id
@GeneratedValue(strategy = GenerationType.UUID)
private UUID orderId;
```

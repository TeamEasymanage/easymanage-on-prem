# EasyManage Templates

## Two Db Sources Template

How to Use Two Db Sources in single API project.

## How to Use this template

View in this template project, how Spring JPA Auto Configuration is overrided for configuring and using two database sources and apply similar technique in your project.

### View | Study Files

* Extract `emapi.zip` as `emapi`
* View | Study Files
	- Example shows using Two Db Sources in REST project.

## Two Db Sources in REST project

Use case applied in REST project
- `emapi\app\dbrest`

### DataSourceConfig | JpaConfig 

Location: `emapi\app\dbrest\src\main\java\com\example\emapi\app`

Files

```
Db1DataSourceConfig.java
Db1JpaConfig.java
Db2DataSourceConfig.java
Db2JpaConfig.java
```

### application.properties

File: `emapi\app\dbrest\src\main\resources\application.properties`

Notice properties setup for db1, db2:

```
# -- Db1 --
# mysql
spring.datasource.db1.url=jdbc:mysql://localhost:3306/DBNAME?useUnicode=true&characterEncoding=utf8
spring.datasource.db1.username=user
spring.datasource.db1.password=pwd

# hikari conf
spring.datasource.db1.configuration.maximum-pool-size=5

#em.datasource.db1.dialect=org.hibernate.dialect.MySQL8Dialect

# -- Db2 --
# psql
spring.datasource.db2.url=jdbc:postgresql://localhost:5432/emdb?useUnicode=true&characterEncoding=utf8
spring.datasource.db2.username=user
spring.datasource.db2.password=pwd
 
# hikari conf
spring.datasource.db2.configuration.maximum-pool-size=5

#em.datasource.db2.dialect=org.hibernate.dialect.PostgreSQLDialect

```

* If some datasource needs explicit dialect specified, e.g. db1
	- Uncomment `em.datasource.db1.dialect` in `application.properties`
	- Uncomment and use property in `Db1JpaConfig.java`


### packages re-organized | moved

* Customer table from db1
	- Dir: `emapi\lib\base-app\src\main\java\com\example\emapi\app\db1\Customer`
	- Package: `package com.example.emapi.app.db1.Customer; `

Used as:
```
import com.example.emapi.app.db1.Customer.Customer; 
import com.example.emapi.app.db1.Customer.CustomerService; 
```

* Inventory table from db2
	- Dir: `emapi\lib\base-app\src\main\java\com\example\emapi\app\db2\Inventory`
	- Package: `package com.example.emapi.app.db2.Inventory; `

Used as:
```
import com.example.emapi.app.db2.Inventory.Inventory; 
import com.example.emapi.app.db2.Inventory.InventoryService; 
```

## Two Db Sources in GraphQL project

Use case can be applied in GraphQL project by following similar technique and changes as REST.
- `emapi\app\dbgraphql`


# EasyManage Templates

## Validation in Spring Boot

Validation is used to validate user input. The standard for performing validation is with Hibernate Validator. Using annotations on fields.

One can apply and combine different validation rules to the constrained classes, via different fields in model.

Setup: Add dependency
```
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-validation</artifactId>
		</dependency>
```

> Note: Use `@Valid` annotation for method level validation, so add prefix to method parameters. e.g. `public Inventory inventoryCreate(@Valid Inventory inventoryRec)`


### For Numeric Types

Use e.g.: 
	`@NotNull`,
	`@Positive`,
	`@Pattern(regexp = "/0-9/")`,
    `@Min(10)`,
    `@Max(50)`

```
	@Id 
	@Column(name = "product_id")
	@NotNull
	@Positive
	@Pattern(regexp = "/0-9/")
    @Min(1)
	private long productId;
```

### For Character or other Types

Use e.g.:
	`@NotNull`,
	`@NotEmpty`,
	`@NotBlank`,
    `@Size(min = 2, max = 50)` - For length

```
	@Column(name = "product_name")
	@NotBlank(message = "Product Name is mandatory")
    @Size(min = 2, max = 50)
	private String productName;
```

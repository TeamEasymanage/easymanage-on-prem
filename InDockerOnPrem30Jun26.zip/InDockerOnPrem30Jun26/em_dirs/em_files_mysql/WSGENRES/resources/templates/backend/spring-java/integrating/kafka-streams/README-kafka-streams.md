# EasyManage Templates

## Kafka Streams

Kafka Streams enables the processing of streaming events. 

* It is a client library and provides features to 
- read streaming events from an input Kafka topic
- enables operations like joins, grouping, aggregation, and filtering on streaming events
- and then sends them (e.g. word count) to the Kafka output.

> Please see `..\kafka\README-kafka.md` for some common aspects and setting up Kafka.

## How to Use this template

Make note of `SOURCE` folder

`SOURCE` : `templates\backend\spring-java\integrating\kafka\emapi`

Locate generated code folder, we will refer to it as `DEST`

`DEST` : generated code `..\backend\spring-java\emapi`


### Edit pom.xml for dbrest

Locations in `DEST` :
`emapi\app\dbrest\pom.xml`

Add dependencies for Spring for Kafka:
```
		<dependency>
			<groupId>org.springframework.kafka</groupId>
			<artifactId>spring-kafka</artifactId>
		</dependency>
        <dependency>
            <groupId>org.apache.kafka</groupId>
            <artifactId>kafka-streams</artifactId>
        </dependency> 
```

## Add Kafka Streams 

### Kafka stream configuration

#### Edit `application.properties`

Locations in `DEST` :

Add to application.properties for dbrest:
`emapi\app\dbrest\src\main\resources\application.properties`

Add properties for Kafka Producer e.g. Order:
```
# -----------------------------------------------------------------
# kafka Streams
# -----------------------------------------------------------------
spring.kafka.producer.bootstrap-servers=localhost:9092
# -----------------------------------------------------------------
```

#### Add java classes

* Example: 
    - Find word count from input topic stream, write to  Kafka Streams state store, then REST endpoint to retrieve the count for given word.

Locations in `DEST` :
`emapi\lib\base-app\src\main\java\com\example\emapi\app\`

* KafkaStreamsConfig.java, 
```
@Configuration
@EnableKafka
@EnableKafkaStreams
public class KafkaStreamsConfig {

    @Value(value = "${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Bean(name = KafkaStreamsDefaultConfiguration.DEFAULT_STREAMS_CONFIG_BEAN_NAME)
    KafkaStreamsConfiguration getKafkaStreamsConfig() {
        Map<String, Object> props = new HashMap<>();
        props.put(APPLICATION_ID_CONFIG, "kafka-streams-app");
        props.put(BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        props.put(DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());
        props.put(DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass().getName());

        return new KafkaStreamsConfiguration(props);
    }
}
```

* StreamAggregateProcessor.java - with word count example
```
@Component
public class StreamAggregateProcessor {

    @Autowired
    void createPipeline(StreamsBuilder kafkaStreamsBuilder) {
        KStream<String, String> inputMsgStream = kafkaStreamsBuilder
          .stream("input-topic", Consumed.with(Serde<String>, Serde<String>));

        //e.g. word count
        KTable<String, Long> countWords = inputMsgStream
          .mapValues((ValueMapper<String, String>) String::toLowerCase)
          .flatMapValues(stringValue -> Arrays.asList(stringValue.split("\\W+")))
          .groupBy((key, value) -> value, Grouped.with(Serde<String>, Serde<String>))
          .count(Materialized.as("word-counts"));
    }
}
```

* GetWordsCount.java - REST endpoint
```
@GetMapping("/getcount/{forWord}")
public Long getWordCount(@PathVariable String forWord) {
    KafkaStreams kafkaStreams = factoryBean.getKafkaStreams();
    ReadOnlyKeyValueStore<String, Long> wordcounts = kafkaStreams.store(
      StoreQueryParameters.fromNameAndType("word-counts", QueryableStoreTypes.keyValueStore())
    );
    return wordcounts.get(forWord);
}
```

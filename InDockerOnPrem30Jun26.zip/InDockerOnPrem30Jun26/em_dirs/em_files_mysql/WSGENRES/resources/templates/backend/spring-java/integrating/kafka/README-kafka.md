# EasyManage Templates

## Kafka

Apache Kafka is an open-source distributed event processing and event streaming platform.

### Setup Kafka
Download and install Kafka, please refer to the guide [https://kafka.apache.org/quickstart](https://kafka.apache.org/quickstart)

### Use Spring Kafka

The Spring for Apache Kafka project facilitates development of Kafka-based messaging solutions. 

Please refer to [https://docs.spring.io/spring-kafka/reference/index.html](https://docs.spring.io/spring-kafka/reference/index.html)

## Run Kafka in Docker

Starting and Configuring the Kafka Server using Docker

### Run Kafka in Docker Containers 

> **IMP** On Win: Use CMD with Run As Administrator

`cd emapi`

Building the Kafka Containers with docker-compose
`docker-compose -f docker-compose-kafka.yml build`

Running the Kafka Containers
`docker-compose -f docker-compose-kafka.yml up -d`

Check status:
`docker-compose logs kafka | grep -i started`

`docker-compose logs zookeeper | grep -i binding`


## How to Use this template

Make note of `SOURCE` folder

`SOURCE` : `templates\backend\spring-java\integrating\kafka\emapi`

Locate generated code folder, we will refer to it as `DEST`

`DEST` : generated code `..\backend\spring-java\emapi`

### Edit pom.xml for dbrest

Locations in `DEST` :
`emapi\app\dbrest\pom.xml`

Add dependencies for Spring for Kafka:
```
		<dependency>
			<groupId>org.springframework.kafka</groupId>
			<artifactId>spring-kafka</artifactId>
		</dependency>
        <!--
		<dependency>
			<groupId>org.springframework.kafka</groupId>
			<artifactId>spring-kafka-test</artifactId>
			<scope>test</scope>
		</dependency>
        -->
```

## Add Event Producer and Event Consumer 

### Event Producer Service - Order

#### Edit `application.properties`

Locations in `DEST` :

Add to application.properties for dbrest:
`emapi\app\dbrest\src\main\resources\application.properties`

Add properties for Kafka Producer e.g. Order:
```
# -----------------------------------------------------------------
# kafka Producer
# -----------------------------------------------------------------
spring.kafka.producer.bootstrap-servers=localhost:9092
spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer
spring.kafka.producer.value-serializer=org.springframework.kafka.support.serializer.JsonSerializer
spring.kafka.topic.name=order_topic
# -----------------------------------------------------------------
```

#### Add java classes

For example for Order, lets create OrderEvent and Consume in Stock OrderStockEvent.

Locations in `DEST` :
`emapi\lib\base-app\src\main\java\com\example\emapi\app\Order`

* Order.java, 
```
public class Order {
    private String orderId;
    private String productName;
    private int qty;
    private double amuont;
}
```

```
public class OrderEvent {
    private String message;
    private String status;
    private Order newOrder;
}
```

`OrderKafkaConfig.java`
```
@Configuration
public class OrderKafkaConfig {

    @Value("${spring.kafka.topic.name}")
    private String topicName;

    @Bean
    public NewTopic topic() {
        return TopicBuilder.name(topicName).build();
    }
}
```

`ProducerOrderEvent.java`
```
@Service
public class ProducerOrderEvent {

    private static final Logger LOGGER = LoggerFactory.getLogger(ProducerOrderEvent.class);

    private NewTopic topic;

    private KafkaTemplate<String, OrderEvent> kafkaTemplate;

    public ProducerOrderEvent(NewTopic topic, KafkaTemplate<String, OrderEvent> kafkaTemplate) {
        this.topic = topic;
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage(OrderEvent event){
        LOGGER.info(String.format("Producer Order Event => %s", event.toString()));

        Message<OrderEvent> messageOE = MessageBuilder
                .withPayload(event)
                .setHeader(KafkaHeaders.TOPIC, topic.name())
                .build();
        kafkaTemplate.send(messageOE);
    }
}
```

REST API controller and endpoint to Send Order Event
`OrderEventController.java`
```
@RestController
@RequestMapping("/emdbresteventproducer/")
public class OrderEventController {

    private ProducerOrderEvent producerOrderEvent;

    public OrderController(ProducerOrderEvent producerOrderEvent) {
        this.producerOrderEvent = producerOrderEvent;
    }

    @PostMapping("/order")
    public String newOrder(@RequestBody Order order){

        order.setOrderId(UUID.randomUUID().toString());

        OrderEvent orderEvent = new OrderEvent();
        orderEvent.setStatus("CREATED");
        orderEvent.setMessage("Order is created");
        orderEvent.setOrder(order);

        producerOrderEvent.sendMessage(orderEvent);

        return "Order Created Successfully.";
    }
}
```

### Event Consumer Service - Stock

### Edit `application.properties`

Locations in `DEST` :

Add to application.properties for dbrest:
`emapi\app\dbrest\src\main\resources\application.properties`

Add properties for Kafka Consumer e.g. Stock:
```
# -----------------------------------------------------------------
# kafka Consumer
# -----------------------------------------------------------------
spring.kafka.producer.bootstrap-servers=localhost:9092
spring.kafka.consumer.group-id=stockorder
spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
spring.kafka.consumer.value-deserializer=org.springframework.kafka.support.serializer.JsonDeserializer
spring.kafka.consumer.properties.spring.json.trusted.packages=*
spring.kafka.topic.name=order_topic
# -----------------------------------------------------------------
```

#### Add java classes

Consume in Stock StockOrderEvent.

Locations in `DEST` :
`emapi\lib\base-app\src\main\java\com\example\emapi\app\Stock`

* StockOrderEventConsumer.java, 
```
@Service
public class StockOrderEventConsumer {

    @Value("${spring.kafka.topic.name}")
    private String topicName;

    @Value("${spring.kafka.consumer.group-id}")
    private String groupName;

    private static final Logger LOGGER = LoggerFactory.getLogger(StockOrderEventConsumer.class);

    @KafkaListener(
            topics = topicName,
            groupId = groupName
    )
    public void consume(OrderEvent event){
        LOGGER.info(String.format("Order Event consumed in Stock Service => %s", event.toString()));

        // reduce the stock quantity by order qty in database
    }
}```

# EasyManage Templates

## ELK (Elasticsearch, Logstash, and Kibana)

ELK Stack consists of Elasticsearch, Logstash, and Kibana

Use ELK stack along with Spring Boot Microservice for analyzing the generated logs.


## How to Use this template

Copy/Merge below mentioned `SOURCE` folder contents into `DEST` folder.

`SOURCE` : `templates\backend\spring-java\logging\elk\emapi`

`DEST` : generated code `..\backend\spring-java\emapi`

Now Follow further instructions for/with `DEST` folder.

## Build & Run ELK in Docker Containers 

`cd emapi`

Building the ELK Containers with docker-compose
`docker-compose -f docker-compose-elk.yml build`

Running ELK Containers
`docker-compose -f docker-compose-elk.yml up -d`


## Configure Spring Java Apps For Logstash 

### Edit pom.xml for dbrest & dbgraphql

Locations:
`emapi\app\dbrest\pom.xml`
`emapi\app\dbgraphql\pom.xml`

Add dependencies:
```
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter</artifactId>
			<exclusions>
				<exclusion>
					<groupId>org.springframework.boot</groupId>
					<artifactId>spring-boot-starter-logging</artifactId>
				</exclusion>
			</exclusions>
		</dependency>

		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-log4j2</artifactId>
		</dependency>

```
### Customize any Controller for using log4j.Logger

e.g. 
`emapi\app\dbrest\src\main\java\com\example\emapi\app\ErpCustomer\ErpCustomerDataRestController.java`

Step 1: Add Imports
```
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
```

Step 2: Get Logger to log
```
public class ErpCustomerDataRestController {

	private final Logger logger = LogManager.getLogger(this.getClass());
...
```

Step 3: Customize any REST endpoint method and add logging info, e.g.
```
@GetMapping("erp_customer/ViewAllPaged")  
public ResponseEntity<List<ErpCustomer>> ErpCustomerViewAllPaged(@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size)  
	List<ErpCustomer> ErpCustomerList = new ArrayList<ErpCustomer>(); 

...
	logger.info(String.format("ErpCustomer list size=[%s] firstCustomerId=[%s] firstCustomerName=[%s]", ErpCustomerList.size(), ErpCustomerList.get(0).getCustomerId(), ErpCustomerList.get(0).getName()));

```

> Customize any more Controllers for REST or GraphQL in similar fashion.

Step 4: Re-build project
maven Clean & package

Run App dbrest e.g. `emapi\app\dbrest\target\dbrest-1.0-SNAPSHOT.jar`

## Run Spring Java Apps 

Generate some Logs
* Run app dbrest, Call APIs from Swagger
e.g.
```
curl -X 'GET' \
  'http://127.0.0.1:9080/emdbrest/erp_customer/ViewAllPaged?page=0&size=4' \
  -H 'accept: application/hal+json'
```
* Run app dbgraphql, Call APIs from graphiql

## View Logs in Kibana

Access from Kibana UI: [http://localhost:5601](http://localhost:5601)

Configure index pattern: logstash-*
Visualize : Create Visualization
View

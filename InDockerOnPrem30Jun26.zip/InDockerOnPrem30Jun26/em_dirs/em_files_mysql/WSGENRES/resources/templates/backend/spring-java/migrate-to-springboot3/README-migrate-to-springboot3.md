# EasyManage Templates

## Migrating to Spring Boot 3 and Java 17 (or Java 21)

EasyManage generated Backend : Spring Java - GraphQL | REST can be migrated from default configured for Spring Boot 2.7 and Java 8 to:
* Spring Boot 3.2.3
* and Java 17 (or Java 21)

Please follow these steps and edits to migrate.

### How to Use this template

Locate generated code folder, we will refet to it as `DEST`

`DEST` : generated code `..\backend\spring-java\emapi`

### Edit `pom.xml` files

#### Edit `emapi\pom.xml` to make below changes:

1]
BEFORE:
```
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>2.7.18</version>
```
NEW:
```
		<artifactId>spring-boot-starter-parent</artifactId>
		<version>3.2.3</version>
```
2]
BEFORE:
```
	<properties>
		<java.version>1.8</java.version>
```
NEW:
```
	<properties>
		<java.version>17</java.version>
		<maven.compiler.release>17</maven.compiler.release>
```

NEW: If using Java 21
```
	<properties>
		<java.version>21</java.version>
		<maven.compiler.release>21</maven.compiler.release>
```

#### Edit `emapi\lib\base-app\pom.xml` to make below changes:

NOTE: Make below change at all places for `<classifier>`

1] Use new classifier property for artifacts `querydsl-apt` and `querydsl-jpa`
BEFORE:
```
		<dependency>
			<groupId>com.querydsl</groupId>
			<artifactId>querydsl-apt</artifactId>
			<version>${querydsl.version}</version>
			<scope>provided</scope>
			<classifier>jpa</classifier>
		</dependency>
		<dependency>
			<groupId>com.querydsl</groupId>
			<artifactId>querydsl-jpa</artifactId>
			<version>${querydsl.version}</version>
		</dependency>
```
NEW:
```
		<dependency>
			<groupId>com.querydsl</groupId>
			<artifactId>querydsl-apt</artifactId>
			<version>${querydsl.version}</version>
			<scope>provided</scope>
			<classifier>jakarta</classifier>
		</dependency>
		<dependency>
			<groupId>com.querydsl</groupId>
			<artifactId>querydsl-jpa</artifactId>
			<version>${querydsl.version}</version>
			<classifier>jakarta</classifier>
		</dependency>
```

### Edit All Java source files

NOTE: Make below change to all places in all java source code of project. Use project level search multiple files and change using "Replace All" occurances.

1]
BEFORE:
```
import javax.persistence.*; 
```
NEW:
```
import jakarta.persistence.*; 
```

### Edit `application.properties`

Finally, Configure/set `spring.datasource.*` in application.properties for dbrest and dbgraphql in similar fashion as before.

Note: Do not set below if giving error,
`spring.jpa.properties.hibernate.dialect`

### Build and test with Migrated Versions

Pre-requisites: 
Install/Setup below and keep them in path

> Note: If using Java 21, use the path for Java 21.

e.g.
Java 17 at `C:\ProgFiles\Java\jdk-17`
Maven 3.9.6 at `C:\ProgFiles\apache-maven-3.9.6`

Win `CMD` , set env:
```
set JAVA_HOME=C:\ProgFiles\Java\jdk-17
set path=%JAVA_HOME%\bin;C:\ProgFiles\apache-maven-3.9.6\bin;%path%;
```

* Verify NEW versions are in effect:

`java -version`
```
java version "17.0.10" 2024-01-16 LTS
Java(TM) SE Runtime Environment (build 17.0.10+11-LTS-240)
Java HotSpot(TM) 64-Bit Server VM (build 17.0.10+11-LTS-240, mixed mode, sharing)
```

`mvn -v`
```
Apache Maven 3.9.6 (bc0240f3c744dd6b6ec2920b3cd08dcc295161ae)
Maven home: C:\ProgFiles\apache-maven-3.9.6
Java version: 17.0.10, vendor: Oracle Corporation, runtime: C:\ProgFiles\Java\jdk-17
Default locale: en_US, platform encoding: Cp1252
OS name: "windows 11", version: "10.0", arch: "amd64", family: "windows"
```

cd to `DEST` and build test migrated project:

```
cd emapi
mvn clean package
```

> Tip: If using `CMD` and have errors, Do not keep project open in IDE (also) which has auto-build enabled. try `mvn clean` and then `mvn package` few times.

Once build successful `[INFO] BUILD SUCCESS`,

Run REST APIs
`java -jar app\dbrest\target\dbrest-1.0-SNAPSHOT.jar`

    - Check out at: http://127.0.0.1:9080/swagger-ui/index.html

Run GraphQL APIs
`java -jar app\dbgraphql\target\dbgraphql-1.0-SNAPSHOT.jar`

    - Check out at: http://127.0.0.1:9070/graphiql

# EasyManage Templates

## Security - Authentication & Authorization

Authentication & Authorization is provisioned or can be sought from thrid party authentication services. 

* Authentication & Authorization - This is covered in security-auth folder.

* RBAC Configure Role Based Access Control, with Roles to permission rules for CRUD Ops.

### Spring Security - Http Basic Auth

* With InMemoryUserDetails or DatabaseBackedUserDetails

The provisions are made in generated code itself. 

* For REST APIs, follow instructions in 
`backend\spring-java\emapi\app\dbrest\security\Readme_Security.txt`

* For GraphQL APIs, follow instructions in 
`backend\spring-java\emapi\app\dbgraphql\security\Readme_Security_Gql.txt`

### Spring Security - OAuth2

Refer to: `security-oauth2\README-security-oauth2.md`

### Spring Security - Keycloak

Refer to: `security-keycloak\README-security-keycloak.md`

### Spring Security - Social (Google, GitHub, ...)

Refer to: `security-social\README-security-social.md`

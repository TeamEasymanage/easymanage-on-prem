# EasyManage Templates

## Spring Boot Security - Keycloak

How-to: Provision Keycloak in docker side car container and Authenticate using Keycloak

### Spring Boot, Java Versions

The template is updated to work with both:
* Spring Boot 2.7 and Java 8
* Spring Boot 3.2.3 and Java 17

## Security Concepts

What is the difference between authorization server and resource server?

* An Authorization Server issues tokens to client applications on behalf of a Resource Owner for use in authenticating subsequent API calls to the Resource Server. 
* The Resource Server hosts the protected resources, and can accept or respond to protected resource requests using access tokens.

How to manage OAuth2 flow from frontend or mobile app to authorization server and resource server?

* Avoid client secret storing on frontend or mobile app side.
* Keep OAuth2 Client details confidential
* Do OAuth2 flow with a Server-Side Application.
* This pattern is BFF (Backend-For-Frontend).

> Backend for Frontend (BFF) Authentication is a security approach for securing web apps like SPAs and Blazor Apps. It uses standard OAuth flows, BFF Authentication enables backend clients to authenticate users and set up session cookies to store user's secured state.

 Flow |  |  |  |  | | |
----|------|------|---|---|---|---|
 Frontend: <br>Send username password, Get Token | ⇔ | BFF Auth APIs: <br>Have OAuth2 Client Details | ⇔ | Authorization Server | | |
 Frontend: <br>Send Token | ⇔ | Protected APIs | ⇔ | Resource Server: <br>Validate Token, Refresh if expired | ⇔ | Authorization Server |

## Keycloak

Keycloak provides Authentication and Authorization based on OAuth2 and supports SSO. Also it facilitates Identity Brokering and Social Login which can Enable login with social networks without any application code changes.

Keycloak is based on standard protocols and provides support for OAuth 2.0, OpenID Connect, and SAML. More features: User Federation (LDAP, AD).

Keycloak supports fine-grained authorization policies and is able to combine different access control mechanisms such as:
- Attribute-based access control (ABAC)
- Role-based access control (RBAC)
- User-based access control (UBAC) and more.

### Usage in Spring Boot

#### As a Resource Server

How: Set up spring boot working resource server that supports OAuth2 JWT-encoded Bearer Tokens

When using Spring Boot, configuring an application as a resource server consists of two basic steps. First, include the needed dependencies and second, indicate the location of the authorization server.

To invoke the protected endpoints using a bearer token, your client needs to obtain an OAuth2 access token from a Keycloak server

#### As OAuth2 Client to interact with the Keycloak Server

Spring Boot and Spring Security can connect to Keycloak using its OAuth2 client library `spring-boot-starter-oauth2-client`

## Run Keycloak in Docker

Follow steps below to Starting and Configuring the Keycloak Server using Docker.
And also Loading initial realm in keycloak server with docker.

Use sample `emapi` realm import config json file from templates.
* Locate `realm-import.json` in downloaded code folder resources templates: e.g.
`WS_9999\resources\templates\backend\spring-java\security-auth\security-keycloak\config`
* Find the real full path for above folder (not relative path): e.g.
"C:\Users\User01\Downloads\EmGenDir_MYTEMP01_WS_51033\WS_51033\resources\templates\backend\spring-java\security-auth\security-keycloak\config\realm-import.json"
* In `docker run` command below, USE the real full path with double quotes, in place of "full_path_import_file"

* **Note**: 
	- Edit passwords in `realm-import.json`, if needed different.
	- If pairing with graphql project, edit redirectUris port.


```
docker pull  quay.io/keycloak/keycloak:24.0

docker run -p 8180:8180 --name keycloak -e KEYCLOAK_ADMIN=admin -e KEYCLOAK_ADMIN_PASSWORD=admin  -v "full_path_import_file":/opt/keycloak/data/import/realm-import.json quay.io/keycloak/keycloak:24.0 start-dev --import-realm --http-port=8180
```

- Access Keycloak Server at http://127.0.0.1:8180
- Log in as the admin user with password admin.
- Verify realm `emapi` created with Roles and Users and client.

- Navigate to Clients : `login-app` and verify details.

- The client_secret value for use in get token via curl command is secret value specified in `realm-import.json`: `CpHGX36kE`

* NOTE: Below is taken care in import json now, just for reference below:
	--------------------------------------------------
	- Fully set-up users:
	- Navigate to users emUser, emAdmin and in Details setup below values:
		- Set Email, First name, Last name.
		- If required set "Email Verified" toggle to Yes.
	--------------------------------------------------

* Get token to test API security

Note: Token expires in 60 sec by default

* For emUser, get token
```
curl -d "client_id=login-app&client_secret=CpHGX36kE&username=emUser&password=emUser123&grant_type=password" http://127.0.0.1:8180/realms/emapi/protocol/openid-connect/token
```

* For emAdmin, get token
```
curl -d "client_id=login-app&client_secret=CpHGX36kE&username=emAdmin&password=emAdmin123&grant_type=password" http://127.0.0.1:8180/realms/emapi/protocol/openid-connect/token
```

## Usage in Spring Boot - As a Resource Server

Please follow below steps.

## How to Use this template

Make note of `SOURCE` folder

`SOURCE` : `templates\backend\spring-java\security-auth\security-keycloak\emapi`

Locate generated code folder, we will refer to it as `DEST`

`DEST` : generated code `..\backend\spring-java\emapi`

### Edit pom.xml for dbrest & dbgraphql

Locations in `DEST` :
`emapi\app\dbrest\pom.xml`
`emapi\app\dbgraphql\pom.xml`

Add dependencies:
```
		<!-- spring security -->
	  <dependency>
		  <groupId>org.springframework.boot</groupId>
		  <artifactId>spring-boot-starter-security</artifactId>
	  </dependency>
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-oauth2-resource-server</artifactId>
		</dependency>
```

### Edit `application.properties`

Locations in `DEST` :

Add to application.properties for dbrest and dbgraphql:
`emapi\app\dbrest\src\main\resources\application.properties`
`emapi\app\dbgraphql\src\main\resources\application.properties`


Add properties:

```
# -----------------------------------------------------------------
# OAuth2 , Keycloak : Resource Server
# -----------------------------------------------------------------
# For validating JWT
spring.security.oauth2.resourceserver.jwt.issuer-uri=http://127.0.0.1:8180/realms/emapi
# -----------------------------------------------------------------
# security logging
logging.level.org.springframework.security=DEBUG
#logging.level.org.springframework.security=INFO
# -----------------------------------------------------------------
```

### Copy SpringSecurityConfigOAuth2 for dbrest & dbgraphql

Copy/Merge below mentioned `SOURCE` folder/files contents into `DEST` folder.

copy `SOURCE\emapi\app\dbrest\src\security\SpringSecurityConfigOAuth2.java` 
to `DEST\emapi\app\dbrest\src\security\SpringSecurityConfigOAuth2.java`

copy `SOURCE\emapi\app\dbgraphql\src\security\SpringSecurityGqlConfigOAuth2.java`
to `DEST\emapi\app\dbgraphql\src\security\SpringSecurityGqlConfigOAuth2.java`

### Build and Run project

cd to `DEST` and build test migrated project:

```
cd emapi
mvn clean package
```
Once build successful `[INFO] BUILD SUCCESS`,

#### Verify Security.

Run REST APIs
`java -jar app\dbrest\target\dbrest-1.0-SNAPSHOT.jar`

* Check out sample API: 

Without token, should give error:
```
curl "http://127.0.0.1:9080/emdbrest/erp_customer/ViewAll"

curl "http://127.0.0.1:9080/emdbrest/erp_customer/ViewAllPaged?page=0&size=2"
```

Note: Token expires in 60 sec by default

With Bearer token:
```
curl -H "Accept: application/json" -H "Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJZUzdLSzByc19hcEU0NDJBMWUxczhoQzlHeEJQd095cVpyaFVTYzlydGhVIn0.eyJleHAiOjE3MTExODczNTUsImlhdCI6MTcxMTE4NzA1NSwianRpIjoiYjczZGE0ZjQtY2M2My00M2ZkLWI1ZmUtZTYzMGRlZDM4NzhhIiwiaXNzIjoiaHR0cDovLzEyNy4wLjAuMTo4MTgwL3JlYWxtcy9lbWFwaSIsInN1YiI6IjQ5ZmUwOTJkLWYzZWUtNDY4OC05NGE0LTlkNjU1ZDU0NjQ4ZCIsInR5cCI6IkJlYXJlciIsImF6cCI6ImxvZ2luLWFwcCIsInNlc3Npb25fc3RhdGUiOiI5Nzg5ZjEyYi0xZmFlLTQxZDctYTM2ZS01MTYxN2EyMDMwMWEiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbImh0dHA6Ly8xMjcuMC4wLjE6OTA4MCJdLCJyZWFsbV9hY2Nlc3MiOnsicm9sZXMiOlsiVVNFUiJdfSwic2NvcGUiOiJwcm9maWxlIGVtYWlsIiwic2lkIjoiOTc4OWYxMmItMWZhZS00MWQ3LWEzNmUtNTE2MTdhMjAzMDFhIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsIm5hbWUiOiJlbVVzZXIgZW1Vc2VyIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiZW11c2VyIiwiZ2l2ZW5fbmFtZSI6ImVtVXNlciIsImZhbWlseV9uYW1lIjoiZW1Vc2VyIiwiZW1haWwiOiJzX3N1ZGhpcjA1QHlhaG9vLmNvLmluIn0.uD8vV-qNSvvlKqYLVQQdhn1lH-mN26jTrSIbsqOMThkGrW9JIaozfNcHTViTj5A6rVPJy4EGU0Af6qf0u0t6hwMwlMsk6l1HSiw26KHGSoP7VhqLtvwyYneF2zakZgFpIFviYivTsTZWKtlZyVNUpdEa_IdpHCjQ0pSY1nMfeeaVtlulau7ap-W-p6ZQq2hKapJ9A74CiLPY-6zYfOzB51yxEVtcXgoK6PXpdxOlHR-o6nL4vFUCc3rRzzbcWm6djF8M_fuYfxvfFjvPokcEmAWpT-qFO-PuY6rt3zjRO83f9IonLdcciAsOcottY19lzVV7VCJ7N3WGQYiiMevEZQ" "http://127.0.0.1:9080/emdbrest/erp_customer/ViewAllPaged?page=0&size=2" 
```

Run GraphQL APIs
`java -jar app\dbgraphql\target\dbgraphql-1.0-SNAPSHOT.jar`

    - Check out at: http://127.0.0.1:9070/graphiql


## Usage in Spring Boot - As OAuth2 Client to interact with the Keycloak Server

Please follow below additional changes to steps of Usage As a Resource Server

### Edit pom.xml for dbrest & dbgraphql

Locations in `DEST` :
`emapi\app\dbrest\pom.xml`
`emapi\app\dbgraphql\pom.xml`

Add dependencies:
```
		<dependency>
			<groupId>org.springframework.boot</groupId>
			<artifactId>spring-boot-starter-oauth2-client</artifactId>
		</dependency>
```

### Edit `application.properties`

Locations in `DEST` :

Add to application.properties for dbrest and dbgraphql:
`emapi\app\dbrest\src\main\resources\application.properties`
`emapi\app\dbgraphql\src\main\resources\application.properties`


Add properties:

```
# -----------------------------------------------------------------
# OAuth2 , Keycloak : OAuth2 Client
# -----------------------------------------------------------------
# OAuth2 client configuration for Keycloak
spring.security.oauth2.client.registration.keycloak.client-id=login-app
spring.security.oauth2.client.registration.keycloak.client-secret=CpHGX36kE
spring.security.oauth2.client.registration.keycloak.authorization-grant-type=authorization_code
spring.security.oauth2.client.registration.keycloak.scope=openid

# OAuth 2.0 Provider (OIDC provider) Configuration
spring.security.oauth2.client.provider.keycloak.issuer-uri=http://127.0.0.1:8180/realms/emapi
spring.security.oauth2.client.provider.keycloak.user-name-attribute=preferred_username
# -----------------------------------------------------------------
```

### Edit SpringSecurityConfigOAuth2 for dbrest & dbgraphql

`DEST\emapi\app\dbrest\src\security\SpringSecurityConfigOAuth2.java`
`DEST\emapi\app\dbgraphql\src\security\SpringSecurityGqlConfigOAuth2.java`

* Edit and uncomment below code:
```
			/* 
            //login-logout handler
            http.oauth2Login(Customizer.withDefaults())
                .logout(logout -> logout.logoutSuccessUrl("/"));
			*/
```

* Customize/Add logic for below:
- Parse tokens: Check if the token is OidcUserAuthority or OAuth2UserAuthority.
- By default, it is OidcUserAuthority. If so, It can contain the roles under realm access or Groups. So check both and extract the roles.
- If it is OAuth2UserAuthority extract the roles.
- Handling logout from Keycloak.

### Build and Run project

> Tip: First time, chrome browser - do clearing of Application Cookies, Local Storage, Session Storage.

Login to Spring App
http://127.0.0.1:9080/login
http://127.0.0.1:8180/realms/emapi/account

Login re-direct will happen to Keycloak login screen. Once authenticated, load swagger page and run APIs. Spring App will store authentication for session.

http://127.0.0.1:9080/swagger-ui/index.html


* Checkout BFF Auth API (get Token) from generated code:
```
curl --header "Content-Type: application/json" -d "{\"username\":\"emUser123\",\"password\":\"emUser123\"}" http://127.0.0.1:9080/emlogin/oauth2/getToken
```

## Reference Docs

Please follow Documentations at :
* Keycloak Doc [Securing Applications and Services Guide](https://www.keycloak.org/docs/latest/securing_apps/)
* Keycloak Doc [Spring Boot REST Service Protected Using Keycloak Authorization Services](https://github.com/keycloak/keycloak-quickstarts/tree/latest/spring/rest-authz-resource-server)
    - This quickstart demonstrates how to protect a Spring Boot 3.0 REST service using Keycloak Authorization Services.
* Spring Doc [OAuth 2.0 Resource Server JWT](https://docs.spring.io/spring-security/reference/servlet/oauth2/resource-server/jwt.html)

/* ---------------------------------------------
	To enable Spring Security - OAuth2
   ---------------------------------------------
*/

package com.example.emapi.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
@EnableMethodSecurity
public class SpringSecurityConfigOAuth2 {


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

        http
                .csrf().disable()
                .cors().disable()
                .authorizeRequests()
                // Based on URL pattern
                .requestMatchers(new AntPathRequestMatcher("/**/ViewAll")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/ViewAllPaged")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/SelectWhere")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/Query")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/FindOne")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/GetOne")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/FindByColumnName")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/ConsumerService")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/DataMesh")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/Create")).hasRole("USER")
                .requestMatchers(new AntPathRequestMatcher("/**/Update")).hasAnyRole("USER", "ADMIN")
                .requestMatchers(new AntPathRequestMatcher("/**/Delete")).hasRole("ADMIN")
                .requestMatchers(new AntPathRequestMatcher("/login-app/**"))
                .permitAll()
                .anyRequest()
                .authenticated();

            http.oauth2ResourceServer(oauth2 -> oauth2
                        .jwt()
                        .jwtAuthenticationConverter(grantedAuthoritiesExtractor()))
                //.cors(Customizer.withDefaults())
                ;
            //As OAuth2 Client
			/* 
            //login-logout handler
            http.oauth2Login(Customizer.withDefaults())
                .logout(logout -> logout.logoutSuccessUrl("/"));
			*/

        return http.build();
    }

    private Converter<Jwt, AbstractAuthenticationToken> grantedAuthoritiesExtractor() {
        JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
        jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(new GrantedAuthoritiesExtractor());
        return jwtAuthenticationConverter;
    }

    static class GrantedAuthoritiesExtractor implements Converter<Jwt, Collection<GrantedAuthority>> {
        public Collection<GrantedAuthority> convert(Jwt jwt) {
            return (
                    (Map<String, Collection<?>>) jwt.getClaims().getOrDefault("realm_access", Collections.emptyMap())
            ).getOrDefault("roles", Collections.emptyList())
                    .stream()
                    .map(role -> new SimpleGrantedAuthority("ROLE_" + role))
                    .collect(Collectors.toList());
        }
    }
}

# EasyManage Templates

## Spring Security - OAuth2

How-to: Authenticate using OAuth2

> Please refer to [Security - Keycloak](..\security-keycloak\README-security-keycloak.md) for complete example of implementing Spring Security - OAuth2, with reference Authorization Server from Keycloak.

### Reference 

Please follow Spring Documentation at :
[https://spring.io/guides/tutorials/spring-boot-oauth2](https://spring.io/guides/tutorials/spring-boot-oauth2)

Also refer to,
[https://docs.spring.io/spring-security/reference/servlet/oauth2/index.html](https://docs.spring.io/spring-security/reference/servlet/oauth2/index.html)

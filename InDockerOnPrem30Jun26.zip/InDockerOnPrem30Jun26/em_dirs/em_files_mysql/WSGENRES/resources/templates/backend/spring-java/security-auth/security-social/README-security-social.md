# EasyManage Templates

### Spring Security - Social (Google, GitHub, etc.)

How-to: Authenticate using Social Login

Please follow Spring Documentation at :
[https://docs.spring.io/spring-authorization-server/reference/guides/how-to-social-login.html](https://docs.spring.io/spring-authorization-server/reference/guides/how-to-social-login.html)

*"This guide shows how to configure Spring Authorization Server with a social login provider (such as Google, GitHub, etc.) for authentication. The purpose of this guide is to demonstrate how to replace Form Login with OAuth 2.0 Login."*

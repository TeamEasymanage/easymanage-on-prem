# EasyManage Templates

## Testing: BDD (Behavior-Driven Development)

BDD emphasizes the behavior of an application for business requirements. It was originated to address issues arising from ill-defined requirement specifications.

It uses tests written in plain English, which all can easily understand and agree on expected behavior. Often orginated/drafted by business analysts or product management teams. BDD brings together the Business side, Development, and QA teams.  Tests passing ensures right product is developed.

Stack: Cucumber can be used to write and execute automated acceptance tests. Tests are written in Gherkin (a natural language syntax) and organized as per features hierarchy.

### API Automation Testing

#### Serenity BDD, Cucumber

Use Serenity BDD with Cucumber to run API automation test using RestAssured.

Serenity creats interactive, thorough reports.

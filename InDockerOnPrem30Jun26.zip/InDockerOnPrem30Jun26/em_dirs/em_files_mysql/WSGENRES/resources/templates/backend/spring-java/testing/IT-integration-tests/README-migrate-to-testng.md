# EasyManage Templates

## IT Integration Tests - Migrating to TestNG

EasyManage generated IT Integration Tests can be migrated from default JUnit to TestNG.

Please follow these steps and edits to migrate.

### How to Use this template

Locate generated code folder, we will refet to it as `DEST`

`DEST` : generated code `..\backend\spring-java\emapi`

(Page under construction)

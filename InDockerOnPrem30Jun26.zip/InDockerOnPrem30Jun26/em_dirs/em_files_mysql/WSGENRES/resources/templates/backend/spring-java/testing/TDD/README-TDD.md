# EasyManage Templates

## Testing: TDD (Test Driven Development)

Test Driven Development (TDD) refers to software development practice, which follows creating unit test cases before developing the actual software code. It is an agile development methodology. It is an iterative approach combining unit test creation and coding.

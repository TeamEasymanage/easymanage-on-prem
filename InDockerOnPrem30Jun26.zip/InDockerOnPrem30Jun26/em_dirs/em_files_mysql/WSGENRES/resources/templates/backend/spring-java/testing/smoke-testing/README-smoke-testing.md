# EasyManage Templates

## Testing: Smoke Testing

Smoke Testing ensures whether the new build is healthy or not. Is is a Confidence Testing or Build Verification Testing. It ensures that the software release is testable and it will not block QA teams.

Develop automation tests to ensure that the critical functionalities of the product are working fine.

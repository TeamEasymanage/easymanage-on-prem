# EasyManage Tutorials

## Full-Stack Tutorials

## Tutorial 1: Build Your First App

Start building with these sample table SQLs.

* Sample Tables SQL [For MySQL](./full-stack/tutorial-1/sql/mysql/em_demo_app_tables.sql)
* Sample Tables SQL [For PostgreSQL](./full-stack/tutorial-1/sql/psql/em_demo_app_tables.sql)

Create tables in your cloud database or use a FREE cloud database, refer to doc page [Using Free PostgreSQL database solutions](https://easymanage.com/res/blog/using-free-postgresql-db/)

* Follow EasyManage docs: [Build Your First App](https://easymanage.com/res/docs/start-building)
  - Import tables in Builder Studio and follow further steps.


## Backend Tutorials

Undertake tutorials with tech stack Spring-Java backend.

## Tutorial 1 : Create Micorservice

> Note: Create `emapi` project for order table

* Create e-Commerce Order Microservice

* MySQL table:

```
CREATE TABLE order (
  order_id int(11) NOT NULL AUTO_INCREMENT,
  customer_id int(11) NOT NULL,
  product_id int(11) NOT NULL,
  order_date DATE NULL,
  order_quantity int(11) DEFAULT 0,
  order_status varchar(50) NULL,
  PRIMARY KEY (order_id)
);
```

* Customize `order` model with below:
  - Auto-generate orderId (order_id column)
    - Use @GeneratedValue annotation to automatically generate the primary key value for @Id.
  - Add validation for orderQuantity (order_quantity column) as below:
    - Must have value (not null) and value must be positive non-zero.
    - Min quantity: 1, Max Quantity: 5
    - Use annotations `@NotNull`, `@Positive`, `@Min(1)`, `@Max(5)`

## Tutorial 2 : Implement Micorservice Communication and Events

> Note: Create separate/new `emapi` project for shipping tables and use new ports for APIs e.g. 9060/9050

* Create e-Commerce Shipping Microservice

* MySQL tables:

```
CREATE TABLE product_inventory (
  product_id int(11) NOT NULL,
  available_quantity int(11) DEFAULT 0,
  PRIMARY KEY (product_id)
);

INSERT INTO product_inventory (product_id ,available_quantity)
VALUES (1,50),(2,30),(3,40);

CREATE TABLE shipping (
  shipping_id int(11) NOT NULL AUTO_INCREMENT,
  order_id int(11) NOT NULL AUTO_INCREMENT,
  product_id int(11) NOT NULL,
  shipping_quantity int(11) DEFAULT 0,
  shipping_status varchar(50) NULL,
  PRIMARY KEY (shipping_id)
);
```

* Then Order Microservice will communicate with Shipping Microservice for checking available product quantities before creating order.

Implement Event Distribution With kafka:
* Then Order Microservice will produce event `order_created` and Shipping Microservice will comsume this event and create a sihpping record.


## Tutorial 3 : Implement Enterprise Requirements for APIs and Microservices

Select Project configurations for below in Builder Studio and Implement/Verify them in generated `emapi` project:

* Code Coverage - SonarQube
* Security - OAuth2 with Keycloak
* Redis cache
* Logging - ELK stack
* Distributed Events Aggregation with Kafka Streams
* DevOps CI/CD pipelines for build, verify, deploy.

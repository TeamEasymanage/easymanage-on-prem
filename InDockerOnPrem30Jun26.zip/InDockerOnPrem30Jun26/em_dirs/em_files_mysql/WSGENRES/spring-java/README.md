# EasyManage

## Backend : Spring Java - GraphQL | REST

EasyManage Backend for GraphQL | REST APIs in Spring Java. 

* Implemented in Springboot
	* GraphQL
	  - Spring GraphQL
	* REST
	  - Spring Data REST

* Databases
	- Databases supported for runtime are : PostgreSQL, MySQL, MariaDB, Oracle, MS SQL Server, Azure SQL, Snowflake

* Documentation
	- https://easymanage.com/res/docs/category/backend-spring-java
	
### Installation

* Locate your project
    - ```<PROJECTDIR>``` is referenced as project folder, locate dir ```backend\spring-java\emapi```

* Import Maven Project using IntelliJ IDEA 

pom.xml file:
```
<PROJECTDIR>/pom.xml
```

### Build and Run

To compile project and run, use maven.

* Configure, Setup, Run

* Edit properties file:
Open application.properties, Uncomment/specify spring.datasource.* properties for your target database.

REST 
```
<PROJECTDIR>/app/dbrest/src/main/resources/application.properties
```

GraphQL
```
<PROJECTDIR>/app/dbgraphql/src/main/resources/application.properties
```

* Build: Via Run maven package on root project

* Run Application Jar Built in given dir

REST 
```
<PROJECTDIR>/app/dbrest/target
```

GraphQL
```
<PROJECTDIR>/app/dbgraphql/target
```

### Build Deploy `emapi` with Docker

Please refer to Documentation page:
[Build Deploy with Docker](https://easymanage.com/res/docs/backend/reference/developer-resources#build-deploy-with-docker)


## Project Configuration Variations & Templates

### Backend Spring Java Project Configuration 

> Tip: When Used Builder Studio Backend Spring Java Project Configuration, the generated project is as per selected configuration.

To know more about How to setup required apps and tools for selected configurations, See relevant README at folder [EasyManage: Templates Backend Spring Java README](../../resources/templates/backend/spring-java/README.md)

### Extend with EasyManage Templates

> Tip: Extend generated code with EasyManage templates. Template projects contain sample apps, examples, customizations and enhancements to use with EasyManage generated code. See [EasyManage: Templates Backend Spring Java README](../../resources/templates/backend/spring-java/README.md)


### Some Tools Information

Included below is Some key required Tools Information, But for all Tools please refer to EasyManage Templates README given before.

#### How to Use Redis Cache

Please refer to Documentation page:
[How to Use Redis Cache](https://easymanage.com/res/docs/backend/reference/api-how-tos#how-to-use-redis-cache)


#### Code Coverage Analysis

Do static source code analysis and ensure code quality with SonarQube. 

Please refer to Documentation page:
[Code Coverage Analysis](https://easymanage.com/res/docs/backend/reference/developer-resources#code-coverage-analysis)


## Tutorials

* A set of tutorials to help you learn, get started and practice building with EasyManage.

* EasyManage: Tutorials : 
	- See [Tutorials README](../../resources/tutorials/README-tutorials.md)


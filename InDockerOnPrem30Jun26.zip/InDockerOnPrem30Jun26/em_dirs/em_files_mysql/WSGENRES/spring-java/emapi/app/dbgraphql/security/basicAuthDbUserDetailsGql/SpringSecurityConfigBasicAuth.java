
/* ---------------------------------------------
	To enable Spring Security For GraphQL - Http Basic Auth
	Refer to
	../Readme_Security_Gql.txt
   ---------------------------------------------
*/


package com.example.emapi.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.DefaultSecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SpringSecurityConfigBasicAuth {

	@Bean
	DefaultSecurityFilterChain springWebFilterChain(HttpSecurity http) throws Exception {
		return http
				.csrf().disable()
				//below 4 lines are for using Sign-Up Sign-In from frontend i.e. [isAppFESecure = true]
				.authorizeRequests()
				.antMatchers("/emdbrest/app_users_view/Create").permitAll() //Sign-Up
				.antMatchers("/emdbrest/app_users_view/SelectWhere").permitAll() //Sign-In
				.and()
				//use below if required only
				//.antMatchers("/**/checkLogin").permitAll()
				//.and().formLogin().loginPage("/login").permitAll()
				//.and().logout().invalidateHttpSession(true).clearAuthentication(true).permitAll()
				//.and()
				.authorizeRequests().anyRequest().authenticated()
				.and()
				.httpBasic(withDefaults())
				.build();

	}

	/*
		MyUserDetailsService:
		Custom UserDetailsService (database backed) is enabled 
		Since class is configured with the @Service annotation, 
		the application will automatically detect it during component-scan, 
		and it will create a bean out of this class.
	*/

	/* Below bCryptPasswordEncoder() bean is needed, else will get error at runtime
	 */
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

}


package com.example.emapi.app; 
 
import javax.persistence.*; 
import java.util.*; 
import com.fasterxml.jackson.annotation.JsonFormat; 
 
@Entity 
@Table(name = "app_users_view") 
public class AppusersviewTblRec { 
 
	@Id 
	//@GeneratedValue(strategy = GenerationType.AUTO) // or GenerationType.IDENTITY | GenerationType.SEQUENCE | GenerationType.UUID (With UUID java type, char (36) ) 
	@Column(name = "username") 
	private String username; 
 
	@Column(name = "password") 
	private String password; 
 
	@Column(name = "email") 
	private String email; 
 
	@Column(name = "roles") 
	private String roles; 
 
 
public AppusersviewTblRec() { 
 
} 
 
public AppusersviewTblRec(  
  String username 
 , String password 
 , String email 
 , String roles 
 ) { 
	this.username = username; 
	this.password = password; 
	this.email = email; 
	this.roles = roles; 
} 
 
public String getUsername() { return this.username; } 
public String getPassword() { return this.password; } 
public String getEmail() { return this.email; } 
public String getRoles() { return this.roles; } 
 
public void setUsername(String username ) { this.username = username; } 
public void setPassword(String password ) { this.password = password; } 
public void setEmail(String email ) { this.email = email; } 
public void setRoles(String roles ) { this.roles = roles; } 
 
 
@Override 
public String toString() { 
	return "AppusersviewTblRec [ username = "+this.username+" ]"; 
} 
 
} 
 

package com.example.emapi.app; 
 
import java.util.*; 
 
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.http.HttpStatus; 
import org.springframework.http.ResponseEntity; 
import org.springframework.web.bind.annotation.CrossOrigin; 
import org.springframework.web.bind.annotation.DeleteMapping; 
import org.springframework.web.bind.annotation.GetMapping; 
import org.springframework.web.bind.annotation.PathVariable; 
import org.springframework.web.bind.annotation.PostMapping; 
import org.springframework.web.bind.annotation.PutMapping; 
import org.springframework.web.bind.annotation.RequestBody; 
import org.springframework.web.bind.annotation.RequestMapping; 
import org.springframework.web.bind.annotation.RequestParam; 
import org.springframework.web.bind.annotation.RestController; 
import org.springframework.transaction.annotation.Transactional; 
import org.springframework.format.annotation.DateTimeFormat; 
 
//Data Mesh API 
/*  
import org.springframework.web.reactive.function.client.WebClient; 
import org.springframework.http.HttpHeaders; 
import org.springframework.http.MediaType; 
import reactor.core.publisher.Mono; 
import org.springframework.core.ParameterizedTypeReference; 
*/  
 
//Pagination and Sorting 
import org.springframework.data.domain.Page; 
import org.springframework.data.domain.PageRequest; 
import org.springframework.data.domain.Pageable; 
import org.springframework.data.domain.Sort; 
 
import com.querydsl.core.types.dsl.BooleanExpression; 
 
import com.example.emapi.AppusersviewTblRec; 
import com.example.emapi.AppusersviewTblRecRepository; 
 
@CrossOrigin  
@RestController 
@RequestMapping("/emdbrest")  
public class AppusersviewTblRecDataRestController { 
 
	@Autowired 
	AppusersviewTblRecRepository AppusersviewTblRec1Repository;


// -------------------- SelectWhere ------------------------- 
 
@GetMapping("app_users_view/SelectWhere")  
public ResponseEntity<List<AppusersviewTblRec>> AppusersviewTblRecSelectWhere(@RequestParam String searchBy, @RequestParam(defaultValue = "") String sortBy, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) 
		throws Exception 
	{ 
	List<AppusersviewTblRec> AppusersviewTblRecList = new ArrayList<AppusersviewTblRec>(); 
	try { 
 
		System.out.println("search param = "+searchBy); 
		System.out.println("sort by = "+sortBy); 
 
		Pageable myPageParam; 
 
		if (page >= 0) { 
			myPageParam = PageRequest.of(page, size); 
			Sort mySort; 
			if (sortBy != null) { 
				if (sortBy.trim().length() > 0) { 
					EmSortBuilder sortBuild = new EmSortBuilder(sortBy); 
					if (sortBuild.gotSort) { 
						mySort = sortBuild.mySort; 
						myPageParam = PageRequest.of(page, size, mySort); 
					} 
				} 
			} 
			//myPageParam = PageRequest.of(page, size, Sort.by("columnOne").descending().and(Sort.by("columnTwo"))); 
			//Pls note: If using Sort, All the data is sorted first (matching Filter) and then page+size picked up 
		} else { // -1 fetchAll 
			myPageParam = Pageable.unpaged(); //Sort not possible then, use hack below if needed 
			//myPageParam = PageRequest.of(0, 999999999, Sort.by("columnOne").descending().and(Sort.by("columnTwo"))); 
		} 
 
		AppusersviewTblRecPredicatesBuilder builder = new AppusersviewTblRecPredicatesBuilder(searchBy); 
		BooleanExpression queryExpr = builder.build(); 
 
		AppusersviewTblRec1Repository.findAll(queryExpr, myPageParam).forEach(AppusersviewTblRecList::add); 
 
		//AppusersviewTblRec1Repository.findByColumnName(columnVal).forEach(AppusersviewTblRecList::add); 
 
		// if (AppusersviewTblRecList.isEmpty()) { 
		// } 
 
	if (AppusersviewTblRecList.isEmpty()) { 
		return new ResponseEntity<>(HttpStatus.NO_CONTENT); 
	} 
 
	return new ResponseEntity<>(AppusersviewTblRecList, HttpStatus.OK); 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
// -------------------- Create -------------------------
 
@PostMapping("app_users_view/Create")  
@Transactional 
public ResponseEntity<AppusersviewTblRec> AppusersviewTblRecCreate(@RequestBody AppusersviewTblRec AppusersviewTblRec1)  
	throws Exception 
	{   
	try {

		//Check User exists, then SAVE
		List<AppusersviewTblRec> AppusersviewTblRecList = new ArrayList<AppusersviewTblRec>();

		AppusersviewTblRec1Repository.findByUsername(AppusersviewTblRec1.getUsername()).forEach(AppusersviewTblRecList::add);

		if (AppusersviewTblRecList.isEmpty()) {
			AppusersviewTblRec _AppusersviewTblRec = AppusersviewTblRec1Repository
					.save(AppusersviewTblRec1);
			return new ResponseEntity<>(_AppusersviewTblRec, HttpStatus.CREATED);
		} else {
			System.out.println("Error: Username exists, Create User Failed.");
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}

			//If using @GeneratedValue for key, e.g. GenerationType.IDENTITY mysql auto_increment on table column, To get back Db Generated Id value, Use Below
			//.savesaveAndFlush(AppusersviewTblRec1);


	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 

/*
// -------------------- Update ------------------------- 
 
@PutMapping("app_users_view/Update")  
@Transactional 
public ResponseEntity<AppusersviewTblRec> AppusersviewTblRecUpdate(@RequestParam String username, @RequestBody AppusersviewTblRec AppusersviewTblRec1)  
	throws Exception 
	{   
	try { 
 
		List<AppusersviewTblRec> AppusersviewTblRecRec1 = AppusersviewTblRec1Repository.findByUsername(username); 
 
		if (AppusersviewTblRecRec1.isEmpty()) {  
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);  
		}  
 
		AppusersviewTblRec AppusersviewTblRecRec1First = AppusersviewTblRecRec1.get(0); 
		AppusersviewTblRec _AppusersviewTblRec = AppusersviewTblRec1Repository  
						.save(AppusersviewTblRec1);  
		return new ResponseEntity<>(_AppusersviewTblRec, HttpStatus.OK);  
 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
 
// -------------------- Delete ------------------------- 
 
@DeleteMapping("app_users_view/Delete")  
@Transactional 
public ResponseEntity<Long> AppusersviewTblRecDelete(@RequestParam String username)  
	throws Exception 
	{   
	try { 
 
	Long delCount = AppusersviewTblRec1Repository 
			.deleteByUsername(username); 
			//.deleteAll(); 
	return new ResponseEntity<>(delCount, HttpStatus.OK); 
 
	} catch (Exception e) { 
		System.out.println("Error: Exception:  "+e.getMessage()); 
		//e.printStackTrace(System.out); 
		return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR); 
	} 
} 
*/

} 
 

package com.example.emapi.app; 
 
import com.querydsl.core.types.dsl.*; 
 
import com.example.emapi.EmSearchCriteria;  
import com.example.emapi.AppusersviewTblRec;  
 
 
public final class AppusersviewTblRecPredicate { 
 
    private EmSearchCriteria criteria; 
 
    public EmSearchCriteria getCriteria() { 
        return criteria; 
    } 
    public void setCriteria(final EmSearchCriteria criteria) { 
        this.criteria = criteria; 
    } 
 
    public AppusersviewTblRecPredicate(final EmSearchCriteria criteria) { 
        this.criteria = criteria; 
    } 
 
    public BooleanExpression getPredicate() { 
 
        //Using Q classes is easier than PathBuilder 
        //final PathBuilder<AppusersviewTblRec> entityPath = new PathBuilder<>(AppusersviewTblRec.class, "appusersviewTblRec"); 
 
        //key, value, operation 
        String colKey = criteria.getKey(); 
        String colOp = criteria.getOperation(); 
        Object colVal = criteria.getValue(); 
 
        //Q classes are generated at compile time by apt pom -> <classifier>jpa</classifier> 
        QAppusersviewTblRec appusersviewTblRec = QAppusersviewTblRec.appusersviewTblRec; 
        EmPredicatesHelper pHelper = new EmPredicatesHelper(); 
 
        switch (colKey) { 
            case "username" : 
            //process String 
            StringPath usernamePath = appusersviewTblRec.username; 
            return pHelper.emGetStringPathExpr(usernamePath, colOp, colVal); 
            case "password" : 
            //process String 
            StringPath passwordPath = appusersviewTblRec.password; 
            return pHelper.emGetStringPathExpr(passwordPath, colOp, colVal); 
            case "email" : 
            //process String 
            StringPath emailPath = appusersviewTblRec.email; 
            return pHelper.emGetStringPathExpr(emailPath, colOp, colVal); 
            case "roles" : 
            //process String 
            StringPath rolesPath = appusersviewTblRec.roles; 
            return pHelper.emGetStringPathExpr(rolesPath, colOp, colVal); 
        } 
 
        return null; 
    } 
 
} 
 

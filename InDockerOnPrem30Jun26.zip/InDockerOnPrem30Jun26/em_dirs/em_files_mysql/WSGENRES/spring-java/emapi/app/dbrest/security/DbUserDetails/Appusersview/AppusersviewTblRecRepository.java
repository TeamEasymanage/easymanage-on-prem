package com.example.emapi.app; 
 
import java.util.*; 
import org.springframework.data.jpa.repository.JpaRepository; 
import org.springframework.data.domain.Pageable; 
 import org.springframework.data.querydsl.QuerydslPredicateExecutor;  
import com.example.emapi.AppusersviewTblRec; 
 
public interface AppusersviewTblRecRepository extends JpaRepository<AppusersviewTblRec, String>  , QuerydslPredicateExecutor<AppusersviewTblRec>  { 
	//Below 2 are inbuilt available from Repository, not needed to declare  
	//List<AppusersviewTblRec> findAll(); 
	//List<AppusersviewTblRec> findAll(Pageable pageable); 
 
	List<AppusersviewTblRec> findByUsername(String username); 
	//List<AppusersviewTblRec> findByUsername(String username, Pageable pageable); 
	//List<AppusersviewTblRec> findByUsernameLike(String username); 
	//List<AppusersviewTblRec> findByUsernameContaining(String username); 
	//List<AppusersviewTblRec> findByUsernameAndUsername(String username, String username); 
	Long deleteByUsername(String username); 
	//List<AppusersviewTblRec> findByColumnName(String columnName); 
	//List<AppusersviewTblRec> findByColumnName(String columnName, Pageable pageable); 
 
 
	/* Examples on using @Query 
	1] 
	@Query("select s from Student s where s.age = ?") 
	List<Student> findStudentByAgeAndSorted(int age, Sort sort); 
	2] 
	@Query(value = "SELECT * FROM Student WHERE age = :age and name= :name", nativeQuery = true) 
	Book findStudentByAgeAndStudentNameNative1(@Param("age") int age, @Param("name") String name); 
	3] 
	@Query(value = "SELECT * FROM Student WHERE age = ? and name = ? ", nativeQuery = true) 
	Book findStudentByAgeAndNameNative2(String age, String studentName); 
	*/ 
 
 
} 
 

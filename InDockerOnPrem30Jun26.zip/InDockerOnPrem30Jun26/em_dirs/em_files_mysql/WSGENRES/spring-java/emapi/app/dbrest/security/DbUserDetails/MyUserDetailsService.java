package com.example.emapi.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository; 
import com.example.emapi.User; 
import com.example.emapi.UserRepository;
import com.example.emapi.MyUserPrincipal;


@Service
public class MyUserDetailsService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException(username);
        }
        user.setPassword(new BCryptPasswordEncoder().encode(user.getPassword())); //comment out line, if storing encrypted password
        return new MyUserPrincipal(user);
    }
}

package com.example.emapi.app; 

import java.util.*;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.emapi.User;

public class MyUserPrincipal implements UserDetails {
    private final User user;

    public MyUserPrincipal(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    @Override
    public String getUsername() {
        return user.getUsername();
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        //return Collections.<GrantedAuthority>singletonList(new SimpleGrantedAuthority("User"));
        List<GrantedAuthority> list = new ArrayList<GrantedAuthority>();

        String[] role_list = user.getRoles().split(" ");
        for (String each_role : role_list) {
            //do something interesting here
            list.add(new SimpleGrantedAuthority("ROLE_" + each_role));
        }
        return list;

    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

}

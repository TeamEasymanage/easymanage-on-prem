package com.example.emapi.app; 
 
import javax.persistence.*; 
import java.util.*; 
import com.fasterxml.jackson.annotation.JsonFormat; 
 
@Entity 
@Table(name = "app_users_view") 
public class User { 

   @Id 
   private String username; 
   private String password; 
   private String email; 
   private String roles; 

   public User() { 
   } 
   public User(
   String username, 
   String password, 
   String email, 
   String roles
   ) { 
      this.username = username; 
      this.password = password; 
      this.email = email; 
      this.roles = roles; 

   } 
   public String getPassword() {    
      return password; 
   } 
   public void setPassword(String password) { 
      this.password = password; 
   } 
   public String getUsername() { 
      return username; 
   } 
   public void setUsername(String username) { 
      this.username = username; 
   } 


   public String getEmail() { 
      return email; 
   } 
   public void setEmail(String email) { 
      this.email = email; 
   } 
   public String getRoles() { 
      return roles; 
   } 
   public void setRoles(String roles) { 
      this.roles = roles; 
   } 

}

package com.example.emapi.app; 
 
import java.util.*; 
import org.springframework.data.jpa.repository.JpaRepository; 
import com.example.emapi.User; 
 
public interface UserRepository extends JpaRepository<User, String> { 
	User findByUsername(String username);
 
} 
 

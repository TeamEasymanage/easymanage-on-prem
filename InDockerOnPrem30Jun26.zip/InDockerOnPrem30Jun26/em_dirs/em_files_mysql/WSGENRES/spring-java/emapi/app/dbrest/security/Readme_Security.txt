
---------------------------------------------
	To enable Spring Rest Security - Http Basic Auth
	Steps -
	1] pom.xml : Uncomment dependency spring-boot-starter-security
	2] Follow one of below Methods -
	

	Method A - Backend API Secure with *Basic Auth* [InMemoryUserDetails]

	COPY <this_dir>/basicAuthInMemoryUserDetails To ../src/security/basicAuthInMemoryUserDetails

	Method B - Backend API Secure with *Basic Auth* [DatabaseBackedUserDetails]
	
	COPY <this_dir>/basicAuthDbUserDetails To ../src/security/basicAuthDbUserDetails
	COPY <this_dir>/DbUserDetails To ../src/security/DbUserDetails
	Implement <this_dir>/sql/app_users.sql in your database.
		
	3] Security Authorization for api calls as per ROLE_USER, ROLE_ADMIN is implemented via antMatchers (in this file only).
	4] Clean and Re-build project
   ---------------------------------------------
	Note: Below annotations can also be used in spring controller methods, do import them as well
	//@Secured({ "ADMIN" })
	//@RolesAllowed({ "USER","ADMIN" })
   ---------------------------------------------


/* ---------------------------------------------
	To enable Spring Rest Security - Http Basic Auth
	Refer to
	../Readme_Security.txt
   ---------------------------------------------
*/


package com.example.emapi.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class SpringSecurityConfigBasicAuth {

	@Value("${spring.security.debug:false}")
	boolean securityDebug;

	@Bean
	public UserDetailsService userDetailsService(BCryptPasswordEncoder bCryptPasswordEncoder) {
		InMemoryUserDetailsManager manager = new InMemoryUserDetailsManager();
		manager.createUser(User.withUsername("emUser")
				.password(bCryptPasswordEncoder.encode("emUser123"))
				.roles("USER")
				.build());
		manager.createUser(User.withUsername("emAdmin")
				.password(bCryptPasswordEncoder.encode("emAdmin123"))
				.roles("USER", "ADMIN")
				.build());
		return manager;
	}
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

						http
						.csrf().disable()
						.cors().disable()
						.authorizeRequests()
						//Based on HttpMethod type
						/*
						.antMatchers(HttpMethod.GET).hasRole("USER")
						.antMatchers(HttpMethod.POST).hasRole("USER")
						.antMatchers(HttpMethod.PUT).hasAnyRole("USER", "ADMIN")
						.antMatchers(HttpMethod.DELETE).hasRole("ADMIN")
						*/
						// Based on URL pattern
						.antMatchers("/**/ViewAll").hasRole("USER")
						.antMatchers("/**/ViewAllPaged").hasRole("USER")
						.antMatchers("/**/SelectWhere").hasRole("USER")
						.antMatchers("/**/Query").hasRole("USER")
						.antMatchers("/**/FindOne").hasRole("USER")
						.antMatchers("/**/GetOne").hasRole("USER")
						.antMatchers("/**/FindByColumnName").hasRole("USER")
						.antMatchers("/**/ConsumerService").hasRole("USER")
						.antMatchers("/**/DataMesh").hasRole("USER")
						.antMatchers("/**/Create").hasRole("USER")
						.antMatchers("/**/Update").hasAnyRole("USER", "ADMIN")
						.antMatchers("/**/Delete").hasRole("ADMIN")
						.antMatchers("/**/CreateAndProduceEvent").hasRole("USER")
						.antMatchers("/**/GetWordCount").hasRole("USER")
						.antMatchers("/**/GetWordCountAll").hasRole("USER")
						//if login needed
						//.antMatchers("/login/**")
						//.anonymous()
						.anyRequest()
						.authenticated()
						.and()
						.httpBasic()
						.and()
						.sessionManagement()
						.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
						//.and().anonymous().disable()
						//http.headers().frameOptions().disable();
						;

						return http.build();
	}

	/*
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return (web) -> web.debug(securityDebug)
				.ignoring()
				.antMatchers("/css/**", "/js/**", "/img/**", "/lib/**", "/favicon.ico");
	}
	*/
}

DROP TABLE app_users; 

CREATE TABLE app_users ( 
   username VARCHAR(45) NOT NULL , 
   password VARCHAR(45) NOT NULL , 
   email VARCHAR(200) NOT NULL , 
   roles VARCHAR(400) , 
   PRIMARY KEY (username)
); 

CREATE OR REPLACE VIEW app_users_view
as
SELECT
   username,
   password,
   email,
   roles
FROM app_users;


INSERT INTO app_users(username,password,email,roles) 
VALUES 
('emUser','emUser123', 'emUser@example.com','USER'),
('emAdmin','emAdmin123', 'emAdmin@example.com','USER ADMIN')
;

package com.example.emapi.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

@Configuration
public class EmApiRequestLoggingFilterConfig {

    @Bean
    public CommonsRequestLoggingFilter logFilter() {
        System.out.println("Init Request logging filter...");
        CommonsRequestLoggingFilter filter
                = new CommonsRequestLoggingFilter();
        filter.setIncludeQueryString(true);
        //Uncomment below to view payload
        filter.setIncludePayload(true);
        filter.setMaxPayloadLength(10000);
        filter.setIncludeHeaders(false);
        filter.setAfterMessagePrefix("API LOGGING: ");
        return filter;
    }
}

package com.example.emapi.app;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class EmResourceNotFoundException extends RuntimeException {

    public EmResourceNotFoundException(String message) {
        super(message);
    }

}

package com.example.emapi.app;

import org.hibernate.dialect.Dialect;

public class SnowflakeDialect extends Dialect {
    // Customizations can be added here if needed for specific SQL features
}


/* ---------------------------------------------
	To enable Spring Rest Security - Http Basic Auth
	Refer to
	../Readme_Security.txt
   ---------------------------------------------
*/


package com.example.emapi.app;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, securedEnabled = true, jsr250Enabled = true)
public class SpringSecurityConfigBasicAuth {

	@Value("${spring.security.debug:false}")
	boolean securityDebug;

	/*
		MyUserDetailsService:
		Custom UserDetailsService (database backed) is enabled 
		Since class is configured with the @Service annotation, 
		the application will automatically detect it during component-scan, 
		and it will create a bean out of this class.
	*/

	/* Below bCryptPasswordEncoder() bean is needed, else will get error at runtime
	 */
	@Bean
	public BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {

						http
						.csrf().disable()
						.cors().disable()
						//below 4 lines are for using Sign-Up Sign-In from frontend i.e. [isAppFESecure = true]
						.authorizeRequests()
						.antMatchers("/emdbrest/app_users_view/Create").permitAll() //Sign-Up
						.antMatchers("/emdbrest/app_users_view/SelectWhere").permitAll() //Sign-In
						.and()
						//use below if required only
						//.antMatchers("/**/checkLogin").permitAll()
						//.and().formLogin().loginPage("/login").permitAll()
						//.and().logout().invalidateHttpSession(true).clearAuthentication(true).permitAll()
						//.and()
						.authorizeRequests()
						//Securing Based on HttpMethod type
						/*
						.antMatchers(HttpMethod.GET).hasRole("USER")
						.antMatchers(HttpMethod.POST).hasRole("USER")
						.antMatchers(HttpMethod.PUT).hasAnyRole("USER", "ADMIN")
						.antMatchers(HttpMethod.DELETE).hasRole("ADMIN")
						*/
						//Securing Based on URL pattern
						.antMatchers("/**/ViewAll").hasRole("USER")
						.antMatchers("/**/ViewAllPaged").hasRole("USER")
						.antMatchers("/**/SelectWhere").hasRole("USER")
						.antMatchers("/**/Query").hasRole("USER")
						.antMatchers("/**/FindOne").hasRole("USER")
						.antMatchers("/**/GetOne").hasRole("USER")
						.antMatchers("/**/FindByColumnName").hasRole("USER")
						.antMatchers("/**/DataMesh").hasRole("USER")
						.antMatchers("/**/Create").hasRole("USER")
						.antMatchers("/**/Update").hasAnyRole("USER", "ADMIN")
						.antMatchers("/**/Delete").hasRole("ADMIN")
						//if login needed
						//.antMatchers("/login/**")
						//.anonymous()
						.anyRequest()
						.authenticated()
						.and()
						.httpBasic()
						.and()
						.sessionManagement()
						.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
						//.and().anonymous().disable()
						//http.headers().frameOptions().disable();
						;

						return http.build();
	}

	/*
	@Bean
	public WebSecurityCustomizer webSecurityCustomizer() {
		return (web) -> web.debug(securityDebug)
				.ignoring()
				.antMatchers("/css/**", "/js/**", "/img/**", "/lib/**", "/favicon.ico");
	}
	*/
}

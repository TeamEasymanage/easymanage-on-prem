
---------------------------------------------
	To enable Spring Security For GraphQL - Http Basic Auth
	Steps -
    1] pom.xml : Uncomment dependency spring-boot-starter-security
	2] Follow one of below Methods -
	

	Method A - Backend API Secure with *Basic Auth* [InMemoryUserDetails]

	COPY <this_dir>/basicAuthInMemoryUserDetailsGql To ../src/security/basicAuthInMemoryUserDetailsGql

	Method B - Backend API Secure with *Basic Auth* [DatabaseBackedUserDetails]
	
	COPY <this_dir>/basicAuthDbUserDetailsGql To ../src/security/basicAuthDbUserDetailsGql
	COPY <this_dir>../../EmDbRestApp*/spring/security/DbUserDetails To ../src/security/DbUserDetails
	Implement <this_dir>../../EmDbRestApp*/spring/security/sql/app_users.sql in your database.
		

	3] Uncomment Security Auth Annotations in *GraphqlController.java, against required Mutations 
	   e.g. @PreAuthorize("hasRole('USER') or hasRole('ADMIN')")
	   Also Uncomment imports required e.g.
		//import org.springframework.security.access.annotation.Secured;
		//import org.springframework.security.access.prepost.PreAuthorize;
	4] Clean and Re-build project
   ---------------------------------------------
	Note: Below annotations may have issues for using in spring graphql
	//@Secured({ "ADMIN" })
	//@RolesAllowed({ "USER","ADMIN" })
   ---------------------------------------------

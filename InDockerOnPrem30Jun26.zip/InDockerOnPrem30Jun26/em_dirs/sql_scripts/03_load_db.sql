-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: EMDB
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `em_agtmcp_packs`
--

DROP TABLE IF EXISTS `em_agtmcp_packs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_agtmcp_packs` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_WS_DIR` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_NAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_HOST` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LLM_TYPE` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LLM_TOK` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_PORT_API` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_PORT_MCP` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_PORT_AGT` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_OVER_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_SRC_SEC_ID` int DEFAULT NULL,
  `CL_AMP_ENABLE_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AMP_HUB_ENA_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  UNIQUE KEY `EM_AGTMCP_PACKS_IDX01` (`CL_AMP_HOST`,`CL_AMP_PORT_API`),
  UNIQUE KEY `EM_AGTMCP_PACKS_IDX02` (`CL_AMP_HOST`,`CL_AMP_PORT_MCP`),
  UNIQUE KEY `EM_AGTMCP_PACKS_IDX03` (`CL_AMP_HOST`,`CL_AMP_PORT_AGT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_agtmcp_packs`
--

LOCK TABLES `em_agtmcp_packs` WRITE;
/*!40000 ALTER TABLE `em_agtmcp_packs` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_agtmcp_packs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_auth_id_seq`
--

DROP TABLE IF EXISTS `em_auth_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_auth_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_auth_id_seq`
--

LOCK TABLES `em_auth_id_seq` WRITE;
/*!40000 ALTER TABLE `em_auth_id_seq` DISABLE KEYS */;
INSERT INTO `em_auth_id_seq` VALUES (10002);
/*!40000 ALTER TABLE `em_auth_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_categ_id_seq`
--

DROP TABLE IF EXISTS `em_categ_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_categ_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_categ_id_seq`
--

LOCK TABLES `em_categ_id_seq` WRITE;
/*!40000 ALTER TABLE `em_categ_id_seq` DISABLE KEYS */;
INSERT INTO `em_categ_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_categ_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_collab`
--

DROP TABLE IF EXISTS `em_collab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_collab` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_MAIL_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_MAIL_ID` int DEFAULT NULL,
  `CL_O_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_SITE_ID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COL_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REF_DATE` timestamp NULL DEFAULT NULL,
  `CL_O_REF_DATE` timestamp NULL DEFAULT NULL,
  `CL_STATUS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_STORY` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `EM_COLLAB_IDX02` (`CL_USER`,`CL_MAIL_ID`,`CL_O_USER`),
  KEY `EM_COLLAB_IDX01` (`CL_USER`,`CL_MAIL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_collab`
--

LOCK TABLES `em_collab` WRITE;
/*!40000 ALTER TABLE `em_collab` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_collab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_db_src`
--

DROP TABLE IF EXISTS `em_db_src`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_db_src` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_SRC_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SRC_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DRIVER` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INTL` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_NO` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DRV_LEVEL` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_URL` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_USR` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_PWD` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_db_src`
--

LOCK TABLES `em_db_src` WRITE;
/*!40000 ALTER TABLE `em_db_src` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_db_src` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_dual`
--

DROP TABLE IF EXISTS `em_dual`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_dual` (
  `COL1` char(1) COLLATE utf8mb3_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_dual`
--

LOCK TABLES `em_dual` WRITE;
/*!40000 ALTER TABLE `em_dual` DISABLE KEYS */;
INSERT INTO `em_dual` VALUES ('X');
/*!40000 ALTER TABLE `em_dual` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_emp_categ`
--

DROP TABLE IF EXISTS `em_emp_categ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_emp_categ` (
  `CL_CATEG_CODE` varchar(30) COLLATE utf8mb3_bin NOT NULL,
  `CL_LEVEL` int DEFAULT NULL,
  `CL_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NAME_SHORT` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_CATEG_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_emp_categ`
--

LOCK TABLES `em_emp_categ` WRITE;
/*!40000 ALTER TABLE `em_emp_categ` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_emp_categ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_field_id_seq`
--

DROP TABLE IF EXISTS `em_field_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_field_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_field_id_seq`
--

LOCK TABLES `em_field_id_seq` WRITE;
/*!40000 ALTER TABLE `em_field_id_seq` DISABLE KEYS */;
INSERT INTO `em_field_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_field_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fields`
--

DROP TABLE IF EXISTS `em_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fields` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_PROMPT` varchar(500) COLLATE utf8mb3_bin NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_FIELD_SQL_ID` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_TYPE` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LENGTH` int DEFAULT NULL,
  `CL_DISP_LEN` int DEFAULT NULL,
  `CL_VLDN_ID` int DEFAULT NULL,
  KEY `EM_FIELDS_IDX01` (`CL_USER`,`CL_FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fields`
--

LOCK TABLES `em_fields` WRITE;
/*!40000 ALTER TABLE `em_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_blob`
--

DROP TABLE IF EXISTS `em_fld_val_blob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_blob` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VAL_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PATH` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNTTYPE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNTSIZE` int DEFAULT NULL,
  `CL_VALUE` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BLOB_VAL` mediumblob,
  KEY `EM_FLD_VAL_BLOB_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_blob`
--

LOCK TABLES `em_fld_val_blob` WRITE;
/*!40000 ALTER TABLE `em_fld_val_blob` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_blob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_bool`
--

DROP TABLE IF EXISTS `em_fld_val_bool`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_bool` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  KEY `EM_FLD_VAL_BOOL_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_bool`
--

LOCK TABLES `em_fld_val_bool` WRITE;
/*!40000 ALTER TABLE `em_fld_val_bool` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_bool` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_char`
--

DROP TABLE IF EXISTS `em_fld_val_char`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_char` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  KEY `EM_FLD_VAL_CHAR_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_char`
--

LOCK TABLES `em_fld_val_char` WRITE;
/*!40000 ALTER TABLE `em_fld_val_char` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_char` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_clob`
--

DROP TABLE IF EXISTS `em_fld_val_clob`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_clob` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` mediumblob,
  KEY `EM_FLD_VAL_CLOB_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_clob`
--

LOCK TABLES `em_fld_val_clob` WRITE;
/*!40000 ALTER TABLE `em_fld_val_clob` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_clob` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_date`
--

DROP TABLE IF EXISTS `em_fld_val_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_date` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` timestamp NULL DEFAULT NULL,
  KEY `EM_FLD_VAL_DATE_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_date`
--

LOCK TABLES `em_fld_val_date` WRITE;
/*!40000 ALTER TABLE `em_fld_val_date` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_date` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_flt`
--

DROP TABLE IF EXISTS `em_fld_val_flt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_flt` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` decimal(38,6) DEFAULT NULL,
  KEY `EM_FLD_VAL_FLT_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_flt`
--

LOCK TABLES `em_fld_val_flt` WRITE;
/*!40000 ALTER TABLE `em_fld_val_flt` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_flt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_num`
--

DROP TABLE IF EXISTS `em_fld_val_num`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_num` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` int DEFAULT NULL,
  KEY `EM_FLD_VAL_NUM_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_num`
--

LOCK TABLES `em_fld_val_num` WRITE;
/*!40000 ALTER TABLE `em_fld_val_num` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_num` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_stream`
--

DROP TABLE IF EXISTS `em_fld_val_stream`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_stream` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` mediumblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_stream`
--

LOCK TABLES `em_fld_val_stream` WRITE;
/*!40000 ALTER TABLE `em_fld_val_stream` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_stream` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_text`
--

DROP TABLE IF EXISTS `em_fld_val_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_text` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` mediumtext COLLATE utf8mb3_bin,
  KEY `EM_FLD_VAL_TEXT_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_text`
--

LOCK TABLES `em_fld_val_text` WRITE;
/*!40000 ALTER TABLE `em_fld_val_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_fld_val_texts`
--

DROP TABLE IF EXISTS `em_fld_val_texts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_fld_val_texts` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VALUE` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  KEY `EM_FLD_VAL_TEXTS_IDX01` (`CL_USER`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_fld_val_texts`
--

LOCK TABLES `em_fld_val_texts` WRITE;
/*!40000 ALTER TABLE `em_fld_val_texts` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_fld_val_texts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_form_id_seq`
--

DROP TABLE IF EXISTS `em_form_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_form_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_form_id_seq`
--

LOCK TABLES `em_form_id_seq` WRITE;
/*!40000 ALTER TABLE `em_form_id_seq` DISABLE KEYS */;
INSERT INTO `em_form_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_form_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_locations`
--

DROP TABLE IF EXISTS `em_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_locations` (
  `CL_LOC_ID` int NOT NULL,
  `CL_LOC_GL_ID` int DEFAULT NULL,
  `CL_LOC_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CITY` varchar(200) COLLATE utf8mb3_bin NOT NULL,
  `CL_STATE_CODE` varchar(10) COLLATE utf8mb3_bin NOT NULL,
  `CL_ZIP` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CC_CODE` varchar(2) COLLATE utf8mb3_bin NOT NULL,
  `CL_DIST` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOCALITY` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOC_FEAT_CLS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_CC_CODE`,`CL_STATE_CODE`,`CL_CITY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_locations`
--

LOCK TABLES `em_locations` WRITE;
/*!40000 ALTER TABLE `em_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_ctl`
--

DROP TABLE IF EXISTS `em_mail_ctl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_ctl` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_MAIL_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_MAIL_ID` int DEFAULT NULL,
  `CL_O_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_O_SITE_ID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TRNF_ID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR_FM` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR_TO` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EM_TO_USERS` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EM_TO_APPS` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SUBJECT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PKG_LEV` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAILMSG_FLG` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_TYPE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_CATEG` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SITE_TYPE` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FOLDER` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_STATUS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_KEY_WORDS` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_HEADERS` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SENT_DATE` timestamp NULL DEFAULT NULL,
  `CL_RCVD_DATE` timestamp NULL DEFAULT NULL,
  `CL_SIZE` int DEFAULT NULL,
  `CL_PRIORITY` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MP_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ATTACH_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_MAIL_CTL_IDX01` (`CL_USER`,`CL_MAIL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_ctl`
--

LOCK TABLES `em_mail_ctl` WRITE;
/*!40000 ALTER TABLE `em_mail_ctl` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_mail_ctl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_def`
--

DROP TABLE IF EXISTS `em_mail_def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_def` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SU` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_DEF_ID` int NOT NULL,
  `CL_OBJ_FLG` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ACT_FLG` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR_FM` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR_RPL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR_TO` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SUBJECT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BEFAFT_YN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PG_BEF` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PG_AFT` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_MAIL_DEF_IDX01` (`CL_USER`,`CL_MAIL_DEF_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_def`
--

LOCK TABLES `em_mail_def` WRITE;
/*!40000 ALTER TABLE `em_mail_def` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_mail_def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_def_id_seq`
--

DROP TABLE IF EXISTS `em_mail_def_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_def_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_def_id_seq`
--

LOCK TABLES `em_mail_def_id_seq` WRITE;
/*!40000 ALTER TABLE `em_mail_def_id_seq` DISABLE KEYS */;
INSERT INTO `em_mail_def_id_seq` VALUES (10001);
/*!40000 ALTER TABLE `em_mail_def_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_def_tran`
--

DROP TABLE IF EXISTS `em_mail_def_tran`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_def_tran` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SU` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_DEF_ID` int NOT NULL,
  `CL_TRAN_ID` int DEFAULT NULL,
  `CL_OBJ_FLG` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_ID` int DEFAULT NULL,
  `CL_VAL_ID` int DEFAULT NULL,
  `CL_VAL_ORDER` int DEFAULT NULL,
  `CL_FIELD_ID` int DEFAULT NULL,
  `CL_FORM_ID` int DEFAULT NULL,
  `CL_QRY_ID` int DEFAULT NULL,
  `CL_WP_ID` int DEFAULT NULL,
  `CL_SCR_ID` int DEFAULT NULL,
  `CL_FILE_ID` int DEFAULT NULL,
  `CL_ACT_FLG` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_AS` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROC_FLG` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_STATUS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SENT_DATE` timestamp NULL DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_MAIL_DEF_TRAN_IDX01` (`CL_PROC_FLG`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_def_tran`
--

LOCK TABLES `em_mail_def_tran` WRITE;
/*!40000 ALTER TABLE `em_mail_def_tran` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_mail_def_tran` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_det`
--

DROP TABLE IF EXISTS `em_mail_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_det` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_MAIL_ID` int NOT NULL,
  `CL_DET_ID` int NOT NULL,
  `CL_PART_LEV` int DEFAULT NULL,
  `CL_PART_NO` int DEFAULT NULL,
  `CL_MP_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MP_CNT` int DEFAULT NULL,
  `CL_VAL_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ATTACH_YN` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PATH` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNTTYPE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_ENC` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_DISP` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_HEADERS` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SIZE` int DEFAULT NULL,
  `CL_VALUE` text COLLATE utf8mb3_bin,
  `CL_BLOB_VAL` mediumblob,
  KEY `EM_MAIL_DET_IDX01` (`CL_USER`,`CL_MAIL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_det`
--

LOCK TABLES `em_mail_det` WRITE;
/*!40000 ALTER TABLE `em_mail_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_mail_det` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_mail_id_seq`
--

DROP TABLE IF EXISTS `em_mail_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_mail_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_mail_id_seq`
--

LOCK TABLES `em_mail_id_seq` WRITE;
/*!40000 ALTER TABLE `em_mail_id_seq` DISABLE KEYS */;
INSERT INTO `em_mail_id_seq` VALUES (10001);
/*!40000 ALTER TABLE `em_mail_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_marksend`
--

DROP TABLE IF EXISTS `em_marksend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_marksend` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_ID` int DEFAULT NULL,
  `CL_PARENT_CATEG_ID` int DEFAULT NULL,
  `CL_CATEG_TYPE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_NAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SENDYN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_OBJYN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_OBJ_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_OBJ_PARTS` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FORM_ID` int DEFAULT NULL,
  `CL_QRY_ID` int DEFAULT NULL,
  `CL_VAL_ID` int DEFAULT NULL,
  `CL_WP_ID` int DEFAULT NULL,
  `CL_SCREEN_ID` int DEFAULT NULL,
  `CL_SCREEN_ORD` int DEFAULT NULL,
  `CL_USER_ID` int DEFAULT NULL,
  `CL_USER_SEC_ID` int DEFAULT NULL,
  `CL_REC_STAT` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_TYP` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_MARKSEND` (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_marksend`
--

LOCK TABLES `em_marksend` WRITE;
/*!40000 ALTER TABLE `em_marksend` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_marksend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_marksend_2`
--

DROP TABLE IF EXISTS `em_marksend_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_marksend_2` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_OBJ_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_ID` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CONT_ID` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INFO` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_OWNER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_TYP` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_marksend_2`
--

LOCK TABLES `em_marksend_2` WRITE;
/*!40000 ALTER TABLE `em_marksend_2` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_marksend_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_odb_ctg_tree`
--

DROP TABLE IF EXISTS `em_odb_ctg_tree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_odb_ctg_tree` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_TYP` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TREE_STR` varchar(850) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_PARENT_CATEG_ID` int DEFAULT NULL,
  `CL_LEVELS` int DEFAULT NULL,
  `CL_DISP_ORD` int DEFAULT NULL,
  `CL_CATEG_TYPE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NEW_CTG_ID` int DEFAULT NULL,
  `CL_NEW_PRNT_ID` int DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_ODB_CTG_TREE_IDX01` (`CL_USER`,`CL_TREE_STR`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_odb_ctg_tree`
--

LOCK TABLES `em_odb_ctg_tree` WRITE;
/*!40000 ALTER TABLE `em_odb_ctg_tree` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_odb_ctg_tree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_qry_id_seq`
--

DROP TABLE IF EXISTS `em_qry_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_qry_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_qry_id_seq`
--

LOCK TABLES `em_qry_id_seq` WRITE;
/*!40000 ALTER TABLE `em_qry_id_seq` DISABLE KEYS */;
INSERT INTO `em_qry_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_qry_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_runstat_hdr`
--

DROP TABLE IF EXISTS `em_runstat_hdr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_runstat_hdr` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_RUN_ID` int NOT NULL,
  `CL_TYPE` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SUBTYPE` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COUNT` int DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_RUNSTAT_HDR_IDX01` (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_runstat_hdr`
--

LOCK TABLES `em_runstat_hdr` WRITE;
/*!40000 ALTER TABLE `em_runstat_hdr` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_runstat_hdr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_screen_id_seq`
--

DROP TABLE IF EXISTS `em_screen_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_screen_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_screen_id_seq`
--

LOCK TABLES `em_screen_id_seq` WRITE;
/*!40000 ALTER TABLE `em_screen_id_seq` DISABLE KEYS */;
INSERT INTO `em_screen_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_screen_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_siteid`
--

DROP TABLE IF EXISTS `em_siteid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_siteid` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_SITE_ID` varchar(40) COLLATE utf8mb3_bin NOT NULL,
  `CL_KEY` int DEFAULT NULL,
  `CL_KEY_RCV` int DEFAULT NULL,
  `CL_KEY_SITE_ID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_KEY_GEN` int DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_SITEID_IDX01` (`CL_USER`,`CL_SITE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_siteid`
--

LOCK TABLES `em_siteid` WRITE;
/*!40000 ALTER TABLE `em_siteid` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_siteid` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user`
--

DROP TABLE IF EXISTS `em_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_PASS` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_STAT` varchar(10) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_ID` int NOT NULL,
  `CL_USER_NAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_DESC` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_WEBSITE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_WEBSITE2` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PARENT_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PARENT_USER_ID` int DEFAULT NULL,
  `CL_USER_PERM` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_VLDN_ID` int DEFAULT NULL,
  `CL_COMM` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EMAIL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EMAIL2` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_NAME2` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EMAIL3` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_NAME3` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EMAIL_STAT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_USER` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_PASS` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_FOLD` mediumtext COLLATE utf8mb3_bin,
  `CL_MAIL_SUFFIX` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MAIL_REPLYTO` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_KEY_WORDS` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FNAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LNAME` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PHONE_H` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PHONE_W` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PHONE_FAX` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PHONE_C` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PHONE_PGR` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEX` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BIRTH_YR` varchar(4) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BIRTH_MO` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BIRTH_DD` varchar(2) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMPANY` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ACC_TYPE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MEMB_TYPE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROMO_TYPE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR1` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ADDR2` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CITY` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_STATE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ZIP` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COUNTRY` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOCALE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USR_SRH` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EM_PREF` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SITE_ID` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_GR_CODE` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_CODE` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_PROP` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_SRH` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_INFO` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_DATE` timestamp NULL DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user`
--

LOCK TABLES `em_user` WRITE;
/*!40000 ALTER TABLE `em_user` DISABLE KEYS */;
INSERT INTO `em_user` VALUES ('ADMIN','ADMIN','VALID',11,'EM SU ADMIN ACCOUNT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-05-06 06:13:21','2026-05-06 06:13:21');
/*!40000 ALTER TABLE `em_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `TR_EM_USER_ADD_SELF_CONTACT` AFTER INSERT ON `em_user` FOR EACH ROW BEGIN
	DECLARE P2 INT;
	IF (NEW.CL_USER NOT LIKE 'EMAPP%') THEN
	IF (NEW.CL_USER NOT LIKE 'EMMAIL%') THEN
	
	UPDATE EM_AUTH_ID_SEQ SET CL_ID = CL_ID + 1 ; 
	SELECT CL_ID into P2 FROM EM_AUTH_ID_SEQ ;

	INSERT INTO EM_USER_CONTACTS ( 
	CL_USER,		
	CL_CNT_TYPE,	
	CL_CNT_SUBTYPE,	
	CL_CNT_USER,	
	CL_CNT_USER_NM,	
	CL_REC_STAT,
	CL_CRBY_USER,	
	CL_CRDATE,		
	CL_UPDBY_USER,	
	CL_UPDDATE,		
	CL_USER_SEC_ID	
	) VALUES (
	NEW.CL_USER,
	'Contact',
	'Yes',
	NEW.CL_USER,
	concat(NEW.CL_USER,' Self Contact'),
	'Active',
	NEW.CL_USER,
	NEW.CL_CRDATE,
	NEW.CL_USER,
	NEW.CL_UPDDATE,
	P2
	);
	END IF;
	END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `em_user_agt_run`
--

DROP TABLE IF EXISTS `em_user_agt_run`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_agt_run` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_AG_ID` int DEFAULT NULL,
  `CL_RUN_ID` int DEFAULT NULL,
  `CL_EXEC_ID` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TASK_ID` int DEFAULT NULL,
  `CL_STEP_NO` int DEFAULT NULL,
  `CL_TASK_RESP` text COLLATE utf8mb3_bin,
  `CL_TASK_STATUS` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REQ_APPROV` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TASK_MSG` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LAST_STEP` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MODEL_REQ` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TASK_PROMPT` text COLLATE utf8mb3_bin,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_AGT_RUN_IDX01` (`CL_USER`,`CL_CATEG_ID`),
  KEY `EM_USER_AGT_RUN_IDX02` (`CL_USER`,`CL_AG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_agt_run`
--

LOCK TABLES `em_user_agt_run` WRITE;
/*!40000 ALTER TABLE `em_user_agt_run` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_agt_run` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_agt_svrconf`
--

DROP TABLE IF EXISTS `em_user_agt_svrconf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_agt_svrconf` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_URL_BASE` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MODELS_LIST` text COLLATE utf8mb3_bin,
  `CL_MODELS_FLG` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_TYPE` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_KEY` varchar(900) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_KEY_ROLE` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_TYPE` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USRNAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USRPASS` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USRROLE` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BEARER_TOK` varchar(900) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_RAG_FLG` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEM_CACHE_FLG` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  UNIQUE KEY `EM_USER_AGT_SVRCONF_IDX01` (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_agt_svrconf`
--

LOCK TABLES `em_user_agt_svrconf` WRITE;
/*!40000 ALTER TABLE `em_user_agt_svrconf` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_agt_svrconf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_agt_task`
--

DROP TABLE IF EXISTS `em_user_agt_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_agt_task` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_AG_ID` int DEFAULT NULL,
  `CL_TASK_ID` int DEFAULT NULL,
  `CL_TASK_ORD` int DEFAULT NULL,
  `CL_TASK_NAME` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PMT_TYPE` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INPUT_PROMPT` text COLLATE utf8mb3_bin,
  `CL_TBL_ID` int DEFAULT NULL,
  `CL_TBL_UTIL_TYPE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBL_UTIL_ID` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBL_UTIL_PROMPT` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INPUT_CONTEXT` text COLLATE utf8mb3_bin,
  `CL_PREV_CONTEXT_YN` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PREV_CONTEXT_SEL` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CONTEXT_SV_PMT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TASK_MODEL` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_RAG_YN` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_RAG_FILTER` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEM_CACHE_YN` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_AGT_TASK_IDX01` (`CL_USER`,`CL_AG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_agt_task`
--

LOCK TABLES `em_user_agt_task` WRITE;
/*!40000 ALTER TABLE `em_user_agt_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_agt_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_agtproj`
--

DROP TABLE IF EXISTS `em_user_agtproj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_agtproj` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_AG_ID` int DEFAULT NULL,
  `CL_AGT_TYPE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PATTERN` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROJ_NAME` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TOOL_LIMIT` int DEFAULT NULL,
  `CL_TOOL_NM_INCL` varchar(5000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TOOL_NM_EXCL` varchar(5000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SYS_PROMPT` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTO_APROV_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROJ_MODEL` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ALLOW_SW` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  UNIQUE KEY `EM_USER_AGTPROJ_IDX01` (`CL_USER`,`CL_CATEG_ID`),
  KEY `EM_USER_AGTPROJ_IDX02` (`CL_USER`,`CL_AG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_agtproj`
--

LOCK TABLES `em_user_agtproj` WRITE;
/*!40000 ALTER TABLE `em_user_agtproj` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_agtproj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth`
--

DROP TABLE IF EXISTS `em_user_auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_AUTH_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_NAME` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_GROUP_ID` int DEFAULT NULL,
  `CL_CHILD_ID` int DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR_OVR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  KEY `EM_USER_AUTH_IDX01` (`CL_USER_APP`,`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth`
--

LOCK TABLES `em_user_auth` WRITE;
/*!40000 ALTER TABLE `em_user_auth` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth_det`
--

DROP TABLE IF EXISTS `em_user_auth_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth_det` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int DEFAULT NULL,
  `CL_WP_ID` int DEFAULT NULL,
  `CL_SCR_ID` int DEFAULT NULL,
  `CL_FILE_ID` int DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`),
  KEY `EM_USER_AUTH_DET_IDX01` (`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth_det`
--

LOCK TABLES `em_user_auth_det` WRITE;
/*!40000 ALTER TABLE `em_user_auth_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth_det` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth_dg`
--

DROP TABLE IF EXISTS `em_user_auth_dg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth_dg` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DG_ENTRY_DEF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DG_QRY_PREF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`),
  KEY `EM_USER_AUTH_DG_IDX01` (`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth_dg`
--

LOCK TABLES `em_user_auth_dg` WRITE;
/*!40000 ALTER TABLE `em_user_auth_dg` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth_dg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth_grant`
--

DROP TABLE IF EXISTS `em_user_auth_grant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth_grant` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_GRANT_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`),
  KEY `EM_USER_AUTH_GRANT_IDX01` (`CL_GRANT_USER`,`CL_USER_APP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth_grant`
--

LOCK TABLES `em_user_auth_grant` WRITE;
/*!40000 ALTER TABLE `em_user_auth_grant` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth_grant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth_grant_dg`
--

DROP TABLE IF EXISTS `em_user_auth_grant_dg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth_grant_dg` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DG_ENTRY_DEF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DG_QRY_PREF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth_grant_dg`
--

LOCK TABLES `em_user_auth_grant_dg` WRITE;
/*!40000 ALTER TABLE `em_user_auth_grant_dg` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth_grant_dg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_auth_tag`
--

DROP TABLE IF EXISTS `em_user_auth_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_auth_tag` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USRGRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_RATING` float DEFAULT NULL,
  `CL_GRANT_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TAGP_DEF` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TAGP_CUST` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ICON_LIST` varchar(1000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TAGP_TAGS` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_VOTE_MIN` int DEFAULT NULL,
  `CL_VOTE_CNT` int DEFAULT NULL,
  `CL_VOTE_FLG` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_RATING_VOTE` float DEFAULT NULL,
  `CL_USRGRP_VOTE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_auth_tag`
--

LOCK TABLES `em_user_auth_tag` WRITE;
/*!40000 ALTER TABLE `em_user_auth_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_auth_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_blk`
--

DROP TABLE IF EXISTS `em_user_blk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_blk` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_OWN` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_BLK` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_ALL_APPS` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_BLK` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  KEY `EM_USER_BLK_IDX01` (`CL_USER_BLK`),
  KEY `EM_USER_BLK_IDX02` (`CL_USER_OWN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_blk`
--

LOCK TABLES `em_user_blk` WRITE;
/*!40000 ALTER TABLE `em_user_blk` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_blk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_bs_role`
--

DROP TABLE IF EXISTS `em_user_bs_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_bs_role` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_BS_ROLE` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  UNIQUE KEY `EM_USER_BS_ROLE_IDX01` (`CL_USER`,`CL_BS_ROLE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_bs_role`
--

LOCK TABLES `em_user_bs_role` WRITE;
/*!40000 ALTER TABLE `em_user_bs_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_bs_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_bs_role_perm`
--

DROP TABLE IF EXISTS `em_user_bs_role_perm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_bs_role_perm` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_CATEG_ID` int DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`),
  UNIQUE KEY `EM_USER_BS_ROLE_PERM_IDX01` (`CL_USER`,`CL_CATEG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_bs_role_perm`
--

LOCK TABLES `em_user_bs_role_perm` WRITE;
/*!40000 ALTER TABLE `em_user_bs_role_perm` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_bs_role_perm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_bs_users`
--

DROP TABLE IF EXISTS `em_user_bs_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_bs_users` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_BS_USER` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BS_PWD` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BS_EMAIL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_BS_ROLES` varchar(400) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  UNIQUE KEY `EM_USER_BS_USERS_IDX01` (`CL_USER`,`CL_BS_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_bs_users`
--

LOCK TABLES `em_user_bs_users` WRITE;
/*!40000 ALTER TABLE `em_user_bs_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_bs_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_categ`
--

DROP TABLE IF EXISTS `em_user_categ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_categ` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_PARENT_CATEG_ID` int DEFAULT NULL,
  `CL_LEVELS` int DEFAULT NULL,
  `CL_DISP_ORD` int DEFAULT NULL,
  `CL_CHILDYN` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATAYN` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_TYPE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CHILD_CATEG_TYPE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_NAME` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SENDYN` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOCALE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_CATEG_IDX01` (`CL_USER`,`CL_CATEG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_categ`
--

LOCK TABLES `em_user_categ` WRITE;
/*!40000 ALTER TABLE `em_user_categ` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_categ` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_categ_det`
--

DROP TABLE IF EXISTS `em_user_categ_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_categ_det` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FLD_ORDER` int DEFAULT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_GRP_ORIENT` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TIMEDIM` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_MULTI_INP` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FORMAT_ID` int DEFAULT NULL,
  `CL_TBLDBPROP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLDBOPS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDBPROP` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDBOPS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDUPDKEY` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DAT_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DAT_CTG_ID` int DEFAULT NULL,
  `CL_DAT_FLD_ID` int DEFAULT NULL,
  `CL_EM_PREF` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DB_PREF` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATACRDATE` timestamp NULL DEFAULT NULL,
  `CL_DATAUPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_CATEG_DET_IDX01` (`CL_USER`,`CL_CATEG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_categ_det`
--

LOCK TABLES `em_user_categ_det` WRITE;
/*!40000 ALTER TABLE `em_user_categ_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_categ_det` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_categ_sub`
--

DROP TABLE IF EXISTS `em_user_categ_sub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_categ_sub` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_SHR_TYP` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_SUB` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_ID_SUB` int DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_CATEG_SUB_IDX01` (`CL_USER`,`CL_CATEG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_categ_sub`
--

LOCK TABLES `em_user_categ_sub` WRITE;
/*!40000 ALTER TABLE `em_user_categ_sub` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_categ_sub` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_contact_apps`
--

DROP TABLE IF EXISTS `em_user_contact_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_contact_apps` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CNT_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_APP_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_FM_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USR1_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USR2_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROP_BKP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROP_CRTAPP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COPYSTORY` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PASTESTORY` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_STORY` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_CNT_USER`,`CL_APP_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_contact_apps`
--

LOCK TABLES `em_user_contact_apps` WRITE;
/*!40000 ALTER TABLE `em_user_contact_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_contact_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_contacts`
--

DROP TABLE IF EXISTS `em_user_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_contacts` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_CNT_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_CLASS` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_SUBTYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_EMAIL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_EMAIL2` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_PHONE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_PHONE2` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CNT_USER_NM` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  UNIQUE KEY `CL_USER` (`CL_USER`,`CL_CNT_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_contacts`
--

LOCK TABLES `em_user_contacts` WRITE;
/*!40000 ALTER TABLE `em_user_contacts` DISABLE KEYS */;
INSERT INTO `em_user_contacts` VALUES ('ADMIN',10002,'Contact',NULL,'Yes','ADMIN',NULL,NULL,NULL,NULL,'ADMIN Self Contact','Active','ADMIN','2026-05-06 06:13:21','ADMIN','2026-05-06 06:13:21');
/*!40000 ALTER TABLE `em_user_contacts` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `TR_EM_USER_CONTACTS` BEFORE INSERT ON `em_user_contacts` FOR EACH ROW BEGIN
		DECLARE P1 VARCHAR(10);
		SET P1 = 'No';
		select 
			CASE CL_STAT
			WHEN 'VALID' THEN 'Yes'
			ELSE 'No' 
			END
		  into P1 
		from em_user 
		where cl_user = NEW.CL_CNT_USER
		   ;
		SET NEW.CL_CNT_SUBTYPE = P1;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `em_user_contacts_grp`
--

DROP TABLE IF EXISTS `em_user_contacts_grp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_contacts_grp` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_REC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_GRANT_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`,`CL_REC_ID`),
  KEY `EM_USER_CONTACTS_GRP_IDX01` (`CL_GRANT_USER`,`CL_USER_APP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_contacts_grp`
--

LOCK TABLES `em_user_contacts_grp` WRITE;
/*!40000 ALTER TABLE `em_user_contacts_grp` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_contacts_grp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_data`
--

DROP TABLE IF EXISTS `em_user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_data` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_VAL_ORDER` int DEFAULT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATACRDATE` timestamp NULL DEFAULT NULL,
  `CL_DATAUPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_DATA_IDX01` (`CL_USER`,`CL_CATEG_ID`,`CL_VAL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_data`
--

LOCK TABLES `em_user_data` WRITE;
/*!40000 ALTER TABLE `em_user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_data_tag`
--

DROP TABLE IF EXISTS `em_user_data_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_data_tag` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_WP_ID` int NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `CL_TG_USER_SI` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_CATEG_ID` int DEFAULT NULL,
  `CL_TG_VAL_ID` int DEFAULT NULL,
  `CL_TG_VAL_ID_SRL` int DEFAULT NULL,
  `CL_TG_VAL_ORDER` int DEFAULT NULL,
  `CL_TG_ST_UPD` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_VW_ID` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_GT_EUT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_ACC_1` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_ACC_2` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_ACC_3` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_ACC_4` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_ACC_5` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FMTO_FLAG` int DEFAULT NULL,
  `CL_VALID_FM` timestamp NULL DEFAULT NULL,
  `CL_VALID_TO` timestamp NULL DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TAGP_DEF` text COLLATE utf8mb3_bin,
  `CL_TAGP_CUST` text COLLATE utf8mb3_bin,
  `CL_TAGP_TAGS` text COLLATE utf8mb3_bin,
  `CL_ICON_LIST` text COLLATE utf8mb3_bin,
  `CL_TG_1FIELD_ID` int DEFAULT NULL,
  `CL_TG_1VALUE` text COLLATE utf8mb3_bin,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATACRDATE` timestamp NULL DEFAULT NULL,
  `CL_DATAUPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_DATA_TAG_IDX01` (`CL_USER`,`CL_WP_ID`,`CL_TG_USER_SI`),
  KEY `EM_USER_DATA_TAG_IDX02` (`CL_USER`,`CL_WP_ID`,`CL_CATEG_ID`,`CL_VAL_ID`,`CL_TG_USER_SI`),
  KEY `EM_USER_DATA_TAG_IDX03` (`CL_TG_USER_SI`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_data_tag`
--

LOCK TABLES `em_user_data_tag` WRITE;
/*!40000 ALTER TABLE `em_user_data_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_data_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_dg`
--

DROP TABLE IF EXISTS `em_user_dg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_dg` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_DG_ENTRY_DEF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DG_QRY_PREF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DIS` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_SUBSID` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_LOC` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DEPT1` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DEPT2` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DEPT3` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DEPT4` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COMP_DEPT5` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_ROLE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  KEY `EM_USER_DG_IDX01` (`CL_USER_APP`,`CL_DATA_GRP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_dg`
--

LOCK TABLES `em_user_dg` WRITE;
/*!40000 ALTER TABLE `em_user_dg` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_dg` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_emp_apps`
--

DROP TABLE IF EXISTS `em_user_emp_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_emp_apps` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_APP_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_C_NAME` varchar(250) COLLATE utf8mb3_bin NOT NULL,
  `CL_APP_FM_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_APP_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROP_CRTAPP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DISABLE_CRTAPP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_COPYSTORY` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PASTESTORY` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_CODE` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_CUST` varchar(250) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CONT_PUBLIC` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR_PUB` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_STORY` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_C_NAME`,`CL_APP_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_emp_apps`
--

LOCK TABLES `em_user_emp_apps` WRITE;
/*!40000 ALTER TABLE `em_user_emp_apps` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_emp_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_forms`
--

DROP TABLE IF EXISTS `em_user_forms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_forms` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FORM_ID` int NOT NULL,
  `CL_TBLORIENT` varchar(25) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLBORDER` int DEFAULT NULL,
  `CL_TBLWIDTH` int DEFAULT NULL,
  `CL_TBLBGCOLOR` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLCELLSP` int DEFAULT NULL,
  `CL_TBLCELLPADD` int DEFAULT NULL,
  `CL_TBLALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLVALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLSUBNM` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLFORMAT_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLFORMAT` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLFRST_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLFRSTYLE` mediumtext COLLATE utf8mb3_bin,
  `CL_TBLSEM_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBLSEM_BEF` text COLLATE utf8mb3_bin,
  `CL_TBLSEM_AFT` text COLLATE utf8mb3_bin,
  `CL_RECSEM_BEF` text COLLATE utf8mb3_bin,
  `CL_RECSEM_AFT` text COLLATE utf8mb3_bin,
  `CL_FORM_NM` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FORM_ST` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  `CL_TBL_SKIP_FE` int DEFAULT NULL,
  `CL_TBL_SKIP_BE` int DEFAULT NULL,
  `CL_TBL_NO_SKIP_EMLIB` int DEFAULT NULL,
  `CL_TBL_SKIP_PARTS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TBL_LABEL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  KEY `EM_USER_FORMS_IDX01` (`CL_USER`,`CL_CATEG_ID`,`CL_FORM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_forms`
--

LOCK TABLES `em_user_forms` WRITE;
/*!40000 ALTER TABLE `em_user_forms` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_forms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_forms_fld`
--

DROP TABLE IF EXISTS `em_user_forms_fld`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_forms_fld` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FORM_ID` int NOT NULL,
  `CL_FIELD_ID` int NOT NULL,
  `CL_FLDBLLNBEF` int DEFAULT NULL,
  `CL_FLDSTPRLN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDWIDTH` int DEFAULT NULL,
  `CL_FLDBOLD` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDITA` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDUNDR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDBGCOLOR` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDFNTNM` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDFNTSIZE` int DEFAULT NULL,
  `CL_FLDFNTCOL` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDVALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDNOBR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATBOLD` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATITA` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATUNDR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATBGCOLOR` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATFNTNM` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATFNTSIZE` int DEFAULT NULL,
  `CL_FLDDATFNTCOL` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATVALIGN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATNOBR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDHIDE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATHIDE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATMAND` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATDEFVAL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATMULTVAL` mediumtext COLLATE utf8mb3_bin,
  `CL_FLDDATMIN` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATMAX` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATCHRMIN` int DEFAULT NULL,
  `CL_FLDFORMAT_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDFORMAT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDISPFMT_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDISPFMT` varchar(1000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDFRST_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDFRSTYLE` mediumtext COLLATE utf8mb3_bin,
  `CL_FLDDATFRST_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATFRSTYLE` mediumtext COLLATE utf8mb3_bin,
  `CL_FLDDATSEM_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATSEM_BEF` text COLLATE utf8mb3_bin,
  `CL_FLDDATSEM_AFT` text COLLATE utf8mb3_bin,
  `CL_FLDDATDER_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLDDATDER_EXPR` mediumtext COLLATE utf8mb3_bin,
  `CL_FLDLINE` int DEFAULT NULL,
  `CL_FLDCOLFM` int DEFAULT NULL,
  `CL_FLDCOLTO` int DEFAULT NULL,
  `CL_FLDDATLINE` int DEFAULT NULL,
  `CL_FLDDATCOLFM` int DEFAULT NULL,
  `CL_FLDDATCOLTO` int DEFAULT NULL,
  `CL_LOOKUP_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LK_WP_ID` int DEFAULT NULL,
  `CL_LK_SCR_ID` int DEFAULT NULL,
  `CL_LK_FIELD_ID` int DEFAULT NULL,
  `CL_INP_HTMLOBJ` mediumtext COLLATE utf8mb3_bin,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_FORMS_FLD_IDX01` (`CL_USER`,`CL_CATEG_ID`,`CL_FORM_ID`,`CL_FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_forms_fld`
--

LOCK TABLES `em_user_forms_fld` WRITE;
/*!40000 ALTER TABLE `em_user_forms_fld` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_forms_fld` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `em_user_forms_fld_vw`
--

DROP TABLE IF EXISTS `em_user_forms_fld_vw`;
/*!50001 DROP VIEW IF EXISTS `em_user_forms_fld_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_user_forms_fld_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_FORM_ID`,
 1 AS `CL_FIELD_ID`,
 1 AS `CL_FLDBLLNBEF`,
 1 AS `CL_FLDSTPRLN`,
 1 AS `CL_FLDWIDTH`,
 1 AS `CL_FLDBOLD`,
 1 AS `CL_FLDITA`,
 1 AS `CL_FLDUNDR`,
 1 AS `CL_FLDBGCOLOR`,
 1 AS `CL_FLDFNTNM`,
 1 AS `CL_FLDFNTSIZE`,
 1 AS `CL_FLDFNTCOL`,
 1 AS `CL_FLDALIGN`,
 1 AS `CL_FLDVALIGN`,
 1 AS `CL_FLDNOBR`,
 1 AS `CL_FLDDATBOLD`,
 1 AS `CL_FLDDATITA`,
 1 AS `CL_FLDDATUNDR`,
 1 AS `CL_FLDDATBGCOLOR`,
 1 AS `CL_FLDDATFNTNM`,
 1 AS `CL_FLDDATFNTSIZE`,
 1 AS `CL_FLDDATFNTCOL`,
 1 AS `CL_FLDDATALIGN`,
 1 AS `CL_FLDDATVALIGN`,
 1 AS `CL_FLDDATNOBR`,
 1 AS `CL_FLDHIDE`,
 1 AS `CL_FLDDATHIDE`,
 1 AS `CL_FLDDATMAND`,
 1 AS `CL_FLDDATDEFVAL`,
 1 AS `CL_FLDDATMULTVAL`,
 1 AS `CL_FLDDATMIN`,
 1 AS `CL_FLDDATMAX`,
 1 AS `CL_FLDDATCHRMIN`,
 1 AS `CL_FLDFORMAT_YN`,
 1 AS `CL_FLDFORMAT`,
 1 AS `CL_FLDDISPFMT_YN`,
 1 AS `CL_FLDDISPFMT`,
 1 AS `CL_FLDFRST_YN`,
 1 AS `CL_FLDFRSTYLE`,
 1 AS `CL_FLDDATFRST_YN`,
 1 AS `CL_FLDDATFRSTYLE`,
 1 AS `CL_FLDDATSEM_YN`,
 1 AS `CL_FLDDATSEM_BEF`,
 1 AS `CL_FLDDATSEM_AFT`,
 1 AS `CL_FLDDATDER_YN`,
 1 AS `CL_FLDDATDER_EXPR`,
 1 AS `CL_FLDLINE`,
 1 AS `CL_FLDCOLFM`,
 1 AS `CL_FLDCOLTO`,
 1 AS `CL_FLDDATLINE`,
 1 AS `CL_FLDDATCOLFM`,
 1 AS `CL_FLDDATCOLTO`,
 1 AS `CL_LOOKUP_YN`,
 1 AS `CL_LK_WP_ID`,
 1 AS `CL_LK_SCR_ID`,
 1 AS `CL_LK_FIELD_ID`,
 1 AS `CL_INP_HTMLOBJ`,
 1 AS `CL_CRDATE`,
 1 AS `CL_UPDDATE`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `em_user_forms_vw`
--

DROP TABLE IF EXISTS `em_user_forms_vw`;
/*!50001 DROP VIEW IF EXISTS `em_user_forms_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_user_forms_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_FORM_ID`,
 1 AS `CL_TBLORIENT`,
 1 AS `CL_TBLBORDER`,
 1 AS `CL_TBLWIDTH`,
 1 AS `CL_TBLBGCOLOR`,
 1 AS `CL_TBLCELLSP`,
 1 AS `CL_TBLCELLPADD`,
 1 AS `CL_TBLALIGN`,
 1 AS `CL_TBLVALIGN`,
 1 AS `CL_TBLSUBNM`,
 1 AS `CL_TBLFORMAT_YN`,
 1 AS `CL_TBLFORMAT`,
 1 AS `CL_TBLFRST_YN`,
 1 AS `CL_TBLFRSTYLE`,
 1 AS `CL_TBLSEM_YN`,
 1 AS `CL_TBLSEM_BEF`,
 1 AS `CL_TBLSEM_AFT`,
 1 AS `CL_RECSEM_BEF`,
 1 AS `CL_RECSEM_AFT`,
 1 AS `CL_FORM_NM`,
 1 AS `CL_FORM_ST`,
 1 AS `CL_CRDATE`,
 1 AS `CL_UPDDATE`,
 1 AS `CL_TBL_SKIP_FE`,
 1 AS `CL_TBL_SKIP_BE`,
 1 AS `CL_TBL_NO_SKIP_EMLIB`,
 1 AS `CL_TBL_SKIP_PARTS`,
 1 AS `CL_TBL_LABEL`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `em_user_genlic_addon`
--

DROP TABLE IF EXISTS `em_user_genlic_addon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_genlic_addon` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_ID` int NOT NULL,
  `CL_LIC_DESC` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LIC_TOT` int DEFAULT NULL,
  `CL_LIC_DBI` int DEFAULT NULL,
  `CL_LIC_GEN` int DEFAULT NULL,
  `CL_VALID_DAYS` int DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_genlic_addon`
--

LOCK TABLES `em_user_genlic_addon` WRITE;
/*!40000 ALTER TABLE `em_user_genlic_addon` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_genlic_addon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_id_seq`
--

DROP TABLE IF EXISTS `em_user_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_id_seq`
--

LOCK TABLES `em_user_id_seq` WRITE;
/*!40000 ALTER TABLE `em_user_id_seq` DISABLE KEYS */;
INSERT INTO `em_user_id_seq` VALUES (10001);
/*!40000 ALTER TABLE `em_user_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_prof`
--

DROP TABLE IF EXISTS `em_user_prof`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_prof` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_ID` int NOT NULL,
  `CL_REGSUB_LEV` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_ACT` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROF_OVR` varchar(3) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATEFMT_DIS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATEFMT_INP` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TIMEFMT_DIS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TIMEFMT_INP` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DTTM_DRPDN` varchar(25) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CURR_SYMB` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CURRFMT_DIS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CURRFMT_INP` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLTFMT_DIS` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLTFMT_INP` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LANGUAGE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TERRITORY` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TIMEZONE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CHARSET` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SORTORD` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_GUI_STR` varchar(400) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_ID`),
  KEY `EM_USER_PROF_IDX01` (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_prof`
--

LOCK TABLES `em_user_prof` WRITE;
/*!40000 ALTER TABLE `em_user_prof` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_prof` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = latin1 */ ;
/*!50003 SET character_set_results = latin1 */ ;
/*!50003 SET collation_connection  = latin1_swedish_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `TR_EM_USER_GENLIC_ADDON_ADD_PROMO` AFTER INSERT ON `em_user_prof` FOR EACH ROW BEGIN
	DECLARE P2 INT;
	IF (NEW.CL_USER NOT LIKE 'EMAPP%') THEN
	IF (NEW.CL_USER NOT LIKE 'EMMAIL%') THEN

	
	INSERT INTO EM_USER_GENLIC_ADDON ( 
	CL_USER,		
	CL_USER_ID,	
	CL_LIC_DESC,	
	CL_LIC_TOT,
	CL_LIC_DBI,
	CL_LIC_GEN,
	CL_VALID_DAYS,
	CL_CRBY_USER,	
	CL_CRDATE
	) VALUES (
	NEW.CL_USER,
	NEW.CL_USER_ID,	
	'Free-Beta-Promo',
	200,
	30,
	30,
	0,
	'PortalSecurity',	
	NEW.CL_CRDATE
	);
	END IF;
	END IF;
    END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `em_user_qry`
--

DROP TABLE IF EXISTS `em_user_qry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_qry` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_QRY_ID` int NOT NULL,
  `CL_LINE_NO` int DEFAULT NULL,
  `CL_QRY_SEL` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_ANDOR` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FIELD_DT_TYP` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_FLD_QUAL_BEG` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_FLD_QUAL_END` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FIELD_ID` int DEFAULT NULL,
  `CL_DATA_TYPE` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_OPR` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_VAL` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_VAL_QUAL_BEG` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_VAL_QUAL_END` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_CASE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_ORDBY` varchar(40) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_ORDBY_SO` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_OBY_QUAL_BEG` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_OBY_QUAL_END` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_LIMITROWS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_STAT` int DEFAULT NULL,
  `CL_QRY_ROWS` int DEFAULT NULL,
  `CL_FORM_ID` int DEFAULT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_NM` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_QRY_IDX01` (`CL_USER`,`CL_CATEG_ID`,`CL_QRY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_qry`
--

LOCK TABLES `em_user_qry` WRITE;
/*!40000 ALTER TABLE `em_user_qry` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_qry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `em_user_qry_unq_vw`
--

DROP TABLE IF EXISTS `em_user_qry_unq_vw`;
/*!50001 DROP VIEW IF EXISTS `em_user_qry_unq_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_user_qry_unq_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_QRY_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `em_user_sec`
--

DROP TABLE IF EXISTS `em_user_sec`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_sec` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_USER_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EMAIL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_FLG` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REGSUB_LEV` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_USER_SUB` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CATEG_ID` int DEFAULT NULL,
  `CL_DATA_GRP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_SUB` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_DATE` timestamp NULL DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR_OVR` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SEC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOCALE` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_STR` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_GR_CODE` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_AUTH_CODE` varchar(60) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_PAY` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_INFO` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`),
  KEY `EM_USER_SEC_IDX01` (`CL_USER`,`CL_REC_FLG`,`CL_USER_SUB`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_sec`
--

LOCK TABLES `em_user_sec` WRITE;
/*!40000 ALTER TABLE `em_user_sec` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_sec` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_sidest`
--

DROP TABLE IF EXISTS `em_user_sidest`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_sidest` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_SVC_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SVC_SUBTYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SVC_URL` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SVC_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SVC_APP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SCR_DEST` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SVC_MODE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_DEF` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_REC_STAT` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_sidest`
--

LOCK TABLES `em_user_sidest` WRITE;
/*!40000 ALTER TABLE `em_user_sidest` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_sidest` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_tag_icon`
--

DROP TABLE IF EXISTS `em_user_tag_icon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_tag_icon` (
  `CL_IC_ID` int NOT NULL,
  `CL_IC_GRP` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IC_CATEG` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IC_NAME` varchar(30) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IC_ALT` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IC_FILE` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_tag_icon`
--

LOCK TABLES `em_user_tag_icon` WRITE;
/*!40000 ALTER TABLE `em_user_tag_icon` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_tag_icon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_tag_tbl`
--

DROP TABLE IF EXISTS `em_user_tag_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_tag_tbl` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_WP_ID` int NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FORM_ID` int NOT NULL,
  `CL_TG_OPT` varchar(1000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_USER_SI` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_CATEG_ID` int DEFAULT NULL,
  `CL_TG_FORM_ID` int DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_TAG_TBL_IDX01` (`CL_USER`,`CL_TG_CATEG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_tag_tbl`
--

LOCK TABLES `em_user_tag_tbl` WRITE;
/*!40000 ALTER TABLE `em_user_tag_tbl` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_tag_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_tag_tbl_det`
--

DROP TABLE IF EXISTS `em_user_tag_tbl_det`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_tag_tbl_det` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_WP_ID` int NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FORM_ID` int NOT NULL,
  `CL_FIELD_ID` int DEFAULT NULL,
  `CL_TG_SRL` int DEFAULT NULL,
  `CL_TG_POS` int DEFAULT NULL,
  `CL_TG_OPT` varchar(1000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_USER_SI` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TG_CATEG_ID` int DEFAULT NULL,
  `CL_TG_FORM_ID` int DEFAULT NULL,
  `CL_TG_FIELD_ID` int DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_TAG_TBL_DET_IDX01` (`CL_USER`,`CL_TG_CATEG_ID`,`CL_TG_FIELD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_tag_tbl_det`
--

LOCK TABLES `em_user_tag_tbl_det` WRITE;
/*!40000 ALTER TABLE `em_user_tag_tbl_det` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_tag_tbl_det` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_tblfk`
--

DROP TABLE IF EXISTS `em_user_tblfk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_tblfk` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_FK_NO` int DEFAULT NULL,
  `CL_FK_ENABLE` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FIELD_ID` int DEFAULT NULL,
  `CL_FKTBL_ID` int DEFAULT NULL,
  `CL_FKFLD_ID` int DEFAULT NULL,
  `CL_FK_TYP` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_TBLFK_IDX01` (`CL_USER`,`CL_CATEG_ID`),
  KEY `EM_USER_TBLFK_IDX02` (`CL_USER`,`CL_FKTBL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_tblfk`
--

LOCK TABLES `em_user_tblfk` WRITE;
/*!40000 ALTER TABLE `em_user_tblfk` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_tblfk` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_type`
--

DROP TABLE IF EXISTS `em_user_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_type` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_ID` int NOT NULL,
  `CL_TYPE` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_ADV` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_IS_SU` varchar(1) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_type`
--

LOCK TABLES `em_user_type` WRITE;
/*!40000 ALTER TABLE `em_user_type` DISABLE KEYS */;
INSERT INTO `em_user_type` VALUES ('ADMIN',11,'Developer','Y','Y','2026-05-06 06:13:21','2026-05-06 06:13:21');
/*!40000 ALTER TABLE `em_user_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_user_webproj`
--

DROP TABLE IF EXISTS `em_user_webproj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_webproj` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_TBL_ID` int DEFAULT NULL,
  `CL_FORM_ID` int DEFAULT NULL,
  `CL_QRY_ID` int DEFAULT NULL,
  `CL_WP_ID` int DEFAULT NULL,
  `CL_SCREEN_ID` int DEFAULT NULL,
  `CL_SCREEN_ORD` int DEFAULT NULL,
  `CL_TITLE` varchar(155) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SUBTITLE` varchar(155) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_HOME_URL` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_HOME_TEXT` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PRNXT_POS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CMENU_POS` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CMENU_TEXT` varchar(2000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_WM_GUI_STR` varchar(300) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PRNXT_OPT` varchar(25) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_NEXT_TEXT` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PASSWD_PROT` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SCR_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_SCR_PASS` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INP_DISP_FLG` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_QRY_OPTION` varchar(25) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EXT_INT_FLG` varchar(15) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_KEY_WORDS` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PARAM_YN` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PARAM_SND` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PARAM_GET` varchar(500) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_EDT_FORM_ID` int DEFAULT NULL,
  `CL_BEFAFT_YN` varchar(10) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PG_BEF` mediumtext COLLATE utf8mb3_bin,
  `CL_PG_AFT` mediumtext COLLATE utf8mb3_bin,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  KEY `EM_USER_WEBPROJ_IDX01` (`CL_USER`,`CL_CATEG_ID`),
  KEY `EM_USER_WEBPROJ_IDX02` (`CL_WP_ID`,`CL_SCREEN_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_webproj`
--

LOCK TABLES `em_user_webproj` WRITE;
/*!40000 ALTER TABLE `em_user_webproj` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_webproj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `em_user_webproj_unq_vw`
--

DROP TABLE IF EXISTS `em_user_webproj_unq_vw`;
/*!50001 DROP VIEW IF EXISTS `em_user_webproj_unq_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_user_webproj_unq_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_WP_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `em_user_xref`
--

DROP TABLE IF EXISTS `em_user_xref`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_user_xref` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_VAL_ID` int NOT NULL,
  `RecId` int DEFAULT NULL,
  `ParentId` int DEFAULT NULL,
  `Type` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `TypeName` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `IsInbox` varchar(5) COLLATE utf8mb3_bin DEFAULT NULL,
  `RecLevel` int DEFAULT NULL,
  `GroupName` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `RecUser` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `NameUser` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `Email` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `AffEmail` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `AffInfo` mediumtext COLLATE utf8mb3_bin,
  `AllowQryBy` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `SubscrType` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `SubscrStat` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `SubscrCountLev` int DEFAULT NULL,
  `SubscrCountTot` int DEFAULT NULL,
  `Rating` int DEFAULT NULL,
  `Votes` int DEFAULT NULL,
  `RequestStat` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `RecStatus` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `SysStat` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CreatedBy` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CreatedDate` timestamp NULL DEFAULT NULL,
  `UpdatedBy` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `UpdatedDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_VAL_ID`),
  KEY `EM_USER_XREF_IDX01` (`RecUser`),
  KEY `EM_USER_XREF_IDX02` (`ParentId`),
  KEY `EM_USER_XREF_IDX03` (`RecId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_user_xref`
--

LOCK TABLES `em_user_xref` WRITE;
/*!40000 ALTER TABLE `em_user_xref` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_user_xref` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_val_id_seq`
--

DROP TABLE IF EXISTS `em_val_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_val_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_val_id_seq`
--

LOCK TABLES `em_val_id_seq` WRITE;
/*!40000 ALTER TABLE `em_val_id_seq` DISABLE KEYS */;
INSERT INTO `em_val_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_val_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_wp_id_seq`
--

DROP TABLE IF EXISTS `em_wp_id_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_wp_id_seq` (
  `CL_ID` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_wp_id_seq`
--

LOCK TABLES `em_wp_id_seq` WRITE;
/*!40000 ALTER TABLE `em_wp_id_seq` DISABLE KEYS */;
INSERT INTO `em_wp_id_seq` VALUES (100001);
/*!40000 ALTER TABLE `em_wp_id_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_ws_proj`
--

DROP TABLE IF EXISTS `em_ws_proj`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_ws_proj` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_USER_SEC_ID` int NOT NULL,
  `CL_PROJ_TYPE` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_PROJ_NAME` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_FLD_EXCL_FILE` int DEFAULT NULL,
  `CL_DATE_FMT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TIME_FMT` varchar(200) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_LOCALE` varchar(100) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_INCL_TBL_SQL` int DEFAULT NULL,
  `CL_TGT_DB` varchar(50) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_TGT_DB_SRC_ID` int DEFAULT NULL,
  `CL_APPLY_TBL_CONF` int DEFAULT NULL,
  `CL_APPLY_TBL_REL` int DEFAULT NULL,
  `CL_CONF_VIA_NAMES` int DEFAULT NULL,
  `CL_CONF_STR` varchar(4000) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_USER_SEC_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_ws_proj`
--

LOCK TABLES `em_ws_proj` WRITE;
/*!40000 ALTER TABLE `em_ws_proj` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_ws_proj` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `em_ws_proj_rel`
--

DROP TABLE IF EXISTS `em_ws_proj_rel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `em_ws_proj_rel` (
  `CL_USER` varchar(20) COLLATE utf8mb3_bin NOT NULL,
  `CL_CATEG_ID` int NOT NULL,
  `CL_REL_ID` int NOT NULL,
  `CL_LEVEL` int NOT NULL,
  `CL_QRY_ID` int DEFAULT NULL,
  `CL_CRBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_CRDATE` timestamp NULL DEFAULT NULL,
  `CL_UPDBY_USER` varchar(20) COLLATE utf8mb3_bin DEFAULT NULL,
  `CL_UPDDATE` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`CL_USER`,`CL_CATEG_ID`,`CL_REL_ID`,`CL_LEVEL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `em_ws_proj_rel`
--

LOCK TABLES `em_ws_proj_rel` WRITE;
/*!40000 ALTER TABLE `em_ws_proj_rel` DISABLE KEYS */;
/*!40000 ALTER TABLE `em_ws_proj_rel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `em_ws_proj_rel_all_vw`
--

DROP TABLE IF EXISTS `em_ws_proj_rel_all_vw`;
/*!50001 DROP VIEW IF EXISTS `em_ws_proj_rel_all_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_ws_proj_rel_all_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_REL_ID`,
 1 AS `CL_REL_TYPE`,
 1 AS `CL_TOT_LEV`,
 1 AS `CL_QRY1_ID`,
 1 AS `CL_QRY2_ID`,
 1 AS `CL_QRY3_ID`,
 1 AS `CL_QRY4_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `em_ws_proj_rel_vw`
--

DROP TABLE IF EXISTS `em_ws_proj_rel_vw`;
/*!50001 DROP VIEW IF EXISTS `em_ws_proj_rel_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `em_ws_proj_rel_vw` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_CATEG_ID`,
 1 AS `CL_REL_ID`,
 1 AS `CL_REL_TYPE`,
 1 AS `CL_TOT_LEV`,
 1 AS `CL_QRY1_ID`,
 1 AS `CL_QRY2_ID`,
 1 AS `CL_QRY3_ID`,
 1 AS `CL_QRY4_ID`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `networkstousers`
--

DROP TABLE IF EXISTS `networkstousers`;
/*!50001 DROP VIEW IF EXISTS `networkstousers`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `networkstousers` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_VAL_ID`,
 1 AS `RecId`,
 1 AS `ParentId`,
 1 AS `Type`,
 1 AS `TypeName`,
 1 AS `IsInbox`,
 1 AS `RecLevel`,
 1 AS `GroupName`,
 1 AS `RecUser`,
 1 AS `NameUser`,
 1 AS `Email`,
 1 AS `AffEmail`,
 1 AS `AffInfo`,
 1 AS `AllowQryBy`,
 1 AS `SubscrType`,
 1 AS `SubscrStat`,
 1 AS `SubscrCountLev`,
 1 AS `SubscrCountTot`,
 1 AS `Rating`,
 1 AS `Votes`,
 1 AS `RequestStat`,
 1 AS `RecStatus`,
 1 AS `SysStat`,
 1 AS `CreatedBy`,
 1 AS `CreatedDate`,
 1 AS `UpdatedBy`,
 1 AS `UpdatedDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `networkstousersqrypubuser`
--

DROP TABLE IF EXISTS `networkstousersqrypubuser`;
/*!50001 DROP VIEW IF EXISTS `networkstousersqrypubuser`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `networkstousersqrypubuser` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_VAL_ID`,
 1 AS `RecId`,
 1 AS `ParentId`,
 1 AS `Type`,
 1 AS `TypeName`,
 1 AS `IsInbox`,
 1 AS `RecLevel`,
 1 AS `GroupName`,
 1 AS `RecUser`,
 1 AS `NameUser`,
 1 AS `Email`,
 1 AS `AffEmail`,
 1 AS `AffInfo`,
 1 AS `AllowQryBy`,
 1 AS `SubscrType`,
 1 AS `SubscrStat`,
 1 AS `SubscrCountLev`,
 1 AS `SubscrCountTot`,
 1 AS `Rating`,
 1 AS `Votes`,
 1 AS `RequestStat`,
 1 AS `RecStatus`,
 1 AS `SysStat`,
 1 AS `CreatedBy`,
 1 AS `CreatedDate`,
 1 AS `UpdatedBy`,
 1 AS `UpdatedDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `networkstousersqryreguser`
--

DROP TABLE IF EXISTS `networkstousersqryreguser`;
/*!50001 DROP VIEW IF EXISTS `networkstousersqryreguser`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `networkstousersqryreguser` AS SELECT 
 1 AS `CL_USER`,
 1 AS `CL_VAL_ID`,
 1 AS `RecId`,
 1 AS `ParentId`,
 1 AS `Type`,
 1 AS `TypeName`,
 1 AS `IsInbox`,
 1 AS `RecLevel`,
 1 AS `GroupName`,
 1 AS `RecUser`,
 1 AS `NameUser`,
 1 AS `Email`,
 1 AS `AffEmail`,
 1 AS `AffInfo`,
 1 AS `AllowQryBy`,
 1 AS `SubscrType`,
 1 AS `SubscrStat`,
 1 AS `SubscrCountLev`,
 1 AS `SubscrCountTot`,
 1 AS `Rating`,
 1 AS `Votes`,
 1 AS `RequestStat`,
 1 AS `RecStatus`,
 1 AS `SysStat`,
 1 AS `CreatedBy`,
 1 AS `CreatedDate`,
 1 AS `UpdatedBy`,
 1 AS `UpdatedDate`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `em_user_forms_fld_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_user_forms_fld_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_user_forms_fld_vw` AS select `em_user_forms_fld`.`CL_USER` AS `CL_USER`,`em_user_forms_fld`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`em_user_forms_fld`.`CL_FORM_ID` AS `CL_FORM_ID`,`em_user_forms_fld`.`CL_FIELD_ID` AS `CL_FIELD_ID`,`em_user_forms_fld`.`CL_FLDBLLNBEF` AS `CL_FLDBLLNBEF`,`em_user_forms_fld`.`CL_FLDSTPRLN` AS `CL_FLDSTPRLN`,`em_user_forms_fld`.`CL_FLDWIDTH` AS `CL_FLDWIDTH`,`em_user_forms_fld`.`CL_FLDBOLD` AS `CL_FLDBOLD`,`em_user_forms_fld`.`CL_FLDITA` AS `CL_FLDITA`,`em_user_forms_fld`.`CL_FLDUNDR` AS `CL_FLDUNDR`,`em_user_forms_fld`.`CL_FLDBGCOLOR` AS `CL_FLDBGCOLOR`,`em_user_forms_fld`.`CL_FLDFNTNM` AS `CL_FLDFNTNM`,`em_user_forms_fld`.`CL_FLDFNTSIZE` AS `CL_FLDFNTSIZE`,`em_user_forms_fld`.`CL_FLDFNTCOL` AS `CL_FLDFNTCOL`,`em_user_forms_fld`.`CL_FLDALIGN` AS `CL_FLDALIGN`,`em_user_forms_fld`.`CL_FLDVALIGN` AS `CL_FLDVALIGN`,`em_user_forms_fld`.`CL_FLDNOBR` AS `CL_FLDNOBR`,`em_user_forms_fld`.`CL_FLDDATBOLD` AS `CL_FLDDATBOLD`,`em_user_forms_fld`.`CL_FLDDATITA` AS `CL_FLDDATITA`,`em_user_forms_fld`.`CL_FLDDATUNDR` AS `CL_FLDDATUNDR`,`em_user_forms_fld`.`CL_FLDDATBGCOLOR` AS `CL_FLDDATBGCOLOR`,`em_user_forms_fld`.`CL_FLDDATFNTNM` AS `CL_FLDDATFNTNM`,`em_user_forms_fld`.`CL_FLDDATFNTSIZE` AS `CL_FLDDATFNTSIZE`,`em_user_forms_fld`.`CL_FLDDATFNTCOL` AS `CL_FLDDATFNTCOL`,`em_user_forms_fld`.`CL_FLDDATALIGN` AS `CL_FLDDATALIGN`,`em_user_forms_fld`.`CL_FLDDATVALIGN` AS `CL_FLDDATVALIGN`,`em_user_forms_fld`.`CL_FLDDATNOBR` AS `CL_FLDDATNOBR`,`em_user_forms_fld`.`CL_FLDHIDE` AS `CL_FLDHIDE`,`em_user_forms_fld`.`CL_FLDDATHIDE` AS `CL_FLDDATHIDE`,`em_user_forms_fld`.`CL_FLDDATMAND` AS `CL_FLDDATMAND`,`em_user_forms_fld`.`CL_FLDDATDEFVAL` AS `CL_FLDDATDEFVAL`,`em_user_forms_fld`.`CL_FLDDATMULTVAL` AS `CL_FLDDATMULTVAL`,`em_user_forms_fld`.`CL_FLDDATMIN` AS `CL_FLDDATMIN`,`em_user_forms_fld`.`CL_FLDDATMAX` AS `CL_FLDDATMAX`,`em_user_forms_fld`.`CL_FLDDATCHRMIN` AS `CL_FLDDATCHRMIN`,`em_user_forms_fld`.`CL_FLDFORMAT_YN` AS `CL_FLDFORMAT_YN`,`em_user_forms_fld`.`CL_FLDFORMAT` AS `CL_FLDFORMAT`,`em_user_forms_fld`.`CL_FLDDISPFMT_YN` AS `CL_FLDDISPFMT_YN`,`em_user_forms_fld`.`CL_FLDDISPFMT` AS `CL_FLDDISPFMT`,`em_user_forms_fld`.`CL_FLDFRST_YN` AS `CL_FLDFRST_YN`,`em_user_forms_fld`.`CL_FLDFRSTYLE` AS `CL_FLDFRSTYLE`,`em_user_forms_fld`.`CL_FLDDATFRST_YN` AS `CL_FLDDATFRST_YN`,`em_user_forms_fld`.`CL_FLDDATFRSTYLE` AS `CL_FLDDATFRSTYLE`,`em_user_forms_fld`.`CL_FLDDATSEM_YN` AS `CL_FLDDATSEM_YN`,`em_user_forms_fld`.`CL_FLDDATSEM_BEF` AS `CL_FLDDATSEM_BEF`,`em_user_forms_fld`.`CL_FLDDATSEM_AFT` AS `CL_FLDDATSEM_AFT`,`em_user_forms_fld`.`CL_FLDDATDER_YN` AS `CL_FLDDATDER_YN`,`em_user_forms_fld`.`CL_FLDDATDER_EXPR` AS `CL_FLDDATDER_EXPR`,`em_user_forms_fld`.`CL_FLDLINE` AS `CL_FLDLINE`,`em_user_forms_fld`.`CL_FLDCOLFM` AS `CL_FLDCOLFM`,`em_user_forms_fld`.`CL_FLDCOLTO` AS `CL_FLDCOLTO`,`em_user_forms_fld`.`CL_FLDDATLINE` AS `CL_FLDDATLINE`,`em_user_forms_fld`.`CL_FLDDATCOLFM` AS `CL_FLDDATCOLFM`,`em_user_forms_fld`.`CL_FLDDATCOLTO` AS `CL_FLDDATCOLTO`,`em_user_forms_fld`.`CL_LOOKUP_YN` AS `CL_LOOKUP_YN`,`em_user_forms_fld`.`CL_LK_WP_ID` AS `CL_LK_WP_ID`,`em_user_forms_fld`.`CL_LK_SCR_ID` AS `CL_LK_SCR_ID`,`em_user_forms_fld`.`CL_LK_FIELD_ID` AS `CL_LK_FIELD_ID`,`em_user_forms_fld`.`CL_INP_HTMLOBJ` AS `CL_INP_HTMLOBJ`,`em_user_forms_fld`.`CL_CRDATE` AS `CL_CRDATE`,`em_user_forms_fld`.`CL_UPDDATE` AS `CL_UPDDATE` from `em_user_forms_fld` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `em_user_forms_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_user_forms_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_user_forms_vw` AS select `em_user_forms`.`CL_USER` AS `CL_USER`,`em_user_forms`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`em_user_forms`.`CL_FORM_ID` AS `CL_FORM_ID`,`em_user_forms`.`CL_TBLORIENT` AS `CL_TBLORIENT`,`em_user_forms`.`CL_TBLBORDER` AS `CL_TBLBORDER`,`em_user_forms`.`CL_TBLWIDTH` AS `CL_TBLWIDTH`,`em_user_forms`.`CL_TBLBGCOLOR` AS `CL_TBLBGCOLOR`,`em_user_forms`.`CL_TBLCELLSP` AS `CL_TBLCELLSP`,`em_user_forms`.`CL_TBLCELLPADD` AS `CL_TBLCELLPADD`,`em_user_forms`.`CL_TBLALIGN` AS `CL_TBLALIGN`,`em_user_forms`.`CL_TBLVALIGN` AS `CL_TBLVALIGN`,`em_user_forms`.`CL_TBLSUBNM` AS `CL_TBLSUBNM`,`em_user_forms`.`CL_TBLFORMAT_YN` AS `CL_TBLFORMAT_YN`,`em_user_forms`.`CL_TBLFORMAT` AS `CL_TBLFORMAT`,`em_user_forms`.`CL_TBLFRST_YN` AS `CL_TBLFRST_YN`,`em_user_forms`.`CL_TBLFRSTYLE` AS `CL_TBLFRSTYLE`,`em_user_forms`.`CL_TBLSEM_YN` AS `CL_TBLSEM_YN`,`em_user_forms`.`CL_TBLSEM_BEF` AS `CL_TBLSEM_BEF`,`em_user_forms`.`CL_TBLSEM_AFT` AS `CL_TBLSEM_AFT`,`em_user_forms`.`CL_RECSEM_BEF` AS `CL_RECSEM_BEF`,`em_user_forms`.`CL_RECSEM_AFT` AS `CL_RECSEM_AFT`,`em_user_forms`.`CL_FORM_NM` AS `CL_FORM_NM`,`em_user_forms`.`CL_FORM_ST` AS `CL_FORM_ST`,`em_user_forms`.`CL_CRDATE` AS `CL_CRDATE`,`em_user_forms`.`CL_UPDDATE` AS `CL_UPDDATE`,`em_user_forms`.`CL_TBL_SKIP_FE` AS `CL_TBL_SKIP_FE`,`em_user_forms`.`CL_TBL_SKIP_BE` AS `CL_TBL_SKIP_BE`,`em_user_forms`.`CL_TBL_NO_SKIP_EMLIB` AS `CL_TBL_NO_SKIP_EMLIB`,`em_user_forms`.`CL_TBL_SKIP_PARTS` AS `CL_TBL_SKIP_PARTS`,`em_user_forms`.`CL_TBL_LABEL` AS `CL_TBL_LABEL` from `em_user_forms` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `em_user_qry_unq_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_user_qry_unq_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_user_qry_unq_vw` AS select distinct `em_user_qry`.`CL_USER` AS `CL_USER`,`em_user_qry`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`em_user_qry`.`CL_QRY_ID` AS `CL_QRY_ID` from `em_user_qry` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `em_user_webproj_unq_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_user_webproj_unq_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_user_webproj_unq_vw` AS select distinct `em_user_webproj`.`CL_USER` AS `CL_USER`,`em_user_webproj`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`em_user_webproj`.`CL_WP_ID` AS `CL_WP_ID` from `em_user_webproj` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `em_ws_proj_rel_all_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_ws_proj_rel_all_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_ws_proj_rel_all_vw` AS select `m`.`CL_USER` AS `CL_USER`,`m`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`m`.`CL_REL_ID` AS `CL_REL_ID`,'Multi' AS `CL_REL_TYPE`,count(`m`.`CL_LEVEL`) AS `CL_TOT_LEV`,max((case when (`m`.`CL_LEVEL` = 1) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY1_ID`,max((case when (`m`.`CL_LEVEL` = 2) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY2_ID`,max((case when (`m`.`CL_LEVEL` = 3) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY3_ID`,max((case when (`m`.`CL_LEVEL` = 4) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY4_ID` from `em_ws_proj_rel` `m` group by `m`.`CL_USER`,`m`.`CL_CATEG_ID`,`m`.`CL_REL_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `em_ws_proj_rel_vw`
--

/*!50001 DROP VIEW IF EXISTS `em_ws_proj_rel_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `em_ws_proj_rel_vw` AS select `m`.`CL_USER` AS `CL_USER`,`m`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`m`.`CL_REL_ID` AS `CL_REL_ID`,'Multi' AS `CL_REL_TYPE`,count(`m`.`CL_LEVEL`) AS `CL_TOT_LEV`,max((case when (`m`.`CL_LEVEL` = 1) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY1_ID`,max((case when (`m`.`CL_LEVEL` = 2) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY2_ID`,max((case when (`m`.`CL_LEVEL` = 3) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY3_ID`,max((case when (`m`.`CL_LEVEL` = 4) then `m`.`CL_QRY_ID` else 0 end)) AS `CL_QRY4_ID` from `em_ws_proj_rel` `m` group by `m`.`CL_USER`,`m`.`CL_CATEG_ID`,`m`.`CL_REL_ID` having (count(`m`.`CL_LEVEL`) > 1) union all select `c`.`CL_USER` AS `CL_USER`,`c`.`CL_CATEG_ID` AS `CL_CATEG_ID`,`c`.`CL_QRY_ID` AS `CL_QRY_ID`,'' AS `CL_REL_TYPE`,1 AS `CL_TOT_LEV`,`c`.`CL_QRY_ID` AS `CL_QRY_ID`,0 AS `0`,0 AS `0`,0 AS `0` from `em_user_qry` `c` where ((`c`.`CL_QRY_SEL` = 'Cpy') and (`c`.`CL_USER`,`c`.`CL_CATEG_ID`,`c`.`CL_QRY_ID`) in (select `k`.`CL_USER`,`k`.`CL_CATEG_ID`,min(`k`.`CL_QRY_ID`) from `em_user_qry` `k` where ((`k`.`CL_QRY_SEL` = 'Cpy') and (`c`.`CL_USER` = `k`.`CL_USER`) and (`c`.`CL_CATEG_ID` = `k`.`CL_CATEG_ID`) and (`k`.`CL_CATEG_ID` <> `k`.`CL_LINE_NO`)) group by `k`.`CL_USER`,`k`.`CL_CATEG_ID`)) group by `c`.`CL_USER`,`c`.`CL_CATEG_ID`,`c`.`CL_QRY_ID` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `networkstousers`
--

/*!50001 DROP VIEW IF EXISTS `networkstousers`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `networkstousers` AS select `em_user_xref`.`CL_USER` AS `CL_USER`,`em_user_xref`.`CL_VAL_ID` AS `CL_VAL_ID`,`em_user_xref`.`RecId` AS `RecId`,`em_user_xref`.`ParentId` AS `ParentId`,`em_user_xref`.`Type` AS `Type`,`em_user_xref`.`TypeName` AS `TypeName`,`em_user_xref`.`IsInbox` AS `IsInbox`,`em_user_xref`.`RecLevel` AS `RecLevel`,`em_user_xref`.`GroupName` AS `GroupName`,`em_user_xref`.`RecUser` AS `RecUser`,`em_user_xref`.`NameUser` AS `NameUser`,`em_user_xref`.`Email` AS `Email`,`em_user_xref`.`AffEmail` AS `AffEmail`,`em_user_xref`.`AffInfo` AS `AffInfo`,`em_user_xref`.`AllowQryBy` AS `AllowQryBy`,`em_user_xref`.`SubscrType` AS `SubscrType`,`em_user_xref`.`SubscrStat` AS `SubscrStat`,`em_user_xref`.`SubscrCountLev` AS `SubscrCountLev`,`em_user_xref`.`SubscrCountTot` AS `SubscrCountTot`,`em_user_xref`.`Rating` AS `Rating`,`em_user_xref`.`Votes` AS `Votes`,`em_user_xref`.`RequestStat` AS `RequestStat`,`em_user_xref`.`RecStatus` AS `RecStatus`,`em_user_xref`.`SysStat` AS `SysStat`,`em_user_xref`.`CreatedBy` AS `CreatedBy`,`em_user_xref`.`CreatedDate` AS `CreatedDate`,`em_user_xref`.`UpdatedBy` AS `UpdatedBy`,`em_user_xref`.`UpdatedDate` AS `UpdatedDate` from `em_user_xref` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `networkstousersqrypubuser`
--

/*!50001 DROP VIEW IF EXISTS `networkstousersqrypubuser`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `networkstousersqrypubuser` AS select `em_user_xref`.`CL_USER` AS `CL_USER`,`em_user_xref`.`CL_VAL_ID` AS `CL_VAL_ID`,`em_user_xref`.`RecId` AS `RecId`,`em_user_xref`.`ParentId` AS `ParentId`,`em_user_xref`.`Type` AS `Type`,`em_user_xref`.`TypeName` AS `TypeName`,`em_user_xref`.`IsInbox` AS `IsInbox`,`em_user_xref`.`RecLevel` AS `RecLevel`,`em_user_xref`.`GroupName` AS `GroupName`,`em_user_xref`.`RecUser` AS `RecUser`,`em_user_xref`.`NameUser` AS `NameUser`,`em_user_xref`.`Email` AS `Email`,`em_user_xref`.`AffEmail` AS `AffEmail`,`em_user_xref`.`AffInfo` AS `AffInfo`,`em_user_xref`.`AllowQryBy` AS `AllowQryBy`,`em_user_xref`.`SubscrType` AS `SubscrType`,`em_user_xref`.`SubscrStat` AS `SubscrStat`,`em_user_xref`.`SubscrCountLev` AS `SubscrCountLev`,`em_user_xref`.`SubscrCountTot` AS `SubscrCountTot`,`em_user_xref`.`Rating` AS `Rating`,`em_user_xref`.`Votes` AS `Votes`,`em_user_xref`.`RequestStat` AS `RequestStat`,`em_user_xref`.`RecStatus` AS `RecStatus`,`em_user_xref`.`SysStat` AS `SysStat`,`em_user_xref`.`CreatedBy` AS `CreatedBy`,`em_user_xref`.`CreatedDate` AS `CreatedDate`,`em_user_xref`.`UpdatedBy` AS `UpdatedBy`,`em_user_xref`.`UpdatedDate` AS `UpdatedDate` from `em_user_xref` where (`em_user_xref`.`AllowQryBy` = 'Public') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `networkstousersqryreguser`
--

/*!50001 DROP VIEW IF EXISTS `networkstousersqryreguser`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = latin1 */;
/*!50001 SET character_set_results     = latin1 */;
/*!50001 SET collation_connection      = latin1_swedish_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `networkstousersqryreguser` AS select `em_user_xref`.`CL_USER` AS `CL_USER`,`em_user_xref`.`CL_VAL_ID` AS `CL_VAL_ID`,`em_user_xref`.`RecId` AS `RecId`,`em_user_xref`.`ParentId` AS `ParentId`,`em_user_xref`.`Type` AS `Type`,`em_user_xref`.`TypeName` AS `TypeName`,`em_user_xref`.`IsInbox` AS `IsInbox`,`em_user_xref`.`RecLevel` AS `RecLevel`,`em_user_xref`.`GroupName` AS `GroupName`,`em_user_xref`.`RecUser` AS `RecUser`,`em_user_xref`.`NameUser` AS `NameUser`,`em_user_xref`.`Email` AS `Email`,`em_user_xref`.`AffEmail` AS `AffEmail`,`em_user_xref`.`AffInfo` AS `AffInfo`,`em_user_xref`.`AllowQryBy` AS `AllowQryBy`,`em_user_xref`.`SubscrType` AS `SubscrType`,`em_user_xref`.`SubscrStat` AS `SubscrStat`,`em_user_xref`.`SubscrCountLev` AS `SubscrCountLev`,`em_user_xref`.`SubscrCountTot` AS `SubscrCountTot`,`em_user_xref`.`Rating` AS `Rating`,`em_user_xref`.`Votes` AS `Votes`,`em_user_xref`.`RequestStat` AS `RequestStat`,`em_user_xref`.`RecStatus` AS `RecStatus`,`em_user_xref`.`SysStat` AS `SysStat`,`em_user_xref`.`CreatedBy` AS `CreatedBy`,`em_user_xref`.`CreatedDate` AS `CreatedDate`,`em_user_xref`.`UpdatedBy` AS `UpdatedBy`,`em_user_xref`.`UpdatedDate` AS `UpdatedDate` from `em_user_xref` where (`em_user_xref`.`AllowQryBy` = 'RegUser') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-06  6:15:42

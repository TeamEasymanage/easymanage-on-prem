#!/bin/bash

set -e

echo "Begin ... init_env.sh ..."

# echo "1 $MYSQL_ROOT_PASSWORD"
echo "2 EMDB_DATABASE: $EMDB_DATABASE"
echo "3 EMDB_USER: $EMDB_USER"
#echo "4 $EMDB_PASSWORD"

echo "Replace env var with values in em_param ... "

sed "s/user=emadb/user=$EMDB_USER/g" /usr/local/tomcat/webapps/em/WEB-INF/classes/em_param1_en_US.properties | \
  sed "s/password=emadb/password=$EMDB_PASSWORD/g" | \
  sed "s/em_db\:3306\/EMDB/em_db\:$EMINDB_PORT\/$EMDB_DATABASE/g" > /usr/local/tomcat/webapps/em/WEB-INF/classes/em_param_en_US.properties

cat /usr/local/tomcat/webapps/em/WEB-INF/classes/em_param_en_US.properties | grep -F "em.db.mysql"

echo "Done ... init_env.sh ..."

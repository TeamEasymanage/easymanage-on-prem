<%
		app_run = 1;
%>
<%@ include file="getting_started.jsp" %>


<%@ include file="jsp/BaseEmPrtl.jsp" %>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * All rights reserved.
 */
-->

<%@ include file="pre_dn1_html.jsp" %>

<TITLE><%= TitleInb %> : Help : About </TITLE>

<%@ include file="pre_dn2_html.jsp" %>


<br>
<TABLE BORDER=0>
<TR>


<TD valign="Top" width="22%">

	
</td>


<TD valign="top" width="100%" >

	<table cellpadding="2" cellspacing="1" border="0" width="100%">
		<tr align="Left">
		<td bgcolor="#3985b5">
		<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2" color="White">
		 <b> About EasyManage Platform (EM WebPlus Suite) </b></font>
		</td>
		</tr>
	</table>
        


<p>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2">
<b>EasyManage Platform (EM WebPlus Suite Version 5.0)</b>
</FONT>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="1">
(Build Info: See <A HREF="ReleaseNotes.txt">ReleaseNotes.txt</A>)
<br><br>
</FONT>
<FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2">

<!-- A HREF="http://www.EasyManage.com"><IMG ALT="EasyManage.com" SRC="/<%=usrproj%>/emlogo.jpg" BORDER=0></A -->
				<span id="logo" style="margin-top: 7px; width: 60px;"> <img src="/<%=usrproj%>/emlogonew.png" style="height: 35px; width: 30px;" alt="EasyManage" > </span>
<br>
<br>
Copyright (c) 2026 <A HREF="http://www.EasyManage.com">EasyManage.com</A>
 All Rights Reserved.
<br>

</FONT>

<br>
<P><FONT FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="1">

<b>Trademarks</b>
<br>All trademarks are acknowledged and are properties of the 
respective owners. The software and documentation makes reference 
to company names 
and product names which may be trademarks for 
identification purposes only.
<br><br>

</font>



</td><td>



</td>
</tr>
</table>


<!-- Footer -->
<%@ include file="post_dn_html.jsp" %>

</BODY>
</HTML>



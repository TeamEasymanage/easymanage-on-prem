<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%>
<%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="jsp/BaseEmJsp.jsp" %>

<jsp:useBean id="mo" scope="page" class="em.My_opt" />
<%
	String isAP = "";
	String isAppPref = "";

	if (app_run == 1 ) { 
		mo.setApFlg();
		isAP = "AP";
		isAppPref = "App";
	}
%>
<%
	mo.processRequest(request, response);
	get_gui_str(mo.gui_str);


%>
<%-- check valid sign-in --%>
<%	emerr = mo.emerr;
	valid_login = mo.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="jsp/no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<TITLE><%= TitleInb %> : Manage Apps | Create New App Info</TITLE>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 4;
	mnu2_sel = 1;
	String usrnm = mo.usrnm;
	usrnm_as = mo.usrnm_as;
	usrnm_si = mo.usrnm_si;
	datagrp = mo.datagrp;

%>
<%@ include file="jsp/pre_dn_sm.jsp" %>

	<%= bfont %> 
			<b>Manage Apps <br><br>
			Create New App Information : Please follow below notes to create new app : 
			<span class="glyphicon glyphicon-circle-arrow-right" title="Start Here"></span>
			</b></font><br><br>

	<%= bfont %> (For more information, please follow <b>Getting Started Guide  
			<span class="glyphicon glyphicon-circle-arrow-right" title="Start Here"></span>
			</b>) </font><br><br>


  <p><%= bfont %><b>For Creating New App For "Contact or Groups"</b></font></p>

  <!----------------------------------------------------------------->
  <p><%= bfont %>Contacts & Groups</font></p>
  <p>
  <a href="#npl_set" class="btn btn-xs btn-info" data-toggle="collapse">
  Seting up Contacts & Groups
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="npl_set" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Add Contact : Go To "My Apps" &rArr; "New Contact/Group"
	<p> Add Group : Same as above (Select Type as Group)
	<p> Add Group Members : Go To "My Apps" &rArr; "List Contacts" &rArr; For particular Group listed : "Members" &rArr; "Create New Record" 

	</font>

  </div>

  </p><p>
  <a href="#npl_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Creating App For Contacts & Groups
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="npl_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Create App : Go To "My Apps" &rArr; "List Contacts" &rArr; For particular Contact or Group listed : "New Apps"
	<p> Set App Prop : Go To "My Apps" &rArr; "List My Apps" &rArr; For particular App listed : "App Properties"
	<p> Publish App  as IApp : Go To "My Apps" &rArr; "List My Apps" &rArr; For particular App listed : "Publish IApp" <br>
		<font size=1>Note: All of this App's assignments to other contacts/groups (and public as well) will become "IApp" Immutable App (Read-Only mode).
		</font>
	</font>

   </div>

  <p><%= bfont %><b>For Creating New Public (Global or Location) App "Available to ALL Signed-in users"</b></font></p>

  <!----------------------------------------------------------------->
  <p><%= bfont %>Public Apps</font></p>
  <a href="#emp_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Creating Public Apps & Stories
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="emp_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Create Global Public App : Go To "Public Apps" &rArr; "New Global App"
	<p> Create Location Public App : Go To "Public Apps" &rArr; "New/Assign Location App"
	<p> Set App Prop : Go To "Public Apps" &rArr; For particular App listed : "[EMAPPnnnnn] App Properties"
	<p> Publish App  as IApp: Go To "Public Apps" &rArr; For particular App listed : "Publish IApp" <br>
		<font size=1>Note: All of this App's assignments to other contacts/groups (and public as well) will become "IApp" Immutable App (Read-Only mode).
		</font>
	</font>

   </div>


<%@ include file="jsp/post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

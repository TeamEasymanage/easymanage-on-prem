<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<html>
<%@ include file="/jsp/BaseEmJsp.jsp" %>
<%

%>

<head>
<title> <%=TitleInb%> Custom View Show </title>
</head>
<%
	String isAU = "";
	if (app_usr == 1) {
		isAU = "AU";
	}
	String tm_now = Long.toString(new java.util.Date().getTime());
	String usrnm = request.getParameter("usrnm");

	String SendToUrlPref = "/"+usrproj+"/jsp/dn/"+isAU+"";
	String SendToUrlPrefCust = "/"+usrproj+"/custom/jsp/"+isAU+"";
	String SendToUrlSuf = "?usrnm="+usrnm+"&tm_now="+tm_now;

	String SendToUrlSiteSuf = "?tm_now="+tm_now;

	//String SendToUrl = "/"+usrproj+"/jsp/dn/"+isAU+"EmDshFramesLev2.jsp?usrnm="+usrnm+"&tm_now="+tm_now;
	String tgt_str = "TARGET=\"EMMAIN\"";
	//String tgt1_str = "TARGET=\"EMMAINL0\"";

	String view = "" + request.getParameter("view");

	String[][] viewList = {
				  { "Coming Soon...", "cmng" }

			/*********			
				  { "Social Networking - Student", "NetwStud" }
				, { "Social Networking - Everyone", "NetwAll" }
				, { "Social Networking - Business", "NetwBus" }
				, { "Social Networking - Family", "NetwFam" }
				, { "Social Networking - Dating", "NetwDtg" }
				, { "Blogger", "Blog" }
				, { "Groups", "grp" }
				, { "Forums", "Forum" }
				, { "Communities", "comm" }
				, { "Opinions", "opn" }
				, { "Polls", "pol" }
				, { "Voting", "vot" }
				, { "Feedback", "feed" }
				, { "Reviews", "revw" }
				, { "Questions Q&A", "que" }
				, { "Photos", "photo" }
				, { "Videos", "vid" }
				, { "Music", "mus" }
				, { "Techies & Technology Community", "NetwTech" }
				, { "Knowledge Networking Community", "NetwKnow" }
				, { "Referral Jobs", "RefJobs" }
				, { "Matrimony", "Matr" }
				, { "Educational Services", "Edu" }
				, { "Campus To Companies", "Campus" }
				, { "JobPlus", "Jobs" }
				, { "Travel", "Trv" }
				, { "Services (C2C)", "SvcC2C" }
				, { "Shopper", "Shop" }
			**********/
				};

%>

<body <%=em_body_str%> bgcolor=<%= bcolor %>>

<%= bfont1 %> <b>Custom View For: </b></font> <br><br>

<%
	String viewName = "";
	String viewOpt = "";
	for (int i=0; i<viewList.length; i++) {
		viewOpt = viewList[i][1];
	if (viewOpt.equals(view)) {
		viewName = viewList[i][0];
	}

	}
%>
	&nbsp;&nbsp;
	<%=bfont%> <b><%=viewName%></b></font> <br>



</body>
</HTML>

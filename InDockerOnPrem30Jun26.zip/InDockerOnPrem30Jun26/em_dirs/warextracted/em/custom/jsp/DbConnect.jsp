<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.sql.*" %>

<%-- Declare local jsp variables --%>
<%!

	String[] JEM_DB0_INFO = 
	{ "oracle.jdbc.driver.OracleDriver", "oracle" };

	String[] JEM_DB1_INFO = 
	{ "sun.jdbc.odbc.JdbcOdbcDriver", "mssql" };

	String[] JEM_DB2_INFO = 
	{ "sun.jdbc.odbc.JdbcOdbcDriver", "access"};

	String[] JEM_DB_INFO = JEM_DB2_INFO;

	//Database connection parameters
	String db_type= JEM_DB_INFO[1];
	String driver = JEM_DB_INFO[0];
	//String url = "jdbc:oracle:thin:@127.0.0.1:1521:ORA815";
	String url = "jdbc:odbc:EMADB";
	//String url = "jdbc:odbc:EMDB";
	String login = "";
	String passwd = "";

	Connection dbconn = null;
	int db_stat = 0;
	String db_stat_info = "";

	//Database connection functions
  	void JConnToDb() {
        try {
            Class.forName(driver); //driver
            dbconn = DriverManager.getConnection(url, login, passwd);
		if (dbconn != null) {
			db_stat = 1;
		}

            System.out.println("  <<  Jsp make db conn ["+db_type+" "+url+" ]");

        }
        catch (ClassNotFoundException ex) {
	    db_stat_info = db_stat_info 
		+"\nJsp Cannot find the database driver classes:<br>"
		+"\n  **  db conn ["+db_type+" "+url+" ]<br>"
		+"\n Exception:<br>"
		+"\n " + ex +"<br>";
            System.err.println(db_stat_info);
            //System.err.println("Cannot find the database driver classes:");
            //System.err.println(ex);
        }
        catch (SQLException ex) {
	    db_stat_info = db_stat_info 
		+"\nJsp Cannot connect to this database:<br>"
		+"\n  **  db conn ["+db_type+" "+url+" ]<br>"
		+"\n Exception:<br>"
		+"\n " + ex +"<br>";
            System.err.println(db_stat_info);
            //System.err.println("Cannot connect to this database:");
            //System.err.println(ex);
        }
   	  catch(java.lang.Exception ex) {
			ex.printStackTrace();
	}

  }

	void JcloseDb  () 
	{
            System.out.println("    >>Jsp clse db conn");
		try {
			dbconn.close();
		}
		catch (SQLException ex) { 
	            System.err.println(ex);
		}
     }

%>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- 1. Connect to DB sample usage
	2. session parameters for Ora Msq
--%>

<%-- SAMPLE USAGE

<%@ include file="/custom/jsp/DbConnect.jsp" %>

<%
	JConnToDb();

	if (db_stat == 1) {

	PreparedStatement stmt;
	ResultSet rset;
	String[] jwptext = new String[4];
	String sql_qry_txt = "";

	try {

	sql_qry_txt =
	"	SELECT		"+"\n"+
	"	FLS_LED_CODE, MTHN,  	"+"\n"+
	"	Expr1002 , Expr1005   "+"\n"+
	"	FROM FN_DISP_LED_HIS5_VW 	"+"\n";

		stmt = dbconn.prepareStatement(sql_qry_txt); 

		//stmt.setInt(1, (int) 10019);
		//stmt.setString(2, "DEMO") ;

	if (dbconn == null || stmt == null) {
		return;
	}
	else {
            rset = stmt.executeQuery();

		//if (rset.next()) {
		while (rset.next()) {
	       for (int i=0; (i < jwptext.length) ;i++) {
			jwptext[i] = rset.getString(i+1);
%>
		i = <%=i%> - <%=jwptext[i]%><br>
<%
		}

		}

		rset.close();
		stmt.close();
	} //else
	} //try
        catch (SQLException ex) {
            System.err.println(ex);
        }


	JcloseDb(); 
	}

%>

SAMPLE USAGE --%>

<%@ page import="java.io.*" %>
<%@ page import="java.util.*" %>
<%@ page import="java.sql.*" %>


	void JsetSessionParamOra(String[] em_prof) {
	//Set session parameters...	
	String sql_qry_txt = "ALTER SESSION SET ";
	String sql1_txt = "";
	String sql2_txt = "";
	String sql3_txt = "";
	int exec = 0;

	try {
	if (l_em_conn[6].equals("Yes")) {

		if (! ("X"+em_prof[9]).equals("Xnull")){
			if (em_prof[9].trim().length() > 0 ){
			sql1_txt = " NLS_LANGUAGE = '"+em_prof[9]+"' ";
			exec = 1;
			}
		}
		if (! ("X"+em_prof[10]).equals("Xnull")){
			if (em_prof[10].trim().length() > 0 ){
			sql2_txt = " NLS_TERRITORY = '"+em_prof[10]+"' ";
			exec = 1;
			}
		}
		//if(! ("X"+em_prof[11]).equals("Xnull")) {
		//sql3_txt = " SET NLS_CHARACTERSET = '"+em_prof[11]+"' ";
		//exec = 1;
		//}

		sql_qry_txt = sql_qry_txt + sql1_txt + sql2_txt + sql3_txt + "\n";

		if(exec == 1) {


		//System.out.println("************ >>Setting NLS....");
		//System.out.println(sql_qry_txt);
		//System.out.println("************ <<Setting NLS....");

		PreparedStatement stmt;
		ResultSet rset;

		stmt = dbconn.prepareStatement(sql_qry_txt); 
		if (dbconn == null || stmt == null) {
		}
		else {
        	    rset = stmt.executeQuery();

			rset.close();
			stmt.close();

		} //else

		/******* debug *
		stmt = dbconn.prepareStatement(
		"select rpad(parameter,40), rpad(value,35) from v$nls_parameters"
		); 
        	    rset = stmt.executeQuery();
			while (rset.next()) {
			System.out.println(rset.getString(1)+" "+rset.getString(2));
			}
			rset.close();
			stmt.close();

		******* debug *******/

		}
	
	}
	}
        catch (SQLException ex) {
            System.err.println(ex);
	    //System.err.println(sql_qry_txt);
        }
  }

	void JsetSessionParamMsq(String[] em_prof) {
	//Set session parameters...	
	String sql_qry_txt = "";

	if (! ("X"+em_prof[2]).equals("Xnull")){
	if (em_prof[2].trim().length() > 0 ){
	sql_qry_txt = "SET DATEFORMAT '"+em_prof[2]+"'";

	try {
		PreparedStatement stmt;
		ResultSet rset;

		stmt = dbconn.prepareStatement(sql_qry_txt); 
		if (dbconn == null || stmt == null) {
		}
		else {
        	    	stmt.execute();

			//rset.close();
			stmt.close();

		} //else

	}
        catch (SQLException ex) {
            System.err.println(ex);
	    System.err.println(sql_qry_txt);
        }

	}
     }



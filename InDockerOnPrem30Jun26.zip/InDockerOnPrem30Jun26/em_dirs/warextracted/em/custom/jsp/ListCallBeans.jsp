<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->
	<%-- DEFINE the beans as described below, and remove: if (1==2) line....

	<% if (cbn_nm.equals("em.CB_DEMO_10004_10018")) { %>
<%@ include file="/custom/jsp/CB_DEMO_10004_10018.jsp" %>

	<% if (1==2) { %>

	--%>

	<% if (cbn_nm.equals("em.CB_DEMO_10006_10037")) { %>
<%@ include file="/custom/jsp/CB_DEMO_10006_10037.jsp" %>

	<% } else if (cbn_nm.equals("em.CB_DEMO_10006_10038")) { %>
<%@ include file="/custom/jsp/CB_DEMO_10006_10038.jsp" %>

	<% } else { %>

	<br>
	<%=bfont1%> <font color="FF0000">
	Info: No jsp code associated for called bean [<%=cbn_nm%>].
	</font></font><BR><br>

	<% } %>

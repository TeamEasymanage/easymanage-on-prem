<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="jsp/BaseEmJsp.jsp" %>

<jsp:useBean id="mo" scope="page" class="em.My_opt" />
<%
	String isAP = "";
	String isAppPref = "";

	if (app_run == 1 ) { 
		mo.setApFlg();
		isAP = "AP";
		isAppPref = "App";
	}
%>
<%
	mo.processRequest(request, response);
	get_gui_str(mo.gui_str);


%>
<%-- check valid sign-in --%>
<%	emerr = mo.emerr;
	valid_login = mo.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="jsp/no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<TITLE><%= TitleInb %> : Getting Started</TITLE>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	mnu1_sel = 4;
	mnu2_sel = 1;
	String usrnm = mo.usrnm;
	usrnm_as = mo.usrnm_as;
	usrnm_si = mo.usrnm_si;
	datagrp = mo.datagrp;

%>
<%@ include file="jsp/pre_dn_sm.jsp" %>

	<%= bfont %> <b>Getting Started Guide : Start Here 
			<span class="glyphicon glyphicon-circle-arrow-right" title="Start Here"></span>
			</b></font><br>

  <p></p><p><%= bfont %>For Beginners & App Usage </font></p>

  <!----------------------------------------------------------------->
  <p><%= bfont %>View Apps</font></p>
  <a href="#use_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Find, View, Use: Apps
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="use_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>
	<ul><li>
	<p> View Available Contact & Group Apps : Go To [
		<A HREF="<%="/"+usrproj+"/jsp/dn/auth_list_apps_npl.jsp?usrnm="+usrnm+"&selopt=aplist&wptext3=Avl&attempt=1&routeto="%>">
		Contact Apps</A>
		&rArr;
		<A HREF="<%="/"+usrproj+"/jsp/dn/auth_list_apps_npl.jsp?usrnm="+usrnm+"&selopt=aplist&wptext3=Avl&attempt=1&routeto="%>">
		<b>Avl Contact & Group Apps</b></A>
		]
	</li><li>
	<p> Search Contact & Group Apps : Go To [
		<A HREF="<%="/"+usrproj+"/jsp/dn/auth_list_apps_npl.jsp?usrnm="+usrnm+"&selopt=aplist&wptext3=Avl&attempt=1&routeto="%>">
		Contact Apps</A>
		&rArr;
		<A HREF="<%="/"+usrproj+"/jsp/dn/CSearchNpl.jsp?usrnm="+usrnm+"&routeto="%>">
		Search Contact Apps</A>
		]
	</li><li>
	<p> View Available Public Apps : Go To [
		<A HREF="<%="/"+usrproj+"/jsp/dn/auth_list_apps_emp.jsp?usrnm="+usrnm+"&selopt=empaplist&wptext0=180&attempt=1&routeto="%>">
		Public Apps</A> (or Choose below it: List Global Apps or List Location Apps)
		]
	</li><li>
	<p> Find, Search Public Apps : From Left Panel Select Button [<span class="glyphicon glyphicon-search"></span> Public Apps]
	<font size=1><br>Narrow search by giving Duration, Category, Location or App name</font>
	</li><li>
	<p> View App or IApp : From above searches : Click On "Select App" or displayed App List Link. 
		This takes you to App Viewer.<font size=1>
		Click <span class="glyphicon glyphicon-arrow-left" title="Exit App"></span>
		To Come back after viewing app.
		IApp are Read-Only (Not data records can be entered) while App allows data records entry.
		Both allow adding comments (as permitted by its owner).
		</font>
	</li><li>
	<p> Use Apps : Same procedure as View App. Note: data can be entered in Apps while not in IApp.
	</li></ul>
	</font>
   </div>

  <!----------------------------------------------------------------->
  <p></p><p><%= bfont %>View Messages, Use Mail-Box</font></p>
  <a href="#use_msg" class="btn btn-xs btn-info" data-toggle="collapse">
  View Messages, Use Mail-Box
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="use_msg" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> View Messages : Go To "Mail Box" &rArr; "Inbox (Mail)" or "App Inbox" (Msgs sent from Apps)
	<p> View or Check Emails : Go To "Mail Box" &rArr; "Check Mail"
	<p> Send Messages : Go To "Mail Box" &rArr; "Send EM Message"
	<p> Create Email (Draft) : Go To "Mail Box" &rArr; "Compose EM Mail"
	<p> Create Story Mail : Go To "App Copy-Paste" &rArr; "Story Comp Sess or All"
	<p> Send Email (From Draft) : Go To "Mail Box" &rArr; "Outbox" &rArr; List displayed: "Send" for Mail item 
	</font>

   </div>

  <hr>
  <p><%= bfont %>For App Creators</font></p>

  <!----------------------------------------------------------------->
  <p><%= bfont %>Contacts & Groups</font></p>
  <p>
  <a href="#npl_set" class="btn btn-xs btn-info" data-toggle="collapse">
  Seting up Contacts & Groups
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="npl_set" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Add Contact : Go To "My Apps" &rArr; "New Contact/Group"
	<p> Add Group : Same as above (Select Type as Group)
	<p> Add Group Members : Go To "My Apps" &rArr; "List Contacts" &rArr; For particular Group listed : "Members" &rArr; "Create New Record" 

	</font>

  </div>

  </p><p>
  <a href="#npl_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Creating App For Contacts & Groups
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="npl_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Create App : Go To "My Apps" &rArr; "List Contacts" &rArr; For particular Contact or Group listed : "New Apps"
	<p> Set App Prop : Go To "My Apps" &rArr; "List My Apps" &rArr; For particular App listed : "App Properties"
	<p> Publish App  as IApp : Go To "My Apps" &rArr; "List My Apps" &rArr; For particular App listed : "Publish IApp" <br>
		<font size=1>Note: All of this App's assignments to other contacts/groups (and public as well) will become "IApp" Immutable App (Read-Only mode).
		</font>
	</font>

   </div>

  <!----------------------------------------------------------------->
  <p><%= bfont %>Public Apps</font></p>
  <a href="#emp_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Creating Public Apps
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="emp_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> Create Global Public App : Go To "Public Apps" &rArr; "New Global App"
	<p> Create Location Public App : Go To "Public Apps" &rArr; "New/Assign Location App"
	<p> Set App Prop : Go To "Public Apps" &rArr; For particular App listed : "[EMAPPnnnnn] App Properties"
	<p> Publish App  as IApp: Go To "Public Apps" &rArr; For particular App listed : "Publish IApp" <br>
		<font size=1>Note: All of this App's assignments to other contacts/groups (and public as well) will become "IApp" Immutable App (Read-Only mode).
		</font>
	</font>

   </div>

  <hr>
  <p><%= bfont %>Advanced Features : For App Creators</font></p>
   
  <!----------------------------------------------------------------->
  <p><%= bfont %>App Exchange (App Copy-Paste) : Your App Repository</font></p>
  <a href="#repo_app" class="btn btn-xs btn-info" data-toggle="collapse">
  Manage App Repository
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="repo_app" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> [Note: Switch from Dashboard to Advanced Menu to view "App Repository Mgmt" i.e. Manage Repos Menu : Go To   
	<!-- "Menu <span class="glyphicon glyphicon-option-vertical"></span>"
	&rArr; --> "Advanced Menu &rArr;" ]
	<p> List & View Items in Repo : Go To "App Repository Mgmt" &rArr; "List My Repositories"
	<p> Create New Repo Item Ways  : New Repo Item (i.e. App or Story) can be created via following ways :<br>
	[1] Blank Repo : Go To "App Repository Mgmt" &rArr; "Create New Repository" <br>
	[2] Story Repo : Select & View an App &rArr; <span class="glyphicon glyphicon-bookmark"></span> MarkSend items &rArr; "App Copy-Paste" &rArr; "Compose Story Sess or All"<br>
	[3] New App Creation : While creating New Contact/Group or Public App, corresponding Repo is created <br>
	[4] New Repo From Sub/Auth System Apps : Go To "App Repository Mgmt" &rArr; "List Subscribed/Authorized" &rArr; for listed item: "Select" &rArr; "Create-New-MyCopy" <br>
	[5] From EM Mail : Go To "Mail Box" &rArr; "Inbox (Mail)" or "Outbox" &rArr; for listed item: "Create Collaboration" <br>
	<p> Do Copy / Paste with Repo Items : Go To "App Repository Mgmt" &rArr; "List My Repositories" &rArr; for listed item: "MarkForCopy" &rArr; for desired target item: "PasteRefresh" or "PasteCopy"
	</font>

   </div>

  <!----------------------------------------------------------------->
  </p><p><%= bfont %>How to Copy | Extract | Combine on Apps</font></p>
  <a href="#app_ops" class="btn btn-xs btn-info" data-toggle="collapse">
  Extract | Combine Ops on Apps
  <span class="glyphicon glyphicon-menu-down"></span>  
  </a>
  <div id="app_ops" class="collapse" style="border : solid 1px #DEDEDE;">
	<%= bfont %>

	<p> [Note: Switch to Advanced Menu to view "App Repository Mgmt" Menu : Go To   
	<!-- "Menu <span class="glyphicon glyphicon-option-vertical"></span>"
	&rArr; --> "Advanced Menu &rArr;" ]
	<p> Extract New Story From a App (i.e. Create App/Story Repo) : 
		Select & View an App &rArr; <span class="glyphicon glyphicon-bookmark"></span> MarkSend items &rArr; "App Copy-Paste" &rArr; "Compose Story Sess or All"<br>
	<p> Navigate to Repo Item : Go To "App Repository Mgmt" &rArr; "List My Repositories" &rArr; locate from listed items 
	<p> Do Copy / Paste with Repo Items : Go To "App Repository Mgmt" &rArr; "List My Repositories" &rArr; for listed item: "MarkForCopy" &rArr; for desired target item: "PasteRefresh" or "PasteCopy"
	</font>

   </div>




<%-- -------------------------------------------------------------
	--------------------------------------------------------------
	TODO :
	* Using Apps Tips
		Activity : Search Data Records : Wp : Go to Records
		Activity : Search Comments : Wp : Go to Records
		Marked Bokmarks : View with App bookmarks Sess | All
		
	--------------------------------------------------------------
	<%= bfont %> <b>Getting Started</b></font><br>

	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String ctg_param = "usrnm="+mo.usrnm+"&routeto="+mo.routeto+"&tm_now="+tm_now; 
	%>
  --------------------------------- --%>


<%@ include file="jsp/post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

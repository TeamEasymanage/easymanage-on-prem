
<%-- Service Select Block --%>

                                            <label>Service</label> &nbsp;
                                            <select class="label label-info"  name="selService">
											<%
													String disp_opt = "";
													/* -------- >> COPY SECTION --------- */
											%>
<%@ include file="index_ins1_svcs.jsp" %>
											<%
													/* -------- << COPY SECTION --------- */
													String wptext = ""; 
													StringBuffer strbuf1 = new StringBuffer();
													for (int i=0 ;i<op.length; i++) {
														if(op[i].equals(wptext)) {
																 strbuf1.append("<option value=\""+op[i]+"\" selected>"+val[i]+"</option>"+"\n");
														} else {
																 strbuf1.append("<option value=\""+op[i]+"\" >"+val[i]+"</option>"+"\n");
														}
													}
													disp_opt = strbuf1.toString();

											%>
											<%= disp_opt %>
												<%--
                                                <option value="NetPlus">NetPlus</option>
                                                <option value="ProfPlus">ProfPlus</option>
                                                <option value="EmPlus">EmPlus</option>
                                                <option value="BusPlus">BusPlus</option>
												<option value="NetPro">NetPro</option>
												--%>
                                            </select>

											<%
													/* -------- COPY SECTION --------- */
													String op[] = {
																	// **Note: Must start with NetPlus|EmPlus|NetEm|NetPro
																	"NetPro"+"PlatFF"+usrproj
																	};
													%>
<script type="text/javascript">
													var app_rt = [
																	'<%=usrproj%>'
																	];
</script>
													<%
													String val[] = {
																	"EM Platform FF"
																	};
													/* -------- COPY SECTION --------- */
											%>


<%@ include file="jsp/BaseEmPrtl.jsp" %>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * All rights reserved.
 */
-->

<%@ include file="pre_dn1_html.jsp" %>

<TITLE><%= TitleInb %> : Home - Search</TITLE>

<%@ include file="pre_dn2_html.jsp" %>

<% 
String t_secURLPrefix = "";
if (secSignInUp == 1) { 
	t_secURLPrefix = secURLPrefix;
} 
%>

    </div> <!--dummy div tbl resp.-->

    <div class="container">
        <div class="row text-center ">
            <div class="col-sm-8">
                <h3> EasyManage : Search</h3>
            </div>
        </div>
        <div class="row">
               
                  <div class="col-sm-8"> <!--class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2 col-xs-12 "--> <!-- col-xs-offset-1 -->
                        <div class="panel panel-default">
                            <div class="panel-heading">
							<font FACE="VERDANA,ARIAL,TIMES NEW ROMAN" SIZE="2" color="">
                        <strong>   Search Options </strong>
								(Search For Information available without Sign In )
								</font>
                            </div>
                            <div class="panel-body">
							
<%@ include file="SrhWin.jsp" %>
							</div>
                        </div>
                    </div>
                
                
        </div>
    </div>

    <div> <!--dummy div tbl resp.-->


<!-- Footer -->
<%@ include file="post_dn_html.jsp" %>

</BODY>
</HTML>

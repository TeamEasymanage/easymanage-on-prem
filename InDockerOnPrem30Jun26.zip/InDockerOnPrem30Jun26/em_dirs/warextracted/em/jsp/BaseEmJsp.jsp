<%--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
--%>

<%@ page import="java.io.*" %>

<%@ include file="/jsp/BaseEmPrtl.jsp" %>

<%-- Declare local jsp variables --%>
<%!

	// -----------------------------------------
	// CHANGES TO THESE PARAMETERS NOT Effective
	// -----------------------------------------

	int is_frame = 0;
	String ln_tgt = "";

	String[] gui_str = { 
		"White",
		"",
		"Verdana"
		//"0",
		//"#CCCCCC",
		//"#DDDDDD",
		//"#EFEFEF"
		};

	String[] hf_gui_str = new String[11];

	// ------------------------------------
	// DO NOT CHANGE PARAMETER VALUES BELOW 
	// ------------------------------------

	//# For mandatory space in HTML
	String pspace1 = "&nbsp;";

	//# Project code, moved
	//String usrproj = "em";

	int valid_login = 0;
	String emerr = "";
	String SendToUrl = "/"+usrproj+"/index.jsp";

	//String TitleInb	= "EM WebPlus Suite 5.0 :";

	int mnu0_sel = 1;
	int mnu1_sel = 1;
	int mnu2_sel = 1;

	int app_run = 0;
	String usrnm_as = ""; // As User
	String usrnm_si = ""; // Sign-In
	String datagrp = "";
	int app_usr = 0;

	int putMenuNoGlo = 1;

	//-- Jsp Configuration Parameters : User configurable jsp variables --
	//-- Parameters moved up to BaseEmPrtl.jsp. --
	//   //Not used parameters from here anymore	

	//   //Non implemented parameters kept here...	
	int sys_menu_images = 0;

	//**** Following Unsed in jsp, used by bean sub_data_frm
	//int tbl_data_html_img = 1;
		//int tbl_data_html_obj_hylnk = 1;


	//-- **** Misc : GUI Properties **** --
	//#  moved to BaseEmPrtl

// ================= FUNCTIONS =======================
	void get_gui_str (String[] p_gui_str){
		for (int w=0;w<gui_str.length;w++){
			gui_str[w] = p_gui_str[w];
		}
		bcolor = gui_str[0];

		int font_base_size = 1; //2 (was 1)
		bfont  = "<FONT FACE=\""+gui_str[2]+"\" COLOR=\""+gui_str[1]+"\" SIZE=\""+(font_base_size+1)+"\">";
		bfont1  = "<FONT FACE=\""+gui_str[2]+"\" COLOR=\""+gui_str[1]+"\" SIZE=\""+(font_base_size)+"\">";
		bfont3  = "<FONT FACE=\""+gui_str[2]+"\" COLOR=\""+gui_str[1]+"\" SIZE=\""+(font_base_size+2)+"\">";

		//hdr/ftr vars 15-28
		for (int w=0,x=15;w<hf_gui_str.length;w++,x++){
			hf_gui_str[w] = p_gui_str[x];
			//System.out.println(p_gui_str[x]+":"+hf_gui_str[w]);
		}

		hdrfont  = "<FONT FACE=\""+hf_gui_str[1]+"\" >";
		smnufont1  = "<FONT FACE=\""+hf_gui_str[4]+"\" SIZE=\"2\">";

	}

	boolean put_hdrftr_flg(int ndx) {
		boolean ret_flg = false;
		String l_tok = "";
		if ((hf_gui_str[0] != null ) && (hf_gui_str[0].length() >= (ndx+1)) ) { 
				l_tok = hf_gui_str[0].substring(ndx,ndx+1);
		} else {
			l_tok = "1";
		}

		if ((l_tok != null) && (l_tok.equals("1"))) {
			ret_flg = true;
		}
		return ret_flg;
	}
	boolean put_hdr() { return put_hdrftr_flg(0); }
	boolean put_logo() { 
		if (hideEmwpLogo == 1) { 
			return false; 
		} else {
			return put_hdrftr_flg(1); 
		}
	}

	boolean put_title() { return put_hdrftr_flg(2); }
	boolean put_usrinfo() { return put_hdrftr_flg(3); }
	boolean put_apnm() { return put_hdrftr_flg(4); }
	boolean put_smnu() { return put_hdrftr_flg(5); }
	boolean put_hr_beg() { return put_hdrftr_flg(6); }
	boolean put_hr_end() { return put_hdrftr_flg(7); }
	boolean put_ftr() { 
		if (hidePwrByCpyRt == 1) { 
			return false; 
		} else {
			return put_hdrftr_flg(8); 
		}
	}
	boolean put_mnu_img() { 
		if (menu_images == 1 ) { return put_hdrftr_flg(9); 
		} else { return false; }
	}
	boolean put_frmnu_img() { 
		if (fr_menu_images == 1 ) { return put_hdrftr_flg(10); 
		} else { return false; }
	}
	boolean put_mnu_scr_img() { 
		if (menu_scr_images == 1 ) { return put_hdrftr_flg(11);
		} else { return false; }
	}
	boolean put_app_list_img() { 
		if (app_list_images == 1 ) { return put_hdrftr_flg(12); 
		} else { return false; }
	}
	boolean put_mnu_img_hlp_file() { 
		if (mnu_img_helpfile == 1 ) { return put_hdrftr_flg(13); 
		} else { return false; }
	}

	//*** Implemented directly in table display bean (only user prof setting checked) ****
	/*********
	boolean put_data_html_img() { 
		if (tbl_data_html_img == 1 ) { return put_hdrftr_flg(14); 
		} else { return false; }
	}
	boolean put_data_html_obj_hylnk() { 
		if (tbl_data_html_obj_hylnk == 1 ) { return put_hdrftr_flg(15); 
		} else { return false; }
	}
	************/
	boolean put_jquery_on() { 
		return put_hdrftr_flg(27); //== (28 in BaseEm)
	}

	boolean JspCust() { 
		boolean ret_flg = false;
		if (jsp_cust == 1 ) { ret_flg = true; }
		return ret_flg;
	}
	
	// ---------Level 1------------------
	String putMenuImgHelpFileContents(String p_usr,String p_typ, String p_id) 
	throws IOException
	{
			return contentsJspImgHlpFile(getJspImgHlpFile(p_usr,p_typ, p_id));
	}

	// ---------Level 0------------------
	boolean JspImgFile(String p_usr,String p_typ, String p_id) {
		String l_filenm = getJspImgFile(p_usr,p_typ, p_id);
		return (gotJspImgFile(l_filenm));
	}
	boolean JspImgHlpFile(String p_usr,String p_typ, String p_id) {
		String l_filenm = getJspImgHlpFile(p_usr,p_typ, p_id);
		return (gotJspImgFile(l_filenm));
	}

	boolean gotJspImgFile(String l_filenm) {
		boolean ret_flg = false;
		File l_img_file = new File(img_real_dir, l_filenm );
		//System.out.println("File chk: "+l_img_file.getPath());
		if (l_img_file.exists() && l_img_file.canRead()) {
			ret_flg = true;
		}
		return ret_flg;
	}

	String contentsJspImgHlpFile(String l_filenm) 
	throws IOException
	{
		File l_img_file = new File(img_real_dir, l_filenm );
		//System.out.println("File chk: "+l_img_file.getPath());
		return contentsFile(l_img_file);
        }

	String contentsFile(File l_img_file) 
	throws IOException
	{
		FileReader instream = null;
		StringWriter strout = new StringWriter();
		if (l_img_file.exists() && l_img_file.canRead()) {
			instream =  new FileReader(l_img_file);
		}
		char[] buffer = new char[1024*8];
		int totrd = 0;
		int length = 0;
		if (instream != null) {
			while ((length = instream.read(buffer)) != -1)
			{
				strout.write(buffer,0,length);
				totrd += length;
			}
			instream.close();
			strout.close();
		String ret_str = "" + strout.toString();


			//******* General Removals / script / URL links pointing elsewhere ....
			//FOR ALL inputs remove // by /

			//ret_str = doEmWppReplStr(ret_str, "://", " ");
			//ret_str = doEmWppReplStr(ret_str, "//", " ");

	String str =  ret_str;

	//Remove unsafe HTML tags
	String[] html_unsafe = {
		/*********
		"<script", 
		"<base", "<basefont", "<head", "<html", "<body", 
		"<applet", "<object", "<iframe", "<frame", "<frameset", 
		"<script", "<layer", "<ilayer", "<embed", "<bgsound", "<link", 
		"<meta", "<style", "<title", "<blink", "<xml", "<img"
		,"<video" ,"<audio"
		***********/
		//,"Disable For ALL" ,"Top-level elements:"
		"!DOCTYPE"
		,"body"
		,"frameSet"
		,"head"
		,"html"
		,"xhtml"
		// ,"<Head elements:"
		,"?IMPORT"
		,"base"
		,"link"
		,"meta"
		,"title"
		,"style"
		// ,"Frame elements:"
		,"frame"
		,"noFrames"
		,"frameSet"
		// ,"===================================="
		//,"Disable For Safe"
		,"baseFont"
		//,"Embedded and external document resource elements:"
		,"link"
		,"blink"
		,"marquee"
		,"keygen"
		//from orig list
		,"layer"
		,"ilayer"
		//,"Applet, media file and plug-in elements:"
		,"applet"
		,"bgSound"
		//  protocols 
		//scripts, etc
		,"script"
		,"noScript"
		,"javascript:"
		,"vbscript:"
		,"about:"
		,"res:"
		,"embed"
		,"object"
		,"param"
		//,""
		,"xml"
		,"?xml"
		//
		,"video" 
		,"audio"
		,"iframe"
		,"button"
		,"form"
		,"input"
		/************ input types
		,"<input:button", "<input:checkbox", "<input:file", "<input:hidden","<input:image"
		,"<input:password","<input:radio","<input:range","<input:reset"	,"<input:search"
		,"<input:submit","<input:text"
		************/
		,"select"
		,"option"
		,"optGroup"
		//,""
		,"textArea"

		};

	for (int q=0;q<html_unsafe.length;q++) {
	String l_tok_str = html_unsafe[q].toLowerCase();
	String l_tok = "<"+l_tok_str;
	String l_tok_prt = "&lt;"+l_tok_str;
	if (str.toLowerCase().indexOf(l_tok) >= 0 ) {
		str = "Warning: Detected tag keyword ["+l_tok_prt+"], reset the text!";
		break;
	}
	}//for

			//if (ret_str.toLowerCase().indexOf("<script") >= 0 ) {
			//	ret_str = "Warning: Detected script keyword, reset the help text !";
			//}

		return str;
		} // if instream != null
		return "";
	}

	// ********* Copy from EM Lib

    	String doEmWppReplStr(String str, String org, String dest) {
	if ((str==null)||(str=="")||(org==null)||(org=="")) { return (str);}
	if (dest==null) { dest="";}
	StringBuffer strbuf = new StringBuffer();
	int k = org.length();

	for (int j=0 ; (j = str.indexOf(org)) >= 0; ) {
		strbuf.append(str.substring(0,j)+dest);
		if (str.length() > j+k) {
			str = str.substring(j+k);
		} else { str = ""; break; }
	}
	strbuf.append(str); //trailing string part
    	return (strbuf.toString());
    }

	// ********* Copy from EM Lib


	/************** Original
	boolean JspImgFile(String p_usr,String p_typ, String p_id) {
		boolean ret_flg = false;
		File l_img_file = new File(img_real_dir, getJspImgFile(p_usr,p_typ, p_id) );
		//System.out.println("File chk: "+l_img_file.getPath());
		if (l_img_file.exists() && l_img_file.canRead()) {
			ret_flg = true;
		}
		return ret_flg;
	}
	*****************/

	String getJspImgFile(String p_usr,String p_typ, String p_id) {
	return "my_menu/"+p_usr+"/"+p_typ+p_id+img_file_ext;
	}

	String getJspImgHlpFile(String p_usr,String p_typ, String p_id) {
	return "my_menu/"+p_usr+"/"+p_typ+p_id+mnu_img_helpfile_ext;
	}

	
	String getJspEmCky(HttpServletRequest request,String p_cky) {
		String t_cky_val = "";
			try {
				  Cookie[] t_cookies = request.getCookies();
				  for (int i = 0; i < t_cookies.length; i++) {
						Cookie t_c = t_cookies[i];            
					String name = t_c.getName(); 
					String value = t_c.getValue();
					if(name.equals(p_cky)) {
					t_cky_val = value;
					}
				  }
				} catch (Exception ex) {
					System.err.println(ex);
				}
		return t_cky_val;
	}
	
	//Bootstrap Image handling lib
	String btsPutImageDef(String p_typ) {
	String ret_str = "";

		if (p_typ.equals("app")){
		ret_str = 
		"<div class=\"ems_circ img-responsive\">"+"\n"+
		"<span class=\"glyphicon glyphicon-blackboard\"></span>"+"\n"+
		"</div>"+"\n";
		} else {
		ret_str = 
		"<div class=\"ems_circ img-responsive\">"+"\n"+
		"<span class=\"glyphicon glyphicon-user\"></span>"+"\n"+
		"</div>"+"\n";
		}
	return ret_str ;
	}
	String btsPutImageDiv(String p_typ) {
	String ret_str = "";

		if (p_typ.equals("app")){
		ret_str = 
		"<div class=\"ems_circ_blank img-responsive\">"+"\n";
		}
	return ret_str ;
	}

	
%>
<%@ include file="/custom/jsp/JspConfParam.jsp" %>
<%@ include file="/pre_dn_top_bts.jsp" %>
<%@ include file="/jsp/EmStyleDef.jsp" %>

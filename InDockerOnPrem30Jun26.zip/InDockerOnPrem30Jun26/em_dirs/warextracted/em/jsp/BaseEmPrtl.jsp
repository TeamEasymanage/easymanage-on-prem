<%--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
--%>

<%@ page import="java.util.*" %>
<%@ page import="java.net.URLDecoder" %>

<%-- Declare local jsp variables --%>
<%!

	// ------------------------------------
	// PORTAL SPECIFIC PARAMETERS: EXERCISE CAUTION 
	// ------------------------------------

	// **************** Read from resource properties ********

	// Read parameters file
	static ResourceBundle r_em_param_conf =
		ResourceBundle.getBundle("em_param_conf");

	// **************** Configuration Options ****************

	//# Portal: Web App / context 
	String usrproj = getConfParam(r_em_param_conf, "usrproj"); //"em";

	//If above changed, Please change 'em_param.em_usrproj' as well.

	int showNetwkEmHdrFtr = getConfParamInt(r_em_param_conf, "NetwkEmHdrFtr"); //0=No, 1=Yes
	int hideEmwpLogo = getConfParamInt(r_em_param_conf, "hideEmwpLogo"); //0=No, 1=Yes
	int hidePwrByCpyRt = getConfParamInt(r_em_param_conf, "hidePwrByCpyRt"); //0=No, 1=Yes

	//# Edit UserConf Options
	//# 	Can edit: <TitleInbPrtl<CpyRtPwrBy<SiCodesChk<ImgIconProp<UsersAds<ChangeableAdSlots<
	String[] edit_userconfVal = getEdit_userconfConf(r_em_param_conf);
	// ******* OVERRIDE Section at the END ***********

	// ** physical dir (having "my_menu") i.e. em.param.file_dest_dir
	//On Win use format: e.g. "E:/EMV50/MyFiles/"
	//On Unix use format: e.g. "/data1/emv50/em_files/";
	String file_dest_dir =  getConfParam(r_em_param_conf, "file_dest_dir"); //"/XxYyZz/";

	// **************** Display Information Options ****************

	String TitleDomain	= getConfOrAssignDef();
	
	String TitleInb	= getConfParam(r_em_param_conf, "TitleInb");
	String TitlePrtl = getConfParam(r_em_param_conf, "TitlePrtl");

	String PoweredBy = getConfParam(r_em_param_conf, "PoweredBy");
		//"Powered By "+
		//"<A HREF=\"http://www.EasyManage.com\">EasyManage.com</A>"+
		//" (EM WebPlus Suite 5.0)";

		//NOTE: Do not change copyright Year : get's replaced by sed script!
	String CopyRt = getConfParam(r_em_param_conf, "CopyRt");
		//"Copyright (c) 2026 <A HREF=\"http://www.EasyManage.com\">EasyManage</A>"+
		//" Infotech Pvt. Ltd. All Rights Reserved.";

	// **************** Begin: Configure Secure Mode Options ****************

	//Https Sign-In/Sign-Up options
	int secSignInUp = getConfParamInt(r_em_param_conf, "secSignInUp"); //0=No, 1=Yes
	String secURLPrefix = getConfParam(r_em_param_conf, "secURLPrefix"); 
				//e.g. https://<domain>:port (without trailing "/" )
				  //e.g. https://127.0.0.1:8443

	//From https switch to http after sign-in or sign-up
	int switchToHttp = getConfParamInt(r_em_param_conf, "switchToHttp"); //0=No, 1=Yes
	String switchToHttpURLPrefix = getConfParam(r_em_param_conf, "switchToHttpURLPrefix");
					  //e.g. http://<domain>:port (without trailing "/" )
					   //e.g. http://127.0.0.1:8080

	// **************** End  : Configure Secure Mode Options ****************

	// **************** Begin: Mobile / phone rendering ****************
	/******** FOR FUTURE NEEDS
	//# For Mobiles : 0=No, 20=Mini, 15=Plus, 10=More, 5=All, (or 1=Full via Web)
	int for_mob_type = getConfParamInt(r_em_param_conf, "for_mob_type");
	***********/
	//int for_mob_type = 0; //later on add the parameter as above
	int for_mob_type_mode = 0; //for displaying minimum screens
	int ck_for_mob_type = 0; // Set after fun block from cookie

	// **************** Begin: Third Party Sign In params ****************
	//# Facebook
	String tp_fbkapikey = getConfParam(r_em_param_conf, "tp_fbkapikey");

	// **************** Begin: Sign-Up Invitation Code checking ****************

	int siCodeCheck = getConfParamInt(r_em_param_conf, "siCodeCheck");	
				//Check Invitation code on Sign-Up? 
				//0=No, >0=Yes: 1=User Or Group, 2=User && Group

				//Message for Invitation code on Sign-Up screen 
	String siCodeMsg = getConfParam(r_em_param_conf, "siCodeMsg"); 
		//"Please request codes to <a 		//href=\"mailto:support@easymanage.com\">support@easymanage.com</a>.";

	String[][] siCodeList	= getSiCodeListConf(r_em_param_conf);
			  // GroupCode, 		UserCode
	
	// **************** End: Sign-Up Invitation Code checking ****************

	// **************** Begin: Advertise Insertions ****************

	int showAds = getConfParamInt(r_em_param_conf, "showAds");	//Insert Ads Global Flag? 0=No, 1=Yes

	String[] adListVal = getAdListConf(r_em_param_conf);

	String[] adList	= { "" 	//Leave first item blank
		, adListVal[1]
		, adListVal[2]
		, adListVal[3]
		, adListVal[4]
		, adListVal[5]
		, adListVal[6]
		, adListVal[7]
		, adListVal[8]
		, adListVal[9]
		, adListVal[10]
		, adListVal[11]
		};


	//String[] adList	= { "" 	//Leave first item blank
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[1]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[2]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[3]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[4]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[5]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[6]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[7]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[8]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[9]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[10]+"</td></tr></table>"
	//	, "<table border=1 width=100% ><tr><td>"+adListVal[11]+"</td></tr></table>"
	//	};

	//FOR ALL Following: 
	//	0=Show No Ad (Disable Loc), 
	//	n=Ad Number in adList Array starting with 1

	int adLocTop 		= getConfParamInt(r_em_param_conf, "adLocTop");
					//Main Screen: Top Location 
	int adLocBefSysMenu 	= getConfParamInt(r_em_param_conf, "adLocBefSysMenu");	
					//Main Screen: Before Sys Menu Location
	int adLocAftSysMenu 	= getConfParamInt(r_em_param_conf, "adLocAftSysMenu");	
					//Main Screen: After Sys Menu Location
	int adLocAftTopHR 	= getConfParamInt(r_em_param_conf, "adLocAftTopHR");	
					//Main Screen: After Top HR tag Location
	int adLocBefBotHR 	= getConfParamInt(r_em_param_conf, "adLocBefBotHR");	
					//Main Screen: Before Bottom HR tag Location
	int adLocAftBotHR 	= getConfParamInt(r_em_param_conf, "adLocAftBotHR");	
					//Main Screen: After Bottom HR tag Location
	int adLocEnd 		= getConfParamInt(r_em_param_conf, "adLocEnd");	
					//Main Screen: After End Of Page Location

	int adLocUMFrameTop	= getConfParamInt(r_em_param_conf, "adLocUMFrameTop");	
					//User Menu (& WP) Frame: Top Location
	int adLocUMFrameEnd	= getConfParamInt(r_em_param_conf, "adLocUMFrameEnd");	
					//User Menu (& WP) Frame: End Location

	int adLocSMFrameTop	= getConfParamInt(r_em_param_conf, "adLocSMFrameTop");	
					//Sys Menu Frame: Top Location
	int adLocSMFrameEnd	= getConfParamInt(r_em_param_conf, "adLocSMFrameEnd");	
					//Sys Menu Frame: End Location

	// **************** End  : Advertise Insertions ****************

	// **************** Begin: Jsp Configuration Parameters ****************

	// -- Jsp Configuration Parameters : User configurable jsp variables --

	// -- NOTE: Please refer to User Guide chapters for help:
	//		Chapter 8: Using Images (Icons, Links) For EM Objects
	//		Chapter 9: Advanced Features
	// --
	
	// ** Use Customized Jsp file flag:
	// ** Enable using List<Apps|AppMenu|AppScrMenu>Custom.jsp files from /em/custom/jsp dir
	int jsp_cust = getConfParamInt(r_em_param_conf, "jsp_cust"); //0=Off, 1=On

	// -- **** Parameters For Image Icons and Help Files ********* --

	// ** Images physical dir (having "my_menu") i.e. em.param.file_dest_dir
	// is SET From file_dest_dir mentioned above
	String img_real_dir =  getConfParam(r_em_param_conf, "file_dest_dir"); //"/XxYyZz/";

	String img_file_ext = getConfParam(r_em_param_conf, "img_file_ext"); //".jpg"; //e.g. ".jsp", ".bmp", etc.
	String mnu_img_helpfile_ext = getConfParam(r_em_param_conf, "mnu_img_helpfile_ext"); //".html";
	String JspImgProp = getConfParam(r_em_param_conf, "JspImgProp"); //" border=0 width=150 height=100 ";
	String JspImgPropAM = getConfParam(r_em_param_conf, "JspImgPropAM"); //" border=0 width=75 height=35 ";
	String JspImgPropAMScr = getConfParam(r_em_param_conf, "JspImgPropAMScr"); //" border=0 width=75 height=35 ";

	String[] JspImgPropPict = getConfParamArrImgPropPict();

	int menu_images = getConfParamInt(r_em_param_conf, "menu_images");		//App Menu Images Categories, Folders, etc
	int menu_image_cols = getConfParamInt(r_em_param_conf, "menu_image_cols");	//Number of column sections for above
	int fr_menu_images = getConfParamInt(r_em_param_conf, "fr_menu_images");		//Display App Menu Images (above) in Lt UM frame

	int menu_scr_images = getConfParamInt(r_em_param_conf, "menu_scr_images");	//Display WP Screen Menu images

	//App List Images in List Apps Auth & Subscribed, Content List Apps, Collaborations 
	int app_list_images = getConfParamInt(r_em_param_conf, "app_list_images");	

	// ** Displaying of Help HTML file contents on Rt with Menu/Folder/App Image on Lt
	int mnu_img_helpfile = getConfParamInt(r_em_param_conf, "mnu_img_helpfile");

	// ** Displaying of Text URL Links (on Right with Menu/Folder/App Names) 
	// **   along with Menu Image Links Flags.
	//1=On, 0=Display when no image, 2=Off
	int menu_img_txt_lnk = getConfParamInt(r_em_param_conf, "menu_img_txt_lnk");
	int fr_menu_img_txt_lnk = getConfParamInt(r_em_param_conf, "fr_menu_img_txt_lnk");
	int app_list_img_txt_lnk = getConfParamInt(r_em_param_conf, "app_list_img_txt_lnk");
	int menu_scr_img_txt_lnk = getConfParamInt(r_em_param_conf, "menu_scr_img_txt_lnk");

	// **************** End  : Jsp Configuration Parameters ****************

	//-- **** Misc : GUI Properties **** --
	//#  moved from BaseEmJsp

	String emhdr_col1 = "#00267F";
	String emhdr_col2 = "#3985B5";
	String emhdr_colfnt = "#FFFFFF";
	int emhdr_curv = 1;

	String em_body_str = " leftMargin=2 topMargin=0 marginheight=0 marginwidth=0 ";
	String fr_body_str = " leftMargin=0 topMargin=0 marginheight=0 marginwidth=0 ";

	// -----------------------------------------
	// CHANGES TO THESE PARAMETERS NOT Effective
	// -----------------------------------------

	//# Web Page Property variables......
	//#BGCOLOR, HTML body background color
	String bcolor  = "#FFFFFF";
			// "#FFFFC0"; (Yellow-white/cream) //"#D4D4D4"; (Grey) // "#FFCCCC";(Pink) //"#FFFFFF"; (White)

	//# Default font and size
	//Sync following size to beans/em/BaseEm.java also
	int font_base_size = 2; //2 (was 1)
	String bfont  = "<FONT FACE=\"Verdana\" SIZE=\""+(font_base_size+1)+"\">";

	//# Other fonts and sizes
	String bfont1 = "<FONT FACE=\"Verdana\" SIZE=\""+(font_base_size)+"\">";
	String bfont3 = "<FONT FACE=\"Verdana\" SIZE=\""+(font_base_size+2)+"\">";

	String hdrfont  = "<FONT FACE=\"Verdana\" >";
	String smnufont1  = "<FONT FACE=\"Verdana\" SIZE=\"2\">";

	// **************** Begin: Overide as Per Edit UserConf Options ****************
	//# Edit UserConf Options
	//# 	Can edit: <TitleInbPrtl<CpyRtPwrBy<SiCodesChk<ImgIconProp<UsersAds<ChangeableAdSlots<
	// String[] edit_userconfVal = getEdit_userconfConf(r_em_param_conf);

	String getConfOrAssignDef() {
			String str1 = getConfParamIfDef(r_em_param_conf, "TitleDomain");
			if (str1.trim().length() < 1) { 
			str1 = "EasyManage";
			}
			return str1;
	}

	// **** Func
	void doOverAll() {

	if (toEmWppInt(edit_userconfVal[0]) == 1) {
		TitleInb = doOver(TitleInb, "TitleInb");
		TitlePrtl = doOver(TitlePrtl, "TitlePrtl");
	}
	if (toEmWppInt(edit_userconfVal[1]) == 1) {
		PoweredBy = doOver(PoweredBy, "PoweredBy");
		CopyRt = doOver(CopyRt, "CopyRt");
	}
	if (toEmWppInt(edit_userconfVal[2]) == 1) {
		//siCodeCheck = doOver(, "siCodeCheck");	
		//siCodeMsg = doOver(, "siCodeMsg"); 
		//siCodeList	= getSiCodeListConf(r_em_param_conf);
	}
	if (toEmWppInt(edit_userconfVal[3]) == 1) {
	}
	if (toEmWppInt(edit_userconfVal[4]) == 1) {
		//showAds
		//adListVal
		//adList

		//adLoc??? as per edit_userconfVal[5]
	}
	}

	// **************** End  : Overide as Per Edit UserConf Options ****************

	String[] getConfParamArrImgPropPict() {
			String[] wptext = new String[5];
			for (int i=0; i<wptext.length;i++) {
				wptext[i] = getConfParamIfDef(r_em_param_conf, "JspImgPropPict."+i); //" border=0 width=75 height=35 ";
			}
	return wptext;
	}

	// *************************************************************
	// ******** Functions For Jsp Configuration Parameters *********
	// *************************************************************

	// NOTE: BaseEmPrtl is included in lot more .jsp files than BaseEmJsp
	//	 e.g. em/index.jsp, em/tos.jsp


	// **** Func
	String[][] getSiCodeListConf(ResourceBundle r_em_param_conf) {
	String[][] t_siCodeList = new String [6][2];
			  // GroupCode, 		UserCode
	  for (int k=0;k<t_siCodeList.length;k++) {
		t_siCodeList[k][0] = getConfParam(r_em_param_conf, "siCodeList.group."+k);
		t_siCodeList[k][1] = getConfParam(r_em_param_conf, "siCodeList.user."+k);
	  }
	return t_siCodeList;
    }

	// **** Func
	String[] getAdListConf(ResourceBundle r_em_param_conf) {
	String[] t_adListVal = new String [12];
	  for (int k=0;k<t_adListVal.length;k++) {
		t_adListVal[k] = getConfParam(r_em_param_conf, "adList."+k);
	  }
	return t_adListVal;
    }

	// **** Func
	String[] getEdit_userconfConf(ResourceBundle r_em_param_conf) {
	String[] t_arr = new String [5];
	  for (int k=0;k<t_arr.length;k++) {
		t_arr[k] = getConfParam(r_em_param_conf, "from_userconf."+k);
	  }
	return t_arr;
    }

	// ********* Copy from EM Lib

	String toEmWppStr (String param) {
	String tmp_pstr = param;
	//System.out.println("tmp_pstr ="+tmp_pstr);
	if (("X"+tmp_pstr).equals("Xnull")){
		tmp_pstr = "";
	}
	return tmp_pstr;
    }
	int toEmWppInt (String tmp_pstr) {
	//System.out.println("tmp_pstr ="+tmp_pstr);
	int p_int = 0; 
	if (! ("X"+tmp_pstr).equals("Xnull")){
		if (tmp_pstr.trim().length() > 0 ){
			try {
			p_int = Integer.valueOf(tmp_pstr).intValue();
			} catch (NumberFormatException ex) {
		            System.err.println(ex);
		        }

		}
	}
	return p_int;
    }

	// ********* Copy from EM Lib

	String getConfParamIfDef(ResourceBundle b1, String cp_param) {
	String cp_val = "";
	try {
		cp_val = getConfParam(b1, cp_param);
	} catch (MissingResourceException e) {
		cp_val = "";
	} catch (Exception ex) {
		cp_val = "";
	}
	return cp_val;
    }

	String getConfParam(ResourceBundle b1, String cp_param) {
	String cp_val = "";
	//try {
		cp_val = toEmWppStr(b1.getString("em.conf."+cp_param));
	//} catch (MissingResourceException e) {
	//	cp_val = "";
	//}
	return cp_val;
    }
	int getConfParamInt(ResourceBundle b1, String cp_param) {
		return toEmWppInt(getConfParam(b1, cp_param));
    }

		//TitleInb = doOver(TitleInb, "TitleInb");
	String doOver(String org_val, String cp_param) {
	//	ResourceBundle b1
	String cp_val = "";
	//try {
	//	cp_val = toEmWppStr(b1.getString("em.conf."+cp_param));
	//} catch (MissingResourceException e) {
	//	cp_val = "";
	//}
	cp_val = org_val;
	return cp_val;
    }

	// ******** Functions For Jsp Configuration Parameters *********

	// ---------Insert Advertisement Functions ------------------
	String insAdForLoc(String adLocName) {

	String ret_str = "";

	if (showAds == 1) {

	int adListLen = adList.length;

	//return if isMobile true
	if (isMobile()) {
		return ret_str;
	}

	if (adLocName.equals("adLocTop") && (adLocTop > 0) && (adLocTop < adListLen)) {
			ret_str = adList[adLocTop];
	}
	if (adLocName.equals("adLocBefSysMenu") && (adLocBefSysMenu > 0) && (adLocBefSysMenu < adListLen)) {
			ret_str = adList[adLocBefSysMenu];
	}
	if (adLocName.equals("adLocBefSysMenu") && (adLocBefSysMenu > 0) && (adLocBefSysMenu < adListLen)) {
			ret_str = adList[adLocBefSysMenu];
	}
	if (adLocName.equals("adLocAftSysMenu") && (adLocAftSysMenu > 0) && (adLocAftSysMenu < adListLen)) {
			ret_str = adList[adLocAftSysMenu];
	}
	if (adLocName.equals("adLocAftTopHR") && (adLocAftTopHR > 0) && (adLocAftTopHR < adListLen)) {
			ret_str = adList[adLocAftTopHR];
	}
	if (adLocName.equals("adLocBefBotHR") && (adLocBefBotHR > 0) && (adLocBefBotHR < adListLen)) {
			ret_str = adList[adLocBefBotHR];
	}
	if (adLocName.equals("adLocAftBotHR") && (adLocAftBotHR > 0) && (adLocAftBotHR < adListLen)) {
			ret_str = adList[adLocAftBotHR];
	}
	if (adLocName.equals("adLocEnd") && (adLocEnd > 0) && (adLocEnd < adListLen)) {
			ret_str = adList[adLocEnd];
	}
	if (adLocName.equals("adLocUMFrameTop") && (adLocUMFrameTop > 0) && (adLocUMFrameTop < adListLen)) {
			ret_str = adList[adLocUMFrameTop];
	}
	if (adLocName.equals("adLocUMFrameEnd") && (adLocUMFrameEnd > 0) && (adLocUMFrameEnd < adListLen)) {
			ret_str = adList[adLocUMFrameEnd];
	}
	if (adLocName.equals("adLocSMFrameTop") && (adLocSMFrameTop > 0) && (adLocSMFrameTop < adListLen)) {
			ret_str = adList[adLocSMFrameTop];
	}
	if (adLocName.equals("adLocSMFrameEnd") && (adLocSMFrameEnd > 0) && (adLocSMFrameEnd < adListLen)) {
			ret_str = adList[adLocSMFrameEnd];
	}

	} //if (showAds == 1) 

	return ret_str;
	}
	// ---------Insert Advertisement Functions ------------------

	// ---------NetwkEmHdrFtr Functions ------------------
	boolean doNetwkEmHdrFtr() {
		if (showNetwkEmHdrFtr == 1) {
			return true;
		}
	return false;
	}
	// ---------NetwkEmHdrFtr Functions ------------------

	// ---------For Mobile Functions ------------------
	/*************

		0] Common function : true in case of A] or B]
				- isMobile()
		A] Web Edition But MObile rendering: 
				- isMobileFull()
		B] Mobile Edition
				- isMobileAll()
				- isMobilePlus()
				- isMobileMini()
	*************/
	void setEmCkForMobType(HttpServletResponse response) {
		Cookie c1 = new Cookie("EmCkForMob","1");
		c1.setVersion(0); 
		c1.setPath("/"); 
		response.addCookie(c1);
	}
	void resetEmCkForMobType(HttpServletResponse response) {
		Cookie c1 = new Cookie("EmCkForMob"," ");
		c1.setVersion(0); 
		c1.setPath("/"); 
		response.addCookie(c1);
	}
	int getEmCkForMobType(HttpServletRequest request) {

	int ck_for_mob_type = 0;
        Cookie[] t_cookies = request.getCookies();
	if (t_cookies != null) {
	  for (int i = 0; i < t_cookies.length; i++) {
            Cookie t_c = t_cookies[i];            
	    String name = t_c.getName(); 
	    String value = t_c.getValue();
	    if(name.equals("EmCkForMob")) {ck_for_mob_type = toEmWppInt(value);}
	  }
	}
		return ck_for_mob_type; 
	}
	boolean isMobile() { 
		//int ck_for_mob_type = getEmCkForMobType(request);
		return (((ck_for_mob_type+for_mob_type_mode) > 0) ? true : false); 
	}

	/******** FOR FUTURE NEEDS
	boolean isMobileFull() { 
		//int ck_for_mob_type = getEmCkForMobType(request);
		return (((ck_for_mob_type) > 0) ? true : false); 
	}
	boolean isMobileEdn() { return ((for_mob_type > 0) ? true : false); }

	boolean isMobileAll() { return ((for_mob_type == 5) ? true : false); }
	boolean isMobileMore() { return ((for_mob_type == 10) ? true : false); }
	boolean isMobilePlus() { return ((for_mob_type == 15) ? true : false); }
	boolean isMobileMini() { return ((for_mob_type == 20) ? true : false); }
	***********/
	// ---------For Mobile Functions ------------------

	// ---------Cookie Functions ------------------


%>

<%
	ck_for_mob_type = getEmCkForMobType(request);
	// -- **** ENABLED Parameters BLOCK
	//menu_images = 1;		
	//menu_image_cols = 2;	
	//fr_menu_images = 0;		
	//menu_scr_images = 1;	
	//app_list_images = 1;	
	// ********* --
%>

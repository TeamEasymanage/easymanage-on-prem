<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="ct" scope="page" class="em.Categ" />
<%
	ct.setApFlg();
	ct.processRequest(request, response);
	get_gui_str(ct.gui_str);
%>
<%-- check valid sign-in --%>
<%	emerr = ct.emerr;
	valid_login = ct.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<%
	mnu1_sel = 1;
	mnu2_sel = 1;
	String usrnm = ct.usrnm;
	app_run = 1; //ct.app_run;
	usrnm_as = ct.usrnm_as;
	usrnm_si = ct.usrnm_si;
	datagrp = ct.datagrp;

%>

<%-------------------------%>

<% if (JspCust()) { %>
<%@ include file="/custom/jsp/ListAppMenuCustom.jsp" %>
<% } else { %>
<%@ include file="ListAppMenu.jsp" %>
<% } %>

<%-------------------------%>

<% ct.doneRequest(); %>


<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>

<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wp" scope="page" class="em.Agtproj_runsave" />
<%
	if (app_run == 1) {
	wp.setApFlg();
	}
	wp.processRequest(request, response);
	get_gui_str(wp.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wp.emerr;
	valid_login = wp.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Run Response Save </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wp.usrnm;

	if (app_run == 1) {
	usrnm_as = wp.usrnm_as;
	usrnm_si = wp.usrnm_si;
	datagrp = wp.datagrp;
	}

%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wp.categ_name%></b></font></font></td>
</td>
</tr>
</table>

	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String SendToUrlwpsc = "/"+usrproj+"/jsp/dn/agtproj.jsp?usrnm="+wp.usrnm +"&categ_id="+wp.categ_id+"&categ_name="+wp.categ_name+"&categ_levels="+wp.categ_levels+"&routeto="+wp.routeto+"&tm_now="+tm_now; 
	%>

	<%= bfont %> <b> Agent Run Response Save</b></font><br><br>

	<% wp.doResponseSave_Agt(request); %>
	
	<%=bfont%> 
	<% if ( wp.dodb_stat == 1) { %>
		Response Saved.<br><br>
		Please Use Browser BACK button and Close session on Agent Server.<br>

<%--
<SCRIPT langauage="JavaScript">
<!--
function SendTo()
{
	window.location.href= "<%=SendToUrlwpsc%>";
}
function SendToLater()
{
	window.setTimeout("SendTo();", 2000);
}
	SendTo();
//-->
</SCRIPT>
<meta http-equiv="Refresh" content="0; url=<%=SendToUrlwpsc%>">
<noscript>
  <BR> <%= bfont %> Your browser does not seem to support JavaScript. </font>
  <BR> <%= bfont %> To continue <a href="<%=SendToUrlwpsc%>">Click Here</a>.</font><BR>
</noscript>
--%>

	<% } else { %>
		Error: <%= wp.dodb_info %>
	<% } %>
	</font>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (wp.valid_login ==0) --%>

</HTML>

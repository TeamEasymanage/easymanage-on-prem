<!--
/*
 * Copyright (c) 2026 EasyManage.com,
 * 
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of EasyManage.com ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with EasyManage.com.
 */
-->

<%-- Has html tag --%><%@ include file="/pre_dn_top_sm_ins0.jsp" %>
<%@ include file="../BaseEmJsp.jsp" %>

<jsp:useBean id="wpsc" scope="page" class="em.Agtproj_task" />
<%
	wpsc.processRequest(request, response);
	get_gui_str(wpsc.gui_str);

%>
<%-- check valid sign-in --%>
<%	emerr = wpsc.emerr;
	valid_login = wpsc.valid_login; 
if (valid_login == 0 ) { 
%>
<%@ include file="../no_si.jsp" %>
<%
} else {  %> 
<!-- head -->
<title> <%=TitleInb%> Agent Project Tasks </title>
</head>
<body> <!-- <%=em_body_str%> bgcolor=<%= bcolor %> -->
<%
	String usrnm = wpsc.usrnm;
%>
<%@ include file="../pre_dn_sm.jsp" %>
<table width="100%" border=0><tr>
<td bgcolor="#CCCCEE"><%= bfont1 %><font color="#000000">
<b><%=wpsc.categ_name%></b></font></font></td>
</td>
</tr>
</table>
<BR>


	<% 
	String tm_now = Long.toString(new java.util.Date().getTime());
	String SendToUrlwpsc = "/"+usrproj+"/jsp/dn/agtproj.jsp?usrnm="+wpsc.usrnm +"&categ_id="+wpsc.categ_id+"&categ_name="+wpsc.categ_name+"&categ_levels="+wpsc.categ_levels+"&routeto="+wpsc.routeto+"&tm_now="+tm_now; 
	%>

	<%= bfont %> <b> Agent Project Tasks</b></font><br>


<% if ( wpsc.attempt == 0) { %>
	<%-- Display Form --%>

	<% wpsc.doFormQry(); %>
	<%= wpsc.doForm() %>
	<% wpsc.doneReq(); %>
<% } else if ( wpsc.attempt == 1) { %>
	<% wpsc.doDbData(); %>
	<% wpsc.doneReq(); %>

<SCRIPT langauage="JavaScript">
<!--
function SendTo()
{
	window.location.href= "<%=SendToUrlwpsc%>";
}
function SendToLater()
{
	window.setTimeout("SendTo();", 2000);
}
	SendTo();
//-->
</SCRIPT>
<meta http-equiv="Refresh" content="0; url=<%=SendToUrlwpsc%>">
<noscript>
  <BR> <%= bfont %> Your browser does not seem to support JavaScript. </font>
  <BR> <%= bfont %> To continue <a href="<%=SendToUrlwpsc%>">Click Here</a>.</font><BR>
</noscript>



<% } // elseofif ( wpsc.attempt == 1)... %>

<%@ include file="../post_dn_sm.jsp" %>

</BODY>

<% } %> <%-- else of:  if (ct.valid_login ==0) --%>

</HTML>
